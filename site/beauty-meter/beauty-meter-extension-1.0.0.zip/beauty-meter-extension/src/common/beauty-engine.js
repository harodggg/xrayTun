/**
 * 美颜程度检测引擎 · beauty-engine.js
 * ---------------------------------------------------------------------------
 * 纯本地像素分析，零依赖、零网络、零模型：
 *   输入一张图的 RGBA 像素 → 输出 0~100 的「美颜程度」评分 + 六个维度的分项得分。
 *
 * 判断依据（美颜 App 的典型处理链：磨皮 → 美白 → 调色 → 补锐化）：
 *   1) 磨皮去纹理  皮肤区域的高频细节被抹平，但轮廓边缘仍在（双边滤波特征）
 *   2) 美白提亮    肤色被推向「高亮度 + 极低彩度 + 偏红粉」的区间
 *   3) 肤色均匀    皮肤色度（Cr/Cb）起伏被压平
 *   4) 去色低饱和  整体与皮肤饱和度被压低
 *   5) 通透度压缩  对比度被压缩、高光溢出
 *   6) 锐化光晕    磨皮后补锐化，在强边缘两侧留下过冲（overshoot）
 *
 * 关键设计：所有指标都在「长边 512px 的标准工作分辨率」上测量。
 * 不同尺寸的图片先归一到同一尺度，纹理能量才具备可比性（见 resizeImageData）。
 * 图片本身小于 480px 时纹理信息已在传播过程中丢失，会给出高置信度警告。
 *
 * 运行环境：Chrome 扩展的 Service Worker（importScripts）、
 *          扩展页面（<script>）、Node.js（require）三处通用。
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.BeautyEngine = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = '1.0.0';

  /* =======================================================================
   * 可调参数
   * ===================================================================== */

  var DEFAULT_WEIGHTS = {
    smoothing: 0.40,
    whitening: 0.20,
    uniformity: 0.18,
    chroma: 0.11,
    contrast: 0.11
  };

  var DEFAULTS = {
    maxSide: 512,        // 标准工作分辨率（长边）
    sensitivity: 1.0,    // 灵敏度：>1 更敏感，<1 更保守（对偏离中位的分数做放大/收缩）
    weights: null,       // 自定义权重，null 表示用 DEFAULT_WEIGHTS
    minSkinRatio: 0.02,  // 低于此肤色占比则皮肤类指标不可用
    strictSkinRatio: 0.03, // 严格肤色规则命中率低于此值时启用放宽规则（疑似强美白）
    minConfidentSide: 480  // 原图长边低于此值 → 降置信度并警告
  };

  var METRIC_META = {
    smoothing: { label: '磨皮去纹理', hint: '皮肤纹理是否被抹平而轮廓仍在' },
    whitening: { label: '美白提亮', hint: '肤色是否被推向高亮低彩度的漂白区间' },
    uniformity: { label: '肤色均匀', hint: '肤色色度起伏是否被压平' },
    chroma: { label: '去色低饱和', hint: '整体与皮肤的饱和度是否被压低' },
    contrast: { label: '通透度压缩', hint: '对比度是否被压缩、高光是否溢出' }
  };

  /** 分档：分数上界（不含）→ 档位 */
  var LEVELS = [
    { max: 20, label: '原生', desc: '几乎看不到美颜痕迹' },
    { max: 40, label: '轻度美颜', desc: '轻微磨皮或提亮，接近真实' },
    { max: 60, label: '中度美颜', desc: '明显的磨皮 + 美白处理' },
    { max: 80, label: '重度美颜', desc: '皮肤纹理大量丢失、肤色明显漂白' },
    { max: 101, label: '极致美颜', desc: '接近「塑料脸」级别的强处理' }
  ];

  var SKIN_METRICS = ['smoothing', 'whitening', 'uniformity'];
  void SKIN_METRICS;

  /* =======================================================================
   * 基础工具
   * ===================================================================== */

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  function round1(v) { return Math.round(v * 10) / 10; }

  /**
   * 分段线性映射。pts 形如 [[x0,y0],[x1,y1],...]，x 必须递增。
   * 用于把物理量（纹理比、色度标准差…）映射成 0~100 的美颜程度分。
   * 每个断点的含义都写在调用处的注释里。
   */
  function pw(x, pts) {
    var n = pts.length;
    if (!isFinite(x)) return 0;
    if (x <= pts[0][0]) return pts[0][1];
    if (x >= pts[n - 1][0]) return pts[n - 1][1];
    for (var i = 1; i < n; i++) {
      if (x <= pts[i][0]) {
        var x0 = pts[i - 1][0], y0 = pts[i - 1][1];
        var x1 = pts[i][0], y1 = pts[i][1];
        return y0 + (y1 - y0) * (x - x0) / (x1 - x0);
      }
    }
    return pts[n - 1][1];
  }

  function normalizeOptions(options) {
    var opt = {};
    for (var k in DEFAULTS) if (Object.prototype.hasOwnProperty.call(DEFAULTS, k)) opt[k] = DEFAULTS[k];
    if (options) for (var j in options) if (Object.prototype.hasOwnProperty.call(options, j)) opt[j] = options[j];
    var w = opt.weights || DEFAULT_WEIGHTS;
    var weights = {};
    var sum = 0;
    Object.keys(DEFAULT_WEIGHTS).forEach(function (key) {
      var v = typeof w[key] === 'number' ? w[key] : DEFAULT_WEIGHTS[key];
      weights[key] = v > 0 ? v : 0;
      sum += weights[key];
    });
    if (sum <= 0) { weights = Object.assign({}, DEFAULT_WEIGHTS); sum = 1; }
    Object.keys(weights).forEach(function (key) { weights[key] /= sum; });
    opt.weights = weights;
    opt.sensitivity = clamp(Number(opt.sensitivity) || 1, 0.2, 3);
    return opt;
  }

  /* =======================================================================
   * 尺度归一：长边缩放到 maxSide（只缩不放）
   * 分离式面积平均（box）重采样，保证不同浏览器/不同环境结果一致。
   * ===================================================================== */

  function boxWeights(srcLen, dstLen) {
    var out = new Array(dstLen);
    var s = srcLen / dstLen;
    for (var i = 0; i < dstLen; i++) {
      var start = i * s, end = (i + 1) * s;
      var i0 = Math.floor(start);
      var i1 = Math.min(srcLen - 1, Math.ceil(end) - 1);
      var idx = [], wts = [], total = 0;
      for (var j = i0; j <= i1; j++) {
        var cov = Math.min(end, j + 1) - Math.max(start, j);
        if (cov > 0) { idx.push(j); wts.push(cov); total += cov; }
      }
      if (!idx.length) { idx.push(clamp(i0, 0, srcLen - 1)); wts.push(1); total = 1; }
      for (var k = 0; k < wts.length; k++) wts[k] /= total;
      out[i] = { i: idx, w: wts };
    }
    return out;
  }

  /**
   * 把 imageData 缩小到长边 <= maxSide。已经够小则原样返回（不放大，
   * 放大只会人为制造模糊、把「磨皮」分数抬高）。
   */
  function resizeImageData(imageData, maxSide) {
    var w = imageData.width, h = imageData.height;
    var long = Math.max(w, h);
    if (!maxSide || maxSide <= 0 || long <= maxSide) {
      return { data: imageData.data, width: w, height: h, resized: false };
    }
    var scale = maxSide / long;
    var tw = Math.max(1, Math.round(w * scale));
    var th = Math.max(1, Math.round(h * scale));
    var src = imageData.data;
    var tmp = new Float32Array(tw * h * 4);
    var xw = boxWeights(w, tw);
    var yw = boxWeights(h, th);
    var x, y, k, seg, si, o, wt;

    for (y = 0; y < h; y++) {
      var rowIn = y * w * 4;
      for (x = 0; x < tw; x++) {
        seg = xw[x];
        var r = 0, g = 0, b = 0, a = 0;
        for (k = 0; k < seg.i.length; k++) {
          si = rowIn + seg.i[k] * 4;
          wt = seg.w[k];
          r += src[si] * wt; g += src[si + 1] * wt; b += src[si + 2] * wt; a += src[si + 3] * wt;
        }
        o = (y * tw + x) * 4;
        tmp[o] = r; tmp[o + 1] = g; tmp[o + 2] = b; tmp[o + 3] = a;
      }
    }

    var out = new Uint8ClampedArray(tw * th * 4);
    for (y = 0; y < th; y++) {
      seg = yw[y];
      for (x = 0; x < tw; x++) {
        var r2 = 0, g2 = 0, b2 = 0, a2 = 0;
        for (k = 0; k < seg.i.length; k++) {
          si = (seg.i[k] * tw + x) * 4;
          wt = seg.w[k];
          r2 += tmp[si] * wt; g2 += tmp[si + 1] * wt; b2 += tmp[si + 2] * wt; a2 += tmp[si + 3] * wt;
        }
        o = (y * tw + x) * 4;
        out[o] = r2 + 0.5; out[o + 1] = g2 + 0.5; out[o + 2] = b2 + 0.5; out[o + 3] = a2 + 0.5;
      }
    }
    return { data: out, width: tw, height: th, resized: true };
  }

  /* =======================================================================
   * 逐像素特征平面：Y / Cb / Cr / 彩度
   * ===================================================================== */

  function buildPlanes(data, w, h) {
    var n = w * h;
    var Y = new Float32Array(n);
    var Cb = new Float32Array(n);
    var Cr = new Float32Array(n);
    var C = new Float32Array(n); // 彩度 max-min
    var i, p, r, g, b, mx, mn;
    for (i = 0, p = 0; i < n; i++, p += 4) {
      r = data[p]; g = data[p + 1]; b = data[p + 2];
      Y[i] = 0.299 * r + 0.587 * g + 0.114 * b;
      Cb[i] = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      Cr[i] = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
      mx = r > g ? (r > b ? r : b) : (g > b ? g : b);
      mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
      C[i] = mx - mn;
    }
    return { Y: Y, Cb: Cb, Cr: Cr, C: C };
  }

  /* =======================================================================
   * 肤色检测
   *   严格规则：经典 YCbCr + RGB 约束，误报少，但强美白后的皮肤会漏检
   *   放宽规则：高亮度 + 低彩度 + 偏红，专门捞「被漂白的皮肤」
   * 再做 3x3 形态学开闭 + 连通域过滤，去掉零星噪点和背景误检。
   * ===================================================================== */

  function skinMaskStrict(data, w, h) {
    var n = w * h, mask = new Uint8Array(n), count = 0;
    for (var i = 0, p = 0; i < n; i++, p += 4) {
      var r = data[p], g = data[p + 1], b = data[p + 2];
      var y = 0.299 * r + 0.587 * g + 0.114 * b;
      var cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      var cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
      var mx = r > g ? (r > b ? r : b) : (g > b ? g : b);
      var mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
      var ycc = cb >= 77 && cb <= 127 && cr >= 133 && cr <= 173;
      var rgb = r > 95 && g > 40 && b > 20 && mx - mn > 15 &&
                Math.abs(r - g) > 15 && r > g && r > b && y > 40;
      if (ycc && rgb) { mask[i] = 1; count++; }
    }
    return { mask: mask, count: count };
  }

  function skinMaskRelaxed(data, w, h) {
    var n = w * h, mask = new Uint8Array(n), count = 0;
    for (var i = 0, p = 0; i < n; i++, p += 4) {
      var r = data[p], g = data[p + 1], b = data[p + 2];
      var y = 0.299 * r + 0.587 * g + 0.114 * b;
      var cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      var cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
      var mx = r > g ? (r > b ? r : b) : (g > b ? g : b);
      var mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
      // 高亮度 + 低彩度 + 但仍然偏暖（Cr>131、R 明显大于 B）—— 漂白后皮肤的典型特征。
      // 必须要求「偏暖」：黑白照 R=G=B，Cr=128，否则整张灰度图会被当成漂白的皮肤。
      if (y >= 130 && cb >= 76 && cb <= 140 && cr >= 131 && cr <= 182 &&
          mx - mn >= 6 && mx - mn <= 72 && r > 150 && r - b >= 5 && r >= g) {
        mask[i] = 1; count++;
      }
    }
    return { mask: mask, count: count };
  }

  function morph(mask, w, h, dilate) {
    var out = new Uint8Array(w * h);
    var x, y, dx, dy, hit;
    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        hit = 0;
        for (dy = -1; dy <= 1 && !hit; dy++) {
          var yy = y + dy;
          if (yy < 0 || yy >= h) { if (!dilate) { hit = -1; } continue; }
          for (dx = -1; dx <= 1; dx++) {
            var xx = x + dx;
            if (xx < 0 || xx >= w) { if (!dilate) { hit = -1; } continue; }
            var v = mask[yy * w + xx];
            if (dilate ? v : !v) { hit = 1; break; }
          }
        }
        if (hit === -1) { out[y * w + x] = 0; }        // 边界外视为空
        else if (dilate) out[y * w + x] = hit ? 1 : 0;
        else out[y * w + x] = hit ? 0 : 1;
      }
    }
    return out;
  }

  function invertMask(mask) {
    var out = new Uint8Array(mask.length);
    for (var i = 0; i < mask.length; i++) out[i] = mask[i] ? 0 : 1;
    return out;
  }

  /** 并集掩膜 */
  function unionMask(a, b) {
    var out = new Uint8Array(a.length);
    for (var i = 0; i < a.length; i++) out[i] = (a[i] || b[i]) ? 1 : 0;
    return out;
  }

  /**
   * 保留足够大的连通域（8 邻域），并给出最大连通域的「像不像一张脸」指标。
   * 判据来自真实样本标定（docs/CALIBRATION.md）：
   *   人像：最大连通域占比 4.6%~74%，长宽比 0.49~1.30，bbox 填充率 0.33~0.75
   *   建筑（泰姬陵）：占比 3.3%~3.7%、长宽比 1.55~2.0
   *   风景（雪山）：占比 2.1%~5.9%、长宽比 1.1~1.8
   *   食物：长宽比 1.5~2.0（横向暖色带）、占比 26%~58%
   * 于是要求：占比 >= 4%、长宽比 0.35~1.40、填充率 >= 0.30。
   * （这三个阈值是唯一能同时「放过全部人像样本」并「拒绝全部反例」的组合；
   *   也试过「人脸暗结构/内部对比」这类特征，实测无法区分食物照，已放弃并只留在 debug 里。）
   */
  function keepPlausibleSkin(mask, w, h, minSize, size) {
    var n = w * h;
    var seen = new Uint8Array(n);
    var out = new Uint8Array(n);
    var stack = new Int32Array(n);
    var total = 0;
    var largest = { size: 0, bw: 0, bh: 0 };
    for (var s = 0; s < n; s++) {
      if (!mask[s] || seen[s]) continue;
      var sp = 0, csize = 0;
      var minX = w, maxX = 0, minY = h, maxY = 0;
      stack[sp++] = s; seen[s] = 1;
      var comp = [];
      while (sp > 0) {
        var idx = stack[--sp];
        comp.push(idx); csize++;
        var x = idx % w, y = (idx / w) | 0;
        if (x < minX) minX = x; if (x > maxX) maxX = x;
        if (y < minY) minY = y; if (y > maxY) maxY = y;
        for (var dy = -1; dy <= 1; dy++) {
          for (var dx = -1; dx <= 1; dx++) {
            if (!dx && !dy) continue;
            var xx = x + dx, yy = y + dy;
            if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
            var ni = yy * w + xx;
            if (mask[ni] && !seen[ni]) { seen[ni] = 1; stack[sp++] = ni; }
          }
        }
      }
      if (csize > largest.size) {
        largest = { size: csize, bw: maxX - minX + 1, bh: maxY - minY + 1,
                    minX: minX, maxX: maxX, minY: minY, maxY: maxY };
      }
      if (csize >= minSize) {
        for (var c = 0; c < comp.length; c++) out[comp[c]] = 1;
        total += csize;
      }
    }
    var frac = largest.size / size;
    var aspect = largest.bh > 0 ? largest.bw / largest.bh : 0;
    var fill = (largest.bw * largest.bh) > 0 ? largest.size / (largest.bw * largest.bh) : 0;
    return {
      mask: out,
      total: total,
      largest: largest,
      largestFrac: frac,
      largestAspect: aspect,
      largestFill: fill,
      plausible: frac >= 0.04 && aspect >= 0.35 && aspect <= 1.40 && fill >= 0.30
    };
  }

  /* =======================================================================
   * 局部统计量：积分图求 5x5 邻域均值/标准差；Sobel 梯度；Laplacian
   * ===================================================================== */

  function integralPlane(v, w, h) {
    var I = new Float64Array((w + 1) * (h + 1));
    for (var y = 0; y < h; y++) {
      var rowSum = 0;
      for (var x = 0; x < w; x++) {
        rowSum += v[y * w + x];
        I[(y + 1) * (w + 1) + (x + 1)] = I[y * (w + 1) + (x + 1)] + rowSum;
      }
    }
    return I;
  }

  function boxSum(I, w, x0, y0, x1, y1) {
    var W = w + 1;
    return I[(y1 + 1) * W + (x1 + 1)] - I[y0 * W + (x1 + 1)] - I[(y1 + 1) * W + x0] + I[y0 * W + x0];
  }

  /** 5x5 邻域标准差平面（局部纹理强度） */
  function localStdPlane(Y, w, h) {
    var n = w * h;
    var Y2 = new Float32Array(n);
    for (var i = 0; i < n; i++) Y2[i] = Y[i] * Y[i];
    var I = integralPlane(Y, w, h), I2 = integralPlane(Y2, w, h);
    var S = new Float32Array(n);
    var r = 2;
    for (var y = 0; y < h; y++) {
      var y0 = Math.max(0, y - r), y1 = Math.min(h - 1, y + r);
      for (var x = 0; x < w; x++) {
        var x0 = Math.max(0, x - r), x1 = Math.min(w - 1, x + r);
        var cnt = (x1 - x0 + 1) * (y1 - y0 + 1);
        if (cnt < 4) { S[y * w + x] = 0; continue; }
        var s = boxSum(I, w, x0, y0, x1, y1);
        var s2 = boxSum(I2, w, x0, y0, x1, y1);
        var mean = s / cnt;
        var v = s2 / cnt - mean * mean;
        S[y * w + x] = v > 0 ? Math.sqrt(v) : 0;
      }
    }
    return { S: S, I: I };
  }

  /** Sobel 梯度幅值（边缘强度） */
  function gradientPlane(Y, w, h) {
    var G = new Float32Array(w * h);
    for (var y = 1; y < h - 1; y++) {
      for (var x = 1; x < w - 1; x++) {
        var i = y * w + x;
        var gx = (Y[i + w + 1] + 2 * Y[i + 1] + Y[i - w + 1]) -
                 (Y[i + w - 1] + 2 * Y[i - 1] + Y[i - w - 1]);
        var gy = (Y[i + w - 1] + 2 * Y[i + w] + Y[i + w + 1]) -
                 (Y[i - w - 1] + 2 * Y[i - w] + Y[i - w + 1]);
        G[i] = Math.sqrt(gx * gx + gy * gy);
      }
    }
    return G;
  }

  /** 4 邻域 Laplacian 绝对值（高频能量） */
  function laplacianPlane(Y, w, h) {
    var L = new Float32Array(w * h);
    for (var y = 1; y < h - 1; y++) {
      for (var x = 1; x < w - 1; x++) {
        var i = y * w + x;
        L[i] = Math.abs(4 * Y[i] - Y[i - 1] - Y[i + 1] - Y[i - w] - Y[i + w]);
      }
    }
    return L;
  }

  /** 中央差分梯度（色度用） */
  function chromaGradientPlane(Cr, Cb, w, h) {
    var G = new Float32Array(w * h);
    for (var y = 1; y < h - 1; y++) {
      for (var x = 1; x < w - 1; x++) {
        var i = y * w + x;
        var dcx = Math.abs(Cr[i + 1] - Cr[i - 1]) + Math.abs(Cb[i + 1] - Cb[i - 1]);
        var dcy = Math.abs(Cr[i + w] - Cr[i - w]) + Math.abs(Cb[i + w] - Cb[i - w]);
        G[i] = (dcx + dcy) * 0.5;
      }
    }
    return G;
  }

  function percentileFromHistogram(hist, total, p) {
    var target = total * p, acc = 0;
    for (var i = 0; i < hist.length; i++) {
      acc += hist[i];
      if (acc >= target) return i;
    }
    return hist.length - 1;
  }

  function gradientHistogram(G) {
    var hist = new Int32Array(180); // bin = 8 梯度单位，覆盖 0~1440
    var total = 0;
    for (var i = 0; i < G.length; i++) {
      var b = Math.min(179, (G[i] / 8) | 0);
      hist[b]++; total++;
    }
    return { hist: hist, total: total };
  }

  /* =======================================================================
   * 掩膜统计
   * ===================================================================== */

  function maskedMean(v, mask, exclude) {
    var sum = 0, cnt = 0;
    for (var i = 0; i < v.length; i++) {
      if (mask[i] && !(exclude && exclude[i])) { sum += v[i]; cnt++; }
    }
    return cnt ? { mean: sum / cnt, count: cnt } : { mean: 0, count: 0 };
  }

  function maskedMean2(v, mask) {
    var sum = 0, cnt = 0;
    for (var i = 0; i < v.length; i++) if (mask[i]) { sum += v[i]; cnt++; }
    return cnt ? sum / cnt : 0;
  }

  function maskedStd(v, mask) {
    var s = 0, s2 = 0, cnt = 0;
    for (var i = 0; i < v.length; i++) {
      if (!mask[i]) continue;
      s += v[i]; s2 += v[i] * v[i]; cnt++;
    }
    if (!cnt) return 0;
    var m = s / cnt;
    var va = s2 / cnt - m * m;
    return va > 0 ? Math.sqrt(va) : 0;
  }

  function globalMeanStd(v) {
    var s = 0, s2 = 0, n = v.length;
    for (var i = 0; i < n; i++) { s += v[i]; s2 += v[i] * v[i]; }
    var m = s / n;
    var va = s2 / n - m * m;
    return { mean: m, std: va > 0 ? Math.sqrt(va) : 0 };
  }

  /** 同时满足两个掩膜（用 Uint8 逻辑与） */
  function andMask(a, b) {
    var out = new Uint8Array(a.length);
    for (var i = 0; i < a.length; i++) out[i] = (a[i] && b[i]) ? 1 : 0;
    return out;
  }

  /** 内缩 1px，避免边缘/边界像素污染统计 */
  function borderExclude(w, h, radius) {
    var out = new Uint8Array(w * h);
    var r = radius || 2;
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        out[y * w + x] = (x < r || y < r || x >= w - r || y >= h - r) ? 0 : 1;
      }
    }
    return out;
  }

  /* =======================================================================
   * 主分析流程
   * ===================================================================== */

  function badReport(error, opts) {
    var weights = (opts && opts.weights) || DEFAULT_WEIGHTS;
    var metrics = Object.keys(weights).map(function (key) {
      return emptyMetric(key, weights[key]);
    });
    return {
      ok: false,
      version: VERSION,
      error: String(error && error.message ? error.message : error),
      score: 0,
      level: LEVELS[0].label,
      levelDesc: LEVELS[0].desc,
      confidence: 0,
      skinRatio: 0,
      skinPixels: 0,
      metrics: metrics,
      warnings: ['图片无法分析：' + (error && error.message ? error.message : error)],
      summary: '分析失败',
      debug: {}
    };
  }

  function emptyMetric(key, weight) {
    return {
      key: key,
      label: METRIC_META[key].label,
      hint: METRIC_META[key].hint,
      score: 0,
      weight: weight,
      weightPct: Math.round(weight * 100),
      available: false,
      raw: {},
      evidence: '数据不足'
    };
  }

  function levelFor(score) {
    for (var i = 0; i < LEVELS.length; i++) if (score < LEVELS[i].max) return LEVELS[i];
    return LEVELS[LEVELS.length - 1];
  }

  /**
   * 分析一张图片。
   * @param {{data:Uint8ClampedArray|Uint8Array,width:number,height:number}} imageData
   * @param {{maxSide?:number,sensitivity?:number,weights?:object}} [options]
   * @returns {object} report
   */
  function analyze(imageData, options) {
    var opt = normalizeOptions(options);
    try {
      return analyzeInner(imageData, opt);
    } catch (err) {
      return badReport(err, opt);
    }
  }

  function analyzeInner(imageData, opt) {
    if (!imageData || !imageData.data || !imageData.width || !imageData.height) {
      return badReport(new Error('缺少像素数据（需要 {data,width,height}）'), opt);
    }
    var size = imageData.width * imageData.height;
    if (imageData.data.length < size * 4) {
      return badReport(new Error('像素数组长度与尺寸不匹配'), opt);
    }
    if (size < 16 * 16) {
      return badReport(new Error('图片太小（短边需 >= 16px）'), opt);
    }

    var warnings = [];
    var nativeW = imageData.width, nativeH = imageData.height;
    var nativeLong = Math.max(nativeW, nativeH);
    var rs = resizeImageData(imageData, opt.maxSide);
    var w = rs.width, h = rs.height;
    var data = rs.data;
    // 后续所有掩膜/比例都在「工作分辨率」上统计，务必用 w*h 而不是原图像素数，
    // 否则大图缩小后各种占比会被系统性低估（曾是 skinRatio 偏小 4 倍的 bug 根源）。
    size = w * h;

    if (nativeLong < opt.minConfidentSide) {
      warnings.push('原图较小（长边 ' + nativeLong + 'px），网络传播本身已损失纹理，磨皮维度可能偏高');
    }

    var planes = buildPlanes(data, w, h);
    var Y = planes.Y, Cb = planes.Cb, Cr = planes.Cr, C = planes.C;

    /* ---- 肤色掩膜 ----
     * 实测（见 docs/CALIBRATION.md）：单靠颜色规则无法区分「皮肤」和「暖色物体」
     * （食物照的暖色区域会被判成 30% 皮肤）。因此这里做两级把关：
     *   1) 颜色：严格规则 ∪ 放宽规则（放宽规则专收漂白后的高亮低彩度皮肤）
     *   2) 形状：最大连通域必须够大、长宽比和填充率像「一张脸」，
     *      否则判定为「没有可信的肤色区域」，皮肤类指标直接不可用。
     */
    var strict = skinMaskStrict(data, w, h);
    var relaxed = skinMaskRelaxed(data, w, h);
    var skinRatioStrict = strict.count / size;
    var skinRatioRelaxed = relaxed.count / size;
    var rawMask = unionMask(strict.mask, relaxed.mask);
    var usedRelaxed = skinRatioStrict < opt.strictSkinRatio && skinRatioRelaxed > skinRatioStrict;
    if (usedRelaxed) {
      warnings.push('常规肤色规则命中很少，已合并放宽规则（常见于强美白/强滤镜或弱光图片）');
    }
    // 闭运算（膨胀→腐蚀）补洞、开运算（腐蚀→膨胀）去噪点
    var skinClean = morph(rawMask, w, h, true);
    skinClean = morph(skinClean, w, h, false);
    skinClean = morph(skinClean, w, h, false);
    skinClean = morph(skinClean, w, h, true);

    var minComp = Math.max(100, Math.round(size * 0.0005));
    var compInfo = keepPlausibleSkin(skinClean, w, h, minComp, size);
    var skin = compInfo.mask;
    var skinPixels = compInfo.total;
    var skinRatio = skinPixels / size;

    // 人脸结构兜底：真正的脸，其肤色连通域**外接矩形**内一定有明显暗结构
    // （眉毛/眼睛/睫毛/鼻孔）和明显的内部明暗起伏。这里只把这两个量作为 debug
    // 输出，不参与判定——实测它们无法区分「人脸」和「有阴影的暖色画面」
    // （食物照 bboxDark=0.37、bboxYStd=82，比部分人像还高）。
    var lb = compInfo.largest;
    var bboxDark = 0, bboxCount = 0, bboxSum = 0, bboxSum2 = 0;
    if (lb && lb.size > 0) {
      for (var by = lb.minY; by <= lb.maxY; by++) {
        var rowBase = by * w;
        for (var bx = lb.minX; bx <= lb.maxX; bx++) {
          var bv = Y[rowBase + bx];
          bboxCount++;
          bboxSum += bv; bboxSum2 += bv * bv;
          if (bv < 80) bboxDark++;
        }
      }
    }
    var bboxDarkFrac = bboxCount ? bboxDark / bboxCount : 0;
    var bboxMeanY = bboxCount ? bboxSum / bboxCount : 0;
    var bboxYStd = bboxCount ? Math.sqrt(Math.max(0, bboxSum2 / bboxCount - bboxMeanY * bboxMeanY)) : 0;
    var faceLike = compInfo.plausible;
    var largestFrac = compInfo.largestFrac;
    var largestAspect = compInfo.largestAspect;
    var largestFill = compInfo.largestFill;
    var nonSkin = invertMask(skin);

    var skinInterior = andMask(skin, morph(skin, w, h, false));
    var interiorCount = 0;
    for (var ic = 0; ic < skinInterior.length; ic++) if (skinInterior[ic]) interiorCount++;
    // 腐蚀后太小时直接用原掩膜（弱光/细窄肤色区域）
    if (interiorCount < skinPixels * 0.35) skinInterior = skin;
    var nonSkinInterior = andMask(nonSkin, morph(nonSkin, w, h, false));
    var border = borderExclude(w, h, 2);

    /* ---- 纹理 / 边缘 ---- */
    var grad = gradientPlane(Y, w, h);
    var lap = laplacianPlane(Y, w, h);
    var loc = localStdPlane(Y, w, h);
    var S = loc.S;

    var gh = gradientHistogram(grad);
    var p90 = Math.max(20, percentileFromHistogram(gh.hist, gh.total, 0.90) * 8);
    var p98 = Math.max(60, percentileFromHistogram(gh.hist, gh.total, 0.98) * 8);
    var isEdge = new Uint8Array(size);
    var isStrongEdge = new Uint8Array(size);
    for (var e = 0; e < size; e++) {
      if (grad[e] >= p90) isEdge[e] = 1;
      if (grad[e] >= p98) isStrongEdge[e] = 1;
    }
    var flat = andMask(border, invertMask(isEdge));

    var gStats = globalMeanStd(Y);
    var rmsContrast = gStats.std / 255;

    var skinFlat = andMask(skinInterior, flat);
    var nonSkinFlat = andMask(nonSkinInterior, flat);

    var skinTex = maskedMean(S, skinFlat);
    var refTex = maskedMean(S, nonSkinFlat);
    var refTexVal = Math.max(refTex.mean, 0.8);
    var textureRatio = skinTex.mean / refTexVal;

    /* ---- 皮肤色度 / 亮度 ---- */
    var skinY = maskedMean(Y, skinInterior).mean || maskedMean(Y, skin).mean;
    var skinSat = maskedMean(C, skinInterior).mean || maskedMean(C, skin).mean;
    var skinCr = maskedMean(Cr, skinInterior).mean || maskedMean(Cr, skin).mean;
    var skinCb = maskedMean(Cb, skinInterior).mean || maskedMean(Cb, skin).mean;

    // 被漂白的皮肤占比：高亮度 + 低彩度
    var paleCount = 0, skinCountAll = 0;
    for (var q = 0; q < size; q++) {
      if (!skin[q]) continue;
      skinCountAll++;
      if (Y[q] >= 205 && C[q] <= 50) paleCount++;
    }
    var paleFrac = skinCountAll ? paleCount / skinCountAll : 0;

    var chromaStd = Math.sqrt((maskedStd(Cr, skin) * maskedStd(Cr, skin) +
                               maskedStd(Cb, skin) * maskedStd(Cb, skin)) / 2);

    var cg = chromaGradientPlane(Cr, Cb, w, h);
    var chromaGrad = maskedMean(cg, andMask(skinInterior, flat)).mean;

    /* ---- 全局色度 / 对比 ---- */
    var satMean = maskedMean(C, border).mean / 255;
    var nonSkinSat = Math.max(maskedMean(C, nonSkinInterior).mean, 1);
    var skinRelSat = skinSat / nonSkinSat;

    var deepBlack = 0, highLight = 0, tot = 0;
    for (var t = 0; t < size; t++) {
      if (Y[t] < 20) deepBlack++;
      if (Y[t] > 240) highLight++;
      tot++;
    }
    var deepBlackFrac = deepBlack / tot;
    var highLightFrac = highLight / tot;

    // 灰度图（黑白照）没有肤色信息：肤色掩膜必然失效，任何「美颜程度」都无从谈起。
    // 早期版本曾因此把一张黑白人像判成重度美颜（72 分），这里直接拒绝而不是外推。
    if (satMean < 0.02) {
      var grayReport = badReport(
        new Error('整图为灰度/近灰度（如黑白照），缺少肤色信息，无法判断美颜程度'), opt);
      grayReport.reason = 'grayscale';
      grayReport.debug = { satMean: Math.round(satMean * 1000) / 1000 };
      return grayReport;
    }

    /* ---- 锐化光晕：强边缘邻域的高频能量 / 平坦区高频能量 ---- */
    var edgeAdj = morph(morph(isStrongEdge, w, h, true), w, h, true);
    var edgeBand = andMask(edgeAdj, invertMask(isStrongEdge));
    var flatFar = andMask(border, invertMask(morph(morph(isStrongEdge, w, h, true), w, h, true)));
    var haloEnergy = maskedMean(lap, edgeBand).mean;
    var flatEnergy = Math.max(maskedMean(lap, flatFar).mean, 0.8);
    var haloRatio = haloEnergy / flatEnergy;

    /* ---- 分项得分 ---- */
    var metrics = [];
    var hasSkin = faceLike && skinRatio >= opt.minSkinRatio;
    if (!faceLike && skinRatio > 0) {
      warnings.push('未检测到可信的人脸肤色区域（可能是风景/食物等暖色画面），皮肤类维度已停用');
    }

    // 1) 磨皮去纹理
    var ratioScore = pw(textureRatio, [
      [0.05, 100], [0.12, 92], [0.22, 78], [0.32, 60],
      [0.45, 42], [0.60, 26], [0.80, 14], [1.00, 6], [1.50, 0]
    ]);
    var absScore = pw(skinTex.mean, [
      // 真实原片在 512px 工作分辨率下的皮肤微纹理实测 5.2~7.9（深/浅肤色都在此区间），
      // 参考美颜 s=1.0 降到 2.6~5.2，叠加往返强处理（extreme）后 1.4~3.4。
      [0.4, 100], [0.9, 96], [1.6, 88], [2.4, 76], [3.3, 60],
      [4.4, 44], [5.8, 26], [7.5, 14], [10.0, 5], [16.0, 0]
    ]);
    if (hasSkin) {
      metrics.push(metric('smoothing', (0.30 * ratioScore + 0.70 * absScore), {
        textureRatio: round1(textureRatio * 1000) / 1000,
        skinTexture: round1(skinTex.mean * 100) / 100,
        refTexture: round1(refTex.mean * 100) / 100
      }, '皮肤微纹理 ' + round1(skinTex.mean) + '（参考区 ' + round1(refTex.mean) +
         '，比值 ' + (Math.round(textureRatio * 100) / 100) + '）'));
    } else {
      metrics.push(unavailable('smoothing', '未检测到足够肤色区域'));
    }

    // 2) 美白提亮
    //    美白本质是「相对本人自然肤色的提亮」，没有原图参照，因此只用两种
    //    「漂白妆效」特征，并且都要求「又亮又没色」，避免把天生白皙/深肤色误判：
    //    W1 = 亮度抬升 × 彩度塌陷（亮度从 120 起算，彩度从 60 起算）
    //    W2 = 彩度绝对塌陷 × 亮度抬升（抓深肤色被漂白的情况）
    //    W3 = 高亮低彩度像素占比（抓过曝式漂白）
    var lumaLift = clamp((skinY - 120) / 80, 0, 1);
    var chromaGap = clamp((60 - skinSat) / 45, 0, 1);
    var w1 = lumaLift * chromaGap;
    var w2 = clamp((0.30 - skinSat / 255) / 0.30, 0, 1) * clamp((skinY - 110) / 70, 0, 1);
    var w1Score = pw(w1, [
      [0, 0], [0.05, 12], [0.12, 30], [0.22, 52], [0.35, 72], [0.50, 88], [0.70, 100]
    ]);
    var w2Score = pw(w2, [
      [0, 0], [0.05, 14], [0.12, 32], [0.22, 54], [0.35, 74], [0.50, 90], [0.70, 100]
    ]);
    var paleScore = pw(paleFrac, [
      [0, 0], [0.02, 12], [0.06, 38], [0.12, 62], [0.25, 85], [0.40, 95], [1, 100]
    ]);
    if (hasSkin) {
      metrics.push(metric('whitening', (0.45 * w1Score + 0.45 * w2Score + 0.10 * paleScore), {
        paleFrac: Math.round(paleFrac * 1000) / 1000,
        skinLuma: round1(skinY),
        skinChroma: round1(skinSat),
        whitenLift: Math.round(w1 * 1000) / 1000,
        whitenCollapse: Math.round(w2 * 1000) / 1000
      }, '肤色亮度 ' + round1(skinY) + '、彩度 ' + round1(skinSat) +
         '，提亮塌陷 ' + (Math.round(w1 * 100) / 100) + ' / ' + (Math.round(w2 * 100) / 100) +
         '，过曝白 ' + (Math.round(paleFrac * 1000) / 10) + '%'));
    } else {
      metrics.push(unavailable('whitening', '未检测到足够肤色区域'));
    }

    // 3) 肤色均匀
    var cStdScore = pw(chromaStd, [
      [0.5, 100], [1.5, 90], [2.5, 74], [4, 55], [6, 38], [9, 22], [13, 10], [20, 2], [30, 0]
    ]);
    var cGradScore = pw(chromaGrad, [
      [0.05, 100], [0.2, 88], [0.5, 70], [1.0, 50], [2.0, 32], [3.5, 16], [6, 4], [10, 0]
    ]);
    if (hasSkin) {
      metrics.push(metric('uniformity', (0.60 * cStdScore + 0.40 * cGradScore), {
        chromaStd: round1(chromaStd * 100) / 100,
        chromaGrad: round1(chromaGrad * 100) / 100
      }, '肤色色度标准差 ' + (Math.round(chromaStd * 100) / 100) +
         '，色度梯度 ' + (Math.round(chromaGrad * 100) / 100)));
    } else {
      metrics.push(unavailable('uniformity', '未检测到足够肤色区域'));
    }

    // 4) 去色低饱和
    var satScore = pw(satMean, [
      [0.03, 92], [0.06, 80], [0.10, 62], [0.16, 45],
      [0.24, 28], [0.34, 14], [0.50, 0]
    ]);
    var relSatScore = pw(skinRelSat, [
      [0.20, 95], [0.35, 80], [0.50, 62], [0.65, 45],
      [0.80, 28], [1.00, 12], [1.30, 0]
    ]);
    var chromaAvailable = satMean >= 0.025;
    if (!chromaAvailable) warnings.push('整图饱和度极低（可能是黑白照），去色维度仅供参考');
    metrics.push(metric('chroma',
      chromaAvailable ? (0.55 * satScore + 0.45 * relSatScore) : 50,
      {
        satMean: Math.round(satMean * 1000) / 1000,
        skinRelSat: Math.round(skinRelSat * 1000) / 1000
      },
      '整图饱和度 ' + (Math.round(satMean * 1000) / 10) + '%，皮肤/非皮肤饱和度比 ' +
      (Math.round(skinRelSat * 100) / 100),
      !chromaAvailable));

    // 5) 通透度压缩
    var rmsScore = pw(rmsContrast, [
      [0.04, 90], [0.08, 70], [0.12, 52], [0.16, 38],
      [0.21, 22], [0.27, 8], [0.35, 0]
    ]);
    var clipScore = pw(highLightFrac, [
      [0.005, 0], [0.02, 20], [0.05, 45], [0.10, 70], [0.20, 88], [0.35, 100]
    ]);
    metrics.push(metric('contrast', 0.7 * rmsScore + 0.3 * clipScore, {
      rmsContrast: Math.round(rmsContrast * 1000) / 1000,
      highLightFrac: Math.round(highLightFrac * 1000) / 1000,
      deepBlackFrac: Math.round(deepBlackFrac * 1000) / 1000
    }, '对比度 RMS ' + (Math.round(rmsContrast * 1000) / 1000) +
       '，高光溢出 ' + (Math.round(highLightFrac * 1000) / 10) + '%'));

    // 6) 锐化光晕（辅助指标，权重为 0，仅作为诊断信息输出）
    //    注意：在标准工作分辨率下 1~2px 的光晕会被重采样抹掉，实测对「是否美颜」
    //    区分度不足（真实原片也能到 5.2，过度锐化的样张也只有 8 左右），
    //    因此不参与打分，只在 debug 中保留。详见 docs/CALIBRATION.md。

    /* ---- 加权合成 ---- */
    var wsum = 0, acc = 0, dropped = 0;
    for (var m = 0; m < metrics.length; m++) {
      metrics[m].weight = opt.weights[metrics[m].key];
      metrics[m].weightPct = Math.round(opt.weights[metrics[m].key] * 100);
      if (!metrics[m].available) { dropped++; continue; }
      var wgt = opt.weights[metrics[m].key];
      acc += metrics[m].score * wgt;
      wsum += wgt;
    }
    if (wsum <= 0) return badReport(new Error('没有可用的分析维度'), opt);

    var baseScore = acc / wsum;
    var score = clamp(Math.round(50 + (baseScore - 50) * opt.sensitivity), 0, 100);
    var level = levelFor(score);

    /* ---- 置信度 ---- */
    var skinConf = clamp(skinRatio / 0.08, 0, 1);
    var sizeConf = clamp(Math.min(w, h) / 256, 0, 1);
    var confidence = 0.65 * skinConf + 0.35 * sizeConf;
    if (usedRelaxed) confidence *= 0.85;
    if (nativeLong < opt.minConfidentSide) confidence *= 0.80;
    if (!chromaAvailable) confidence *= 0.70;
    if (dropped) confidence *= 0.90;
    // 没有可信肤色区域时只有整图色度/对比可参考，置信度必须封顶，
    // 否则一张雪山/食物照也会显示「60% 置信度」。
    if (!hasSkin) confidence = Math.min(confidence, 0.40);
    confidence = clamp(confidence, 0.05, 0.99);

    if (!hasSkin) {
      warnings.push('未检测到足够肤色区域：本次仅依据整图色度/对比特征推断，结果仅供参考');
    }
    if (skinRatio > 0.75) {
      warnings.push('肤色区域超过 75%，可能是纯色/近景特写画面，结果偏差较大');
    }

    var report = {
      ok: true,
      version: VERSION,
      score: score,
      baseScore: Math.round(baseScore * 10) / 10,
      level: level.label,
      levelDesc: level.desc,
      confidence: Math.round(confidence * 100) / 100,
      skinRatio: Math.round(skinRatio * 1000) / 1000,
      skinPixels: skinPixels,
      width: nativeW,
      height: nativeH,
      workingWidth: w,
      workingHeight: h,
      resized: rs.resized,
      skinRelaxed: usedRelaxed,
      partial: !hasSkin,
      metrics: metrics,
      warnings: warnings,
      summary: '',
      debug: {
        textureRatio: round1(textureRatio * 1000) / 1000,
        skinTexture: round1(skinTex.mean * 100) / 100,
        refTexture: round1(refTex.mean * 100) / 100,
        skinLuma: round1(skinY),
        skinChroma: round1(skinSat),
        skinCr: round1(skinCr),
        skinCb: round1(skinCb),
        paleFrac: Math.round(paleFrac * 1000) / 1000,
        chromaStd: round1(chromaStd * 100) / 100,
        chromaGrad: round1(chromaGrad * 100) / 100,
        satMean: Math.round(satMean * 1000) / 1000,
        skinRelSat: Math.round(skinRelSat * 1000) / 1000,
        rmsContrast: Math.round(rmsContrast * 1000) / 1000,
        highLightFrac: Math.round(highLightFrac * 1000) / 1000,
        deepBlackFrac: Math.round(deepBlackFrac * 1000) / 1000,
        haloRatio: Math.round(haloRatio * 100) / 100,
        edgeThreshold: round1(p90),
        strongEdgeThreshold: round1(p98),
        skinRatioStrict: Math.round(skinRatioStrict * 1000) / 1000,
        skinRatioRelaxed: Math.round(skinRatioRelaxed * 1000) / 1000,
        faceLike: faceLike,
        largestSkinFrac: Math.round(largestFrac * 1000) / 1000,
        largestSkinAspect: Math.round(largestAspect * 100) / 100,
        largestSkinFill: Math.round(largestFill * 100) / 100,
        bboxDarkFrac: Math.round(bboxDarkFrac * 1000) / 1000,
        bboxYStd: Math.round(bboxYStd * 10) / 10
      }
    };
    report.summary = describe(report);
    return report;
  }

  function metric(key, score, raw, evidence, unavailableFlag) {
    return {
      key: key,
      label: METRIC_META[key].label,
      hint: METRIC_META[key].hint,
      score: Math.max(0, Math.min(100, Math.round(score))),
      weight: DEFAULT_WEIGHTS[key],
      weightPct: Math.round(DEFAULT_WEIGHTS[key] * 100),
      available: !unavailableFlag,
      raw: raw || {},
      evidence: evidence || ''
    };
  }

  function unavailable(key, why) {
    var m = emptyMetric(key, DEFAULT_WEIGHTS[key]);
    m.evidence = why;
    return m;
  }

  /** 生成一句中文结论，便于复制/展示 */
  function describe(report) {
    if (!report || !report.ok) return '无法判断：' + ((report && report.error) || '未知错误');
    var parts = [];
    if (report.partial) {
      parts.push('未检测到人脸肤色，以下仅为整图参考值：' + report.score + '/100。');
    } else {
      parts.push('美颜程度 ' + report.score + '/100（' + report.level + '）：' + report.levelDesc + '。');
    }
    var top = report.metrics
      .filter(function (m) { return m.available; })
      .slice()
      .sort(function (a, b) { return b.score - a.score; })
      .slice(0, 2)
      .map(function (m) { return m.label + ' ' + m.score; });
    if (top.length) parts.push('最明显的维度：' + top.join('、') + '。');
    parts.push('置信度 ' + Math.round(report.confidence * 100) + '%。');
    if (report.warnings && report.warnings.length) parts.push('注意：' + report.warnings.join('；') + '。');
    return parts.join('');
  }

  /* =======================================================================
   * 浏览器环境适配：把 <img> / ImageBitmap / Blob 变成像素再分析
   * ===================================================================== */

  function fitSize(w, h, maxSide) {
    var long = Math.max(w, h);
    if (!maxSide || long <= maxSide) return { w: w, h: h };
    var s = maxSide / long;
    return { w: Math.max(1, Math.round(w * s)), h: Math.max(1, Math.round(h * s)) };
  }

  function makeCanvas(w, h) {
    if (typeof OffscreenCanvas !== 'undefined') return new OffscreenCanvas(w, h);
    if (typeof document !== 'undefined') {
      var c = document.createElement('canvas');
      c.width = w; c.height = h;
      return c;
    }
    throw new Error('当前环境没有可用的 canvas');
  }

  function naturalSizeOf(source) {
    var w = source.naturalWidth || source.width || 0;
    var h = source.naturalHeight || source.height || 0;
    return { w: w, h: h };
  }

  /**
   * 从任意可绘制对象（HTMLImageElement / ImageBitmap / HTMLCanvasElement）取像素并分析。
   * 大图先在 canvas 上缩到工作分辨率（浏览器内是 GPU/原生实现，比 JS 快得多），
   * 引擎内部还会再做一次确定性归一，保证结果一致。
   */
  function analyzeSource(source, options) {
    var opt = normalizeOptions(options);
    try {
      var size = naturalSizeOf(source);
      if (!size.w || !size.h) throw new Error('无法获取图片尺寸');
      var target = fitSize(size.w, size.h, opt.maxSide);
      var canvas = makeCanvas(target.w, target.h);
      var ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) throw new Error('无法创建 2D 上下文');
      ctx.imageSmoothingEnabled = true;
      if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(source, 0, 0, target.w, target.h);
      var imgData = ctx.getImageData(0, 0, target.w, target.h);
      return analyze({ data: imgData.data, width: target.w, height: target.h }, options);
    } catch (err) {
      return badReport(err, opt);
    }
  }

  return {
    VERSION: VERSION,
    DEFAULTS: DEFAULTS,
    DEFAULT_WEIGHTS: DEFAULT_WEIGHTS,
    METRIC_META: METRIC_META,
    LEVELS: LEVELS,
    analyze: analyze,
    analyzeSource: analyzeSource,
    describe: describe,
    // 以下导出主要供测试与调参使用
    _internals: {
      pw: pw,
      clamp: clamp,
      resizeImageData: resizeImageData,
      buildPlanes: buildPlanes,
      skinMaskStrict: skinMaskStrict,
      skinMaskRelaxed: skinMaskRelaxed,
      localStdPlane: localStdPlane,
      gradientPlane: gradientPlane,
      laplacianPlane: laplacianPlane
    }
  };
});
