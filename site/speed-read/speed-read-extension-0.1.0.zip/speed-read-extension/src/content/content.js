/**
 * 一目十行 · 内容脚本
 * ---------------------------------------------------------------------------
 * 屏幕上永远只有 3 行：α 阿尔法 / β 贝塔 / γ 人说最多。多一个字都不给。
 *
 * 自动更新触发链（用户核心诉求：页面一变就重算）
 *   ① MutationObserver（childList + characterData + subtree）→ 静默 debounceMs 后重算
 *   ② SPA 路由：轮询 location.href（1.2s，只看字符串，几乎零成本）+ popstate/hashchange
 *      + 尽力 patch history.pushState/replaceState
 *   ③ 标签页切回前台（visibilitychange）时核对一次
 *   ④ 兜底轮询：每 pollMs 比对一次内容指纹，救那些没有 DOM 变化事件的轮询式页面
 *   ⑤ 手动：面板 ⟳ / 弹窗按钮 / Alt+Shift+R
 *
 * 省钱与省时的三道闸门（都在后台 Service Worker 里执行）：
 *   内容指纹未变 → 直接命中缓存不发请求；并发去重；同标签最小调用间隔。
 *
 * 安全：模型输出一律用 textContent 写入，绝不 innerHTML，避免网页上的注入面。
 */
(function () {
  'use strict';

  if (window.__SR_CONTENT_LOADED__) return;
  window.__SR_CONTENT_LOADED__ = true;
  if (window.top !== window) return; // 只在主框架工作

  var HOST_ID = 'speedread-host';
  var state = {
    cfg: null,
    host: null,
    root: null,
    parts: null,
    seq: 0,
    running: false,
    queued: null,
    debounceTimer: null,
    pollTimer: null,
    urlTimer: null,
    items: [],
    source: '',
    status: 'idle',
    error: null,
    warnings: [],
    meta: null,
    lastUrl: location.href,
    lastFingerprint: null,
    lastFullChars: 0,
    lastHeadSample: '',
    lastAttemptFp: null,
    lastAttemptAt: 0,
    lastAttemptOk: false,
    expanded: {},
    dead: false,
    styleMode: '',
    bootError: null
  };

  /* =======================================================================
   * 启动失败也绝不静默
   * -----------------------------------------------------------------------
   * 最坏的情况不是「显示错误」，而是「什么都不显示」—— 用户无法区分
   * 「插件没生效」「页面不支持」「正文太短」还是「代码崩了」。
   * 所以任何启动失败都要：① 控制台里有明确原因 ② 页面上有一块最小的可见提示
   * ③ 弹窗的「诊断」能读到这条原因（通过 SR_PING.bootError）。
   * ===================================================================== */

  function noteBootFailure(message) {
    if (state.bootError === message) return;
    state.bootError = message;
    try { window.__SR_BOOT_ERROR__ = message; } catch (e) { /* ignore */ }
    try { console.error('[一目十行] ' + message); } catch (e) { /* ignore */ }
    if (state.host) return; // 面板已经挂上了，错误会显示在面板里
    var box = document.createElement('div');
    box.setAttribute('data-sr-root', '1');
    box.textContent = '一目十行：' + message;
    box.style.cssText = 'all:initial;position:fixed;z-index:2147483600;top:16px;right:16px;max-width:340px;' +
      'display:block;padding:9px 12px;border-radius:10px;background:#161b22;color:#e6edf3;border:1px solid #f85149;' +
      'font:13px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC",system-ui,sans-serif;' +
      'box-shadow:0 8px 24px rgba(0,0,0,.45);';
    try { document.documentElement.appendChild(box); } catch (e) { /* ignore */ }
  }

  var Core = window.SpeedReadCore;
  var Dom = window.SpeedReadDom;
  var Settings = window.SpeedReadSettings;
  var CSS = window.__SR_PANEL_CSS;

  if (!/^https?:$/.test(location.protocol)) {
    // 非 http(s) 页面本来就注入不进来，静默退出即可
    return;
  }
  if (!Core || !Dom || !Settings || !CSS) {
    noteBootFailure('依赖模块没加载齐（Core/Dom/Settings/CSS 缺失），扩展无法工作。请到 chrome://extensions 重新加载扩展。');
    return;
  }

  /* =======================================================================
   * 工具
   * ===================================================================== */

  function send(message) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage(message, function (res) {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          resolve(res);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  function isContextDead(err) {
    return !!(err && /Extension context invalidated|receiving end does not exist|message port closed/i.test(String(err.message || err)));
  }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function fmtMs(ms) {
    if (!ms && ms !== 0) return '';
    return ms < 1000 ? ms + 'ms' : (ms / 1000).toFixed(1) + 's';
  }

  function collapse(text) {
    return String(text || '').replace(/\s+/g, ' ').trim();
  }

  /* =======================================================================
   * 抽取 + 压缩
   * ===================================================================== */

  function metaDescription() {
    try {
      var node = document.querySelector('meta[name="description"], meta[property="og:description"]');
      return node ? String(node.getAttribute('content') || '') : '';
    } catch (e) {
      return '';
    }
  }

  function extract() {
    var body = document.body || document.documentElement;
    var out = Dom.extractPage({
      root: document.documentElement,
      title: document.title,
      description: metaDescription(),
      url: location.href,
      maxBlocks: 1200
    });
    if (!out.blocks.length && body) {
      out = Dom.extractPage({ root: body, title: document.title, description: metaDescription(), url: location.href });
    }
    return out;
  }

  function buildPayload() {
    var cfg = state.cfg;
    var extracted = extract();
    var packed = Core.budgetBlocks(extracted.blocks, { maxChars: cfg.maxChars });
    var text = packed.text || extracted.text || '';
    var terms = Core.topTerms(text, { limit: 14, minCount: 2 });
    var headSample = collapse(text).slice(0, 160);
    return {
      url: location.href,
      title: document.title,
      text: text,
      terms: terms,
      preCompressed: {
        text: text,
        chars: text.length,
        truncated: !!packed.truncated,
        omittedChars: packed.omittedChars || 0
      },
      fingerprint: Core.contentFingerprint({ url: location.href, title: document.title, text: text }),
      stats: {
        fullChars: extracted.chars,
        blocks: extracted.blocks.length,
        container: extracted.container
      },
      headSample: headSample
    };
  }

  /* =======================================================================
   * 面板构建
   * ===================================================================== */

  /**
   * 注入面板样式。
   * 优先用 constructible stylesheet（adoptedStyleSheets）：它不走页面的「内联样式」解析路径，
   * 因此在 GitHub 这类 `style-src 'none'` 的严格 CSP 站点上也不会被拦；
   * 老浏览器退回 <style> 元素（功能不受影响，最多在严格 CSP 站点上丢失外观）。
   */
  function applyStyles(shadow, css) {
    try {
      if (typeof CSSStyleSheet === 'function' && 'adoptedStyleSheets' in shadow) {
        var sheet = new CSSStyleSheet();
        sheet.replaceSync(css);
        shadow.adoptedStyleSheets = [sheet];
        return 'adoptedStyleSheets';
      }
    } catch (e) { /* 落到 <style> */ }
    var style = document.createElement('style');
    style.textContent = css;
    shadow.appendChild(style);
    return 'style-element';
  }

  function mount() {
    var host = document.createElement('div');
    host.id = HOST_ID;
    host.setAttribute('data-sr-root', '1');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483600;top:16px;right:16px;display:block;';
    var shadow = host.attachShadow({ mode: 'open' });

    state.styleMode = applyStyles(shadow, CSS);

    var panel = el('div', 'sr-panel');
    panel.setAttribute('data-theme', 'dark');

    /* —— 标题栏 —— */
    var bar = el('div', 'sr-bar');
    var dot = el('span', 'sr-dot');
    dot.setAttribute('data-s', 'idle');
    var brand = el('span', 'sr-brand', '一目十行');
    var status = el('span', 'sr-status', '待命');
    var tools = el('div', 'sr-tools');
    var btnRefresh = el('button', 'sr-btn', '⟳');
    btnRefresh.title = '立刻重新压缩（Alt+Shift+R）';
    var btnCopy = el('button', 'sr-btn', '⧉');
    btnCopy.title = '复制这 3 条';
    var btnConfig = el('button', 'sr-btn', '⚙');
    btnConfig.title = '打开设置';
    var btnFold = el('button', 'sr-btn', '–');
    btnFold.title = '收起/展开';
    var btnClose = el('button', 'sr-btn', '✕');
    btnClose.title = '关闭面板（Alt+Shift+S 可再打开）';
    tools.appendChild(btnRefresh);
    tools.appendChild(btnCopy);
    tools.appendChild(btnConfig);
    tools.appendChild(btnFold);
    tools.appendChild(btnClose);
    bar.appendChild(dot);
    bar.appendChild(brand);
    bar.appendChild(status);
    bar.appendChild(tools);

    /* —— 主体 —— */
    var body = el('div', 'sr-body');
    var rows = el('ul', 'sr-rows');
    var rowRefs = {};
    Core.ITEM_KEYS.forEach(function (key) {
      var meta = Core.ITEM_META[key];
      var li = el('li', 'sr-row');
      li.setAttribute('data-k', key);
      var badge = el('span', 'sr-badge', meta.badge);
      badge.setAttribute('data-k', key);
      var main = el('div', 'sr-main');
      var text = el('div', 'sr-text', '');
      var ev = el('div', 'sr-ev', '');
      main.appendChild(text);
      main.appendChild(ev);
      li.appendChild(badge);
      li.appendChild(main);
      li.title = meta.label + '：' + meta.hint;
      li.addEventListener('click', function () {
        state.expanded[key] = !state.expanded[key];
        li.setAttribute('data-expanded', state.expanded[key] ? '1' : '0');
      });
      rows.appendChild(li);
      rowRefs[key] = { li: li, text: text, ev: ev };
    });

    var foot = el('div', 'sr-foot');

    var msg = el('div', 'sr-msg');
    var msgTitle = el('div', 'sr-msg-title', '');
    var msgHint = el('div', 'sr-msg-hint', '');
    var msgActions = el('div', 'sr-msg-actions');
    msg.appendChild(msgTitle);
    msg.appendChild(msgHint);
    msg.appendChild(msgActions);

    var skel = el('div', 'sr-skel');
    for (var i = 0; i < 3; i++) skel.appendChild(el('div', 'sr-skel-i'));

    body.appendChild(skel);
    body.appendChild(rows);
    body.appendChild(msg);
    body.appendChild(foot);

    panel.appendChild(bar);
    panel.appendChild(body);
    shadow.appendChild(panel);
    document.documentElement.appendChild(host);

    state.host = host;
    state.root = panel;
    state.parts = {
      panel: panel, dot: dot, status: status, rows: rows, foot: foot,
      msg: msg, msgTitle: msgTitle, msgHint: msgHint, msgActions: msgActions,
      skel: skel, rowRefs: rowRefs,
      btnRefresh: btnRefresh, btnCopy: btnCopy, btnConfig: btnConfig, btnFold: btnFold, btnClose: btnClose,
      bar: bar
    };

    btnRefresh.addEventListener('click', function (e) { e.stopPropagation(); run('manual', { force: true }); });
    btnCopy.addEventListener('click', function (e) { e.stopPropagation(); copyAll(); });
    btnConfig.addEventListener('click', function (e) { e.stopPropagation(); openOptions(); });
    btnFold.addEventListener('click', function (e) { e.stopPropagation(); setCollapsed(!state.cfg.panel.collapsed); });
    btnClose.addEventListener('click', function (e) { e.stopPropagation(); setHidden(true); });
    bar.addEventListener('pointerdown', startDrag);

    applyPanelPrefs();
    render();
  }

  function openOptions() {
    try { chrome.runtime.sendMessage({ type: 'SR_OPEN_OPTIONS' }); } catch (e) { /* ignore */ }
    try { chrome.runtime.openOptionsPage && chrome.runtime.openOptionsPage(); } catch (e2) { /* ignore */ }
  }

  function applyPanelPrefs() {
    var p = state.cfg.panel;
    var host = state.host;
    var panel = state.parts.panel;
    host.style.width = p.width + 'px';
    panel.style.setProperty('--sr-fs', p.fontSize + 'px');
    panel.style.opacity = String(p.opacity);
    panel.setAttribute('data-theme', p.theme);
    panel.setAttribute('data-hidden', p.hidden ? '1' : '0');
    panel.classList.toggle('sr-collapsed', !!p.collapsed);
    state.parts.btnFold.textContent = p.collapsed ? '+' : '–';
    // 位置：用户拖动过就用绝对坐标，否则贴角
    if (p.x != null && p.y != null) {
      host.style.left = p.x + 'px';
      host.style.top = p.y + 'px';
      host.style.right = 'auto';
      host.style.bottom = 'auto';
    } else {
      host.style.left = p.corner.indexOf('left') > 0 ? '16px' : 'auto';
      host.style.top = p.corner.indexOf('top') === 0 ? '16px' : 'auto';
      host.style.bottom = p.corner.indexOf('bottom') === 0 ? '16px' : 'auto';
      host.style.right = p.corner.indexOf('right') > 0 ? '16px' : 'auto';
    }
  }

  function savePanel(patch) {
    state.cfg.panel = Settings.deepMerge(state.cfg.panel, patch);
    applyPanelPrefs();
    try {
      var store = Settings.makeStore(chrome.storage.local);
      Settings.savePanel(store, state.cfg.panel);
    } catch (e) { /* ignore */ }
  }

  function setCollapsed(v) {
    savePanel({ collapsed: !!v });
  }

  function setHidden(v) {
    savePanel({ hidden: !!v });
    if (!v) run('reveal', { force: false });
  }

  /* =======================================================================
   * 拖动
   * ===================================================================== */

  function startDrag(e) {
    if (e.button !== 0) return;
    if (e.target && e.target.closest && e.target.closest('.sr-btn')) return;
    var host = state.host;
    var rect = host.getBoundingClientRect();
    var startX = e.clientX;
    var startY = e.clientY;
    var originLeft = rect.left;
    var originTop = rect.top;
    var moved = false;

    function onMove(ev) {
      var dx = ev.clientX - startX;
      var dy = ev.clientY - startY;
      if (!moved && Math.abs(dx) + Math.abs(dy) < 4) return;
      moved = true;
      var w = host.offsetWidth || 400;
      var h = host.offsetHeight || 120;
      var left = Math.min(Math.max(0, originLeft + dx), Math.max(0, window.innerWidth - w));
      var top = Math.min(Math.max(0, originTop + dy), Math.max(0, window.innerHeight - h));
      host.style.left = left + 'px';
      host.style.top = top + 'px';
      host.style.right = 'auto';
      host.style.bottom = 'auto';
    }

    function onUp() {
      document.removeEventListener('pointermove', onMove, true);
      document.removeEventListener('pointerup', onUp, true);
      if (moved) {
        savePanel({
          x: Math.round(parseFloat(host.style.left) || 0),
          y: Math.round(parseFloat(host.style.top) || 0)
        });
      }
    }

    document.addEventListener('pointermove', onMove, true);
    document.addEventListener('pointerup', onUp, true);
  }

  /* =======================================================================
   * 渲染
   * ===================================================================== */

  function render() {
    if (state.dead) return;
    var p = state.parts;
    var hasItems = state.items && state.items.length === 3;
    var s = state.status;

    p.skel.style.display = s === 'loading' && !hasItems ? 'grid' : 'none';
    p.rows.style.display = hasItems ? 'block' : 'none';
    p.msg.style.display = (s === 'error' || s === 'empty' || (s === 'idle' && !hasItems)) ? 'block' : 'none';
    p.foot.style.display = hasItems && !(state.cfg && state.cfg.panel.showFoot === false) ? 'flex' : 'none';

    p.dot.setAttribute('data-s', s === 'ok' ? (state.source === 'llm' ? 'ok' : 'local') : s === 'loading' ? 'loading' : s === 'error' ? 'error' : 'idle');
    p.status.textContent = statusText();

    if (hasItems) {
      var showEvidence = !(state.cfg && state.cfg.panel.showEvidence === false);
      state.items.forEach(function (item) {
        var ref = p.rowRefs[item.key];
        if (!ref) return;
        ref.text.textContent = item.text || '（空）';
        ref.text.title = item.text || '';
        var evidence = (item.evidence || []).join(' · ');
        ref.ev.textContent = evidence ? '高频：' + evidence : '';
        ref.ev.style.display = showEvidence && evidence ? 'block' : 'none';
        ref.li.setAttribute('data-expanded', state.expanded[item.key] ? '1' : '0');
        ref.li.setAttribute('data-duplicate', item.duplicate ? '1' : '0');
      });
      renderFoot();
    } else {
      renderMessage();
    }
  }

  function statusText() {
    var m = state.meta || {};
    switch (state.status) {
      case 'loading':
        return '正在压缩…';
      case 'ok':
        return (state.source === 'llm' ? 'AI 摘要' : '本地兜底') + (m.cached ? ' · 缓存' : '') + (m.ms ? ' · ' + fmtMs(m.ms) : '');
      case 'throttled':
        return '页面变化太频繁，' + Math.ceil((state.retryAfterMs || 0) / 1000) + 's 后重算';
      case 'error':
        return (state.error && state.error.code) || '出错';
      case 'empty':
        return '正文太短';
      default:
        return '待命';
    }
  }

  function renderFoot() {
    var p = state.parts;
    var m = state.meta || {};
    while (p.foot.firstChild) p.foot.removeChild(p.foot.firstChild);

    function tag(text, warn) {
      var span = el('span', 'sr-tag', text);
      if (warn) span.setAttribute('data-warn', '1');
      return span;
    }

    // 全部用 textContent 写入：模型输出与服务端字符串永远不会被当成 HTML 解析
    p.foot.appendChild(tag(state.source === 'llm' ? 'AI' : '本地兜底'));
    if (m.cached) p.foot.appendChild(tag('缓存'));
    if (m.model) p.foot.appendChild(tag(String(m.model).slice(0, 34)));
    if (m.inputChars) {
      p.foot.appendChild(tag('正文 ' + m.inputChars + ' 字' + (m.compressed ? '（省略 ' + (m.omittedChars || 0) + '）' : '')));
    }
    if (m.ms) p.foot.appendChild(tag(fmtMs(m.ms)));
    var warns = state.warnings || [];
    if (warns.length) p.foot.appendChild(tag('⚠ ' + String(warns[0]).slice(0, 40), true));
  }

  function renderMessage() {
    var p = state.parts;
    var cfgErr = state.error;
    if (state.status === 'empty') {
      p.msgTitle.textContent = '这一页没有可压缩的正文';
      p.msgHint.textContent = cfgErr && cfgErr.message ? cfgErr.message : '正文太短或主要是导航/图片。';
      p.msgActions.textContent = '';
      addAction(p.msgActions, '重试', function () { run('manual', { force: true }); });
      return;
    }
    if (state.status === 'error') {
      p.msgTitle.textContent = '没能生成 3 条';
      p.msgHint.textContent = [cfgErr && cfgErr.message, cfgErr && cfgErr.hint].filter(Boolean).join(' ') || '未知错误。';
      p.msgActions.textContent = '';
      addAction(p.msgActions, '重试', function () { run('manual', { force: true }); });
      addAction(p.msgActions, '打开设置', function () { openOptions(); });
      return;
    }
    p.msgTitle.textContent = '正在准备…';
    p.msgHint.textContent = '读取正文后立刻给你 3 条。';
    p.msgActions.textContent = '';
  }

  function addAction(parent, label, onClick) {
    var btn = el('button', 'sr-link', label);
    btn.addEventListener('click', function (e) { e.stopPropagation(); onClick(); });
    parent.appendChild(btn);
  }

  /* =======================================================================
   * 运行主流程
   * ===================================================================== */

  function setStatus(status, extra) {
    state.status = status;
    if (extra) {
      for (var k in extra) if (Object.prototype.hasOwnProperty.call(extra, k)) state[k] = extra[k];
    }
    render();
  }

  function significantChange(payload) {
    var full = payload.stats.fullChars || payload.text.length;
    if (state.lastFullChars === 0) return true;
    var delta = Math.abs(full - state.lastFullChars);
    var ratio = state.lastFullChars ? delta / state.lastFullChars : 1;
    if (delta >= state.cfg.minDeltaChars) return true;
    if (ratio >= state.cfg.minDeltaRatio) return true;
    // 长度没变但开头就变了（同长度原位改写），也算真变化
    if (state.lastHeadSample && payload.headSample && payload.headSample !== state.lastHeadSample) return true;
    return false;
  }

  async function run(reason, opts) {
    opts = opts || {};
    var cfg = state.cfg;
    if (!cfg || state.dead) return;
    if (cfg.panel.hidden && !opts.force) return;
    if (!cfg.autoUpdate && !opts.force && reason !== 'reveal' && reason !== 'init') return;

    if (state.running) {
      state.queued = { reason: reason, opts: opts };
      return;
    }

    var payload;
    try {
      payload = buildPayload();
    } catch (e) {
      setStatus('error', { error: { code: 'EXTRACT', message: '正文抽取失败：' + e.message, hint: '' } });
      return;
    }

    if (!payload.text || (payload.stats.fullChars || 0) < cfg.skipTinyChars) {
      state.lastFullChars = payload.stats.fullChars || 0;
      state.lastFingerprint = payload.fingerprint;
      setStatus('empty', { error: { message: '正文只有 ' + (payload.stats.fullChars || 0) + ' 字，低于阈值 ' + cfg.skipTinyChars + '。' } });
      return;
    }

    // 内容没变 → 连后台都不用打扰
    if (!opts.force && payload.fingerprint === state.lastFingerprint) {
      return;
    }
    // 变化量太小 → 视为噪声（时钟、阅读数、广告轮播）
    if (!opts.force && !significantChange(payload)) {
      state.lastFingerprint = payload.fingerprint;
      return;
    }
    // 同一个内容刚刚失败过 → 自动触发不重试，等 60s 或用户手动
    if (!opts.force && state.lastAttemptFp === payload.fingerprint && !state.lastAttemptOk &&
      Date.now() - state.lastAttemptAt < 60000) {
      return;
    }

    state.running = true;
    state.lastFingerprint = payload.fingerprint;
    state.lastFullChars = payload.stats.fullChars || payload.text.length;
    state.lastHeadSample = payload.headSample;
    state.lastAttemptFp = payload.fingerprint;
    state.lastAttemptAt = Date.now();
    if (!state.items.length) setStatus('loading');

    var seq = ++state.seq;
    var res;
    try {
      res = await send({
        type: 'SR_SUMMARIZE',
        force: !!opts.force,
        reason: reason,
        input: {
          url: payload.url,
          title: payload.title,
          text: payload.text,
          terms: payload.terms,
          preCompressed: payload.preCompressed,
          fingerprint: payload.fingerprint
        }
      });
    } catch (err) {
      state.running = false;
      if (isContextDead(err)) {
        state.dead = true;
        setStatus('error', { error: { code: 'RELOAD', message: '扩展已更新，刷新页面后生效。', hint: '' } });
        return;
      }
      state.lastAttemptOk = false;
      setStatus('error', { error: { code: 'IPC', message: '和后台通信失败：' + err.message, hint: '试试刷新页面。' } });
      return;
    }
    state.running = false;

    if (seq !== state.seq) return; // 已有更新的请求在飞，丢弃旧结果

    if (res && res.throttled) {
      state.retryAfterMs = res.retryAfterMs || 3000;
      if (!state.items.length) setStatus('throttled');
      else render();
      clearTimeout(state.throttleTimer);
      state.throttleTimer = setTimeout(function () { run('throttle', { force: false }); }, state.retryAfterMs + 250);
      return;
    }

    if (!res) {
      state.lastAttemptOk = false;
      setStatus('error', { error: { code: 'EMPTY', message: '后台没有返回结果。', hint: '' } });
      return;
    }

    if (!res.ok) {
      state.lastAttemptOk = false;
      state.items = [];
      state.warnings = res.warnings || [];
      state.source = 'none';
      state.meta = res.meta || null;
      setStatus('error', { error: res.error || { code: 'UNKNOWN', message: '未知错误', hint: '' } });
      return;
    }

    state.lastAttemptOk = true;
    state.items = res.items || [];
    state.source = res.source || 'llm';
    state.warnings = res.warnings || [];
    state.meta = res.meta || {};
    state.error = res.error || null;
    setStatus('ok');

    // 后台返回的是本地兜底，但配置里其实有 Key → 说明调用失败，把原因挂在状态上
    if (res.error && state.source === 'local') {
      state.parts.status.title = res.error.message + ' ' + (res.error.hint || '');
    }
  }

  function scheduleRun(reason, opts) {
    opts = opts || {};
    if (state.dead) return;
    clearTimeout(state.debounceTimer);
    var delay = opts.immediate ? 0 : (state.cfg ? state.cfg.debounceMs : 1500);
    state.debounceTimer = setTimeout(function () { run(reason, opts); }, delay);
  }

  /* =======================================================================
   * 自动更新的四路触发
   * ===================================================================== */

  function fromSelf(node) {
    var cur = node;
    while (cur) {
      if (cur === state.host) return true;
      if (cur.nodeType === 1 && cur.getAttribute && cur.getAttribute('data-sr-root') != null) return true;
      cur = cur.parentNode;
    }
    return false;
  }

  function startObservers() {
    // ① DOM 变化
    try {
      var observer = new MutationObserver(function (records) {
        if (state.dead) return;
        for (var i = 0; i < records.length; i++) {
          if (fromSelf(records[i].target)) continue;
          scheduleRun('mutation');
          return;
        }
      });
      observer.observe(document.documentElement, {
        childList: true, subtree: true, characterData: true, attributes: false
      });
    } catch (e) { /* ignore */ }

    // ② SPA 路由：轮询 href 是最可靠的信号（pushState 在隔离世界里可能 patch 不到）
    state.urlTimer = setInterval(function () {
      if (state.dead) return;
      if (location.href !== state.lastUrl) {
        state.lastUrl = location.href;
        resetForNewRoute();
        scheduleRun('spa', { immediate: true });
      }
    }, 1200);
    try {
      var push = history.pushState;
      var replace = history.replaceState;
      var onRoute = function () {
        if (location.href !== state.lastUrl) {
          state.lastUrl = location.href;
          resetForNewRoute();
          scheduleRun('spa', { immediate: true });
        }
      };
      history.pushState = function () { var r = push.apply(this, arguments); onRoute(); return r; };
      history.replaceState = function () { var r = replace.apply(this, arguments); onRoute(); return r; };
      window.addEventListener('popstate', onRoute);
      window.addEventListener('hashchange', onRoute);
    } catch (e) { /* ignore */ }

    // ③ 切回前台
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'visible') scheduleRun('visible');
    });

    // ④ 兜底轮询
    restartPolling();

    // ⑤ 可选：滚动结束后再核一次（懒加载站点）
    if (state.cfg.dirtyOnScroll) {
      window.addEventListener('scroll', function () { scheduleRun('scroll'); }, { passive: true });
    }
  }

  function resetForNewRoute() {
    state.lastFingerprint = null;
    state.lastFullChars = 0;
    state.lastHeadSample = '';
    state.lastAttemptFp = null;
    state.lastAttemptOk = false;
    // 换了路由，旧内容不再适用
    state.items = [];
    state.meta = null;
    state.warnings = [];
    setStatus('loading');
  }

  function restartPolling() {
    clearInterval(state.pollTimer);
    var cfg = state.cfg;
    if (!cfg || !cfg.autoUpdate) return;
    state.pollTimer = setInterval(function () {
      if (state.dead || document.visibilityState !== 'visible') return;
      if (state.cfg.panel.hidden || state.running) return;
      var payload;
      try { payload = buildPayload(); } catch (e) { return; }
      if (payload.fingerprint && payload.fingerprint !== state.lastFingerprint) scheduleRun('poll');
    }, cfg.pollMs);
  }

  /* =======================================================================
   * 复制
   * ===================================================================== */

  function summaryText() {
    var lines = ['一目十行 · ' + (document.title || location.host)];
    state.items.forEach(function (item) {
      lines.push(item.badge + ' ' + item.label + '：' + item.text);
    });
    if (state.source === 'local') lines.push('（本地兜底摘要，非 AI）');
    lines.push(location.href);
    return lines.join('\n');
  }

  function copyAll() {
    var text = summaryText();
    function done(ok) {
      var btn = state.parts.btnCopy;
      btn.textContent = ok ? '✓' : '✕';
      setTimeout(function () { btn.textContent = '⧉'; }, 1200);
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { done(true); }, function () { fallbackCopy(text, done); });
        return;
      }
    } catch (e) { /* 落到兜底 */ }
    fallbackCopy(text, done);
  }

  function fallbackCopy(text, done) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('data-sr-skip', '1');
      ta.style.cssText = 'position:fixed;left:-9999px;top:0;';
      document.documentElement.appendChild(ta);
      ta.select();
      var ok = document.execCommand('copy');
      ta.remove();
      done(!!ok);
    } catch (e) {
      done(false);
    }
  }

  /* =======================================================================
   * 启动
   * ===================================================================== */

  function applySettings(publicSettings) {
    var previous = state.cfg;
    state.cfg = Settings.mergeSettings(Object.assign({}, publicSettings, {
      // panel 与 blacklist 内容脚本读本地存储拿，公网设置里没有
      panel: state.cfg ? state.cfg.panel : Settings.DEFAULTS.panel,
      blacklist: state.cfg ? state.cfg.blacklist : []
    }));
    if (!previous) return;
    if (previous.autoUpdate !== state.cfg.autoUpdate || previous.pollMs !== state.cfg.pollMs ||
      previous.debounceMs !== state.cfg.debounceMs) {
      restartPolling();
    }
  }

  async function boot() {
    // 只从本地存储取「面板偏好 + 黑名单」；API Key 只存在于 Service Worker，内容脚本碰不到
    var store = Settings.makeStore(chrome.storage.local);
    var raw = await store.get(Settings.STORAGE_KEY, null);
    var panel = await store.get(Settings.PANEL_KEY, null);
    var local = Settings.mergeSettings({
      blacklist: (raw && raw.blacklist) || [],
      panel: panel || {}
    });
    state.cfg = local;

    if (Settings.isBlacklisted(location.href, local.blacklist)) {
      state.cfg = null;
      return;
    }

    mount();

    // 给工具栏一个「本页已激活」的信号，用户不用猜扩展有没有生效
    try { send({ type: 'SR_HELLO' }); } catch (e) { /* ignore */ }

    try {
      var res = await send({ type: 'SR_GET_PUBLIC_SETTINGS' });
      if (res && res.ok) applySettings(res.settings);
    } catch (err) {
      if (isContextDead(err)) { state.dead = true; return; }
    }

    if (Settings.isBlacklisted(location.href, state.cfg.blacklist)) {
      state.host.remove();
      state.dead = true;
      return;
    }

    startObservers();
    run('init', { force: false });

    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      switch (msg && msg.type) {
        case 'SR_TOGGLE_PANEL':
          setHidden(!state.cfg.panel.hidden);
          sendResponse({ ok: true, hidden: state.cfg.panel.hidden });
          break;
        case 'SR_FORCE_REFRESH':
          run('manual', { force: true });
          sendResponse({ ok: true });
          break;
        case 'SR_SETTINGS_CHANGED':
          syncSettings().then(function () {
            restartPolling();
            run('settings', { force: true });
          });
          sendResponse({ ok: true });
          break;
        case 'SR_PING':
          sendResponse({
            ok: true,
            status: state.status,
            items: state.items.length,
            source: state.source,
            bootError: state.bootError || null,
            hidden: !!(state.cfg && state.cfg.panel.hidden),
            styleMode: state.styleMode,
            url: location.href
          });
          break;
        default:
          sendResponse({ ok: false });
      }
      return true;
    });

    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local') return;
      if (changes[Settings.PANEL_KEY]) {
        state.cfg.panel = Settings.deepMerge(Settings.DEFAULTS.panel, changes[Settings.PANEL_KEY].newValue || {});
        applyPanelPrefs();
        render();
      }
      if (changes[Settings.STORAGE_KEY]) {
        syncSettings().then(function () { restartPolling(); });
      }
    });
  }

  async function syncSettings() {
    try {
      var res = await send({ type: 'SR_GET_PUBLIC_SETTINGS' });
      if (res && res.ok) applySettings(res.settings);
    } catch (e) { /* ignore */ }
  }

  function start() {
    // boot 是 async，所以同步抛错也会变成 rejected promise；统一在这里兜住，
    // 保证任何启动失败都有可见提示 + 可查询的原因，绝不静默什么都不显示。
    var pending;
    try {
      pending = boot();
    } catch (err) {
      noteBootFailure('初始化失败：' + ((err && err.message) || err));
      return;
    }
    if (pending && typeof pending.catch === 'function') {
      pending.catch(function (err) {
        noteBootFailure('初始化失败：' + ((err && err.message) || err));
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
