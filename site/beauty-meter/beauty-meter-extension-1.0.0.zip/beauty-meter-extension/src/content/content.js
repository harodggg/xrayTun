/**
 * 素颜镜 · 美颜程度检测 —— 页面内容脚本
 * ---------------------------------------------------------------------------
 * 见 docs/SPEC.md §4/§5：
 *   · Shadow DOM（attachShadow）隔离样式，页面 CSS 影响不到角标与报告卡片；
 *   · 悬停 <img> hoverDelay 毫秒后分析（默认 300ms），只处理 naturalWidth /
 *     naturalHeight >= minImageSize 且不是 SVG 的图片；
 *   · 同 src 结果 LRU 缓存 50 条；点击角标展开完整报告卡片；
 *   · 响应后台转发来的 SHOW_REPORT（右键菜单）与弹窗发来的 FIND_LARGEST_IMAGE；
 *   · 站点白名单内不工作；扩展被重载后（Extension context invalidated）不抛异常。
 *
 * 分析请求一律发给后台（ANALYZE_URL），由后台 fetch → OffscreenCanvas 取像素，
 * 这样跨域图片也不会污染页面 canvas；blob: 等后台取不到的地址再退回页面 canvas。
 */
(function () {
  'use strict';

  if (window.__beautyMeterContentBooted) return;
  window.__beautyMeterContentBooted = true;

  var HOST_TAG = 'beauty-meter-root';
  var CONTENT_CSS_PATH = 'src/content/content.css';
  var CACHE_LIMIT = 50;
  var CARD_WIDTH = 340;

  var FALLBACK_SETTINGS = {
    hoverEnabled: true,
    minImageSize: 160,
    hoverDelay: 300,
    sensitivity: 1.0,
    preset: 'balanced',
    customWeights: null,
    showDebug: false,
    siteWhitelist: []
  };

  var settings = copySettings(FALLBACK_SETTINGS);
  var whitelistHosts = [];   // 预解析的白名单主机名（避免每次 pointerover 都解析 URL）
  var contextDead = false;
  var cache = new Map();      // src -> {ok, report}
  var inflight = new Map();   // src -> [callback]
  var ui = null;
  var hoverTimer = null;
  var hoverImg = null;
  var badgeHideTimer = null;
  var hideRequested = false;
  var layoutFrame = null;
  var anchorImg = null;
  var cardOpen = false;
  var lastCardAnchor = null;
  var lastCardPlacement = 'anchor';
  var lastCardRes = null;   // 当前卡片展示的结果，供「复制结论」使用

  var LEVEL_SLUG = {
    '原生': 'native',
    '轻度美颜': 'mild',
    '中度美颜': 'moderate',
    '重度美颜': 'heavy',
    '极致美颜': 'extreme'
  };

  /* =====================================================================
   * 基础工具
   * =================================================================== */

  function copySettings(src) {
    return {
      hoverEnabled: !!src.hoverEnabled,
      minImageSize: Number(src.minImageSize) || FALLBACK_SETTINGS.minImageSize,
      hoverDelay: Number(src.hoverDelay),
      sensitivity: Number(src.sensitivity) || 1,
      preset: src.preset || 'balanced',
      customWeights: src.customWeights || null,
      showDebug: !!src.showDebug,
      siteWhitelist: Array.isArray(src.siteWhitelist) ? src.siteWhitelist.slice() : []
    };
  }

  function errText(err) {
    if (!err) return '未知错误';
    if (typeof err === 'string') return err;
    return String(err.message || err);
  }

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = String(text);
    return node;
  }

  function clear(node) {
    while (node && node.firstChild) node.removeChild(node.firstChild);
  }

  function setText(node, text) {
    if (node) node.textContent = text == null ? '' : String(text);
  }

  /* =====================================================================
   * chrome 通信安全层：扩展重载后（Extension context invalidated）也不能抛异常
   * =================================================================== */

  function runtimeAlive() {
    try {
      return typeof chrome !== 'undefined' && !!chrome.runtime && !!chrome.runtime.id;
    } catch (err) {
      return false;
    }
  }

  function isInvalidatedMessage(text) {
    return typeof text === 'string' && text.toLowerCase().indexOf('extension context invalidated') !== -1;
  }

  function markDead(text) {
    if (!isInvalidatedMessage(text)) return false;
    contextDead = true;
    cancelHover();
    hideBadge();
    closeCard();
    return true;
  }

  /** 所有 chrome.runtime.sendMessage 都走这里，统一兜住 lastError 与上下文失效 */
  function sendMessage(message, cb) {
    var finished = false;
    function finish(res) {
      if (finished) return;
      finished = true;
      if (typeof cb === 'function') {
        try { cb(res); } catch (err) { console.error('[素颜镜] 回调异常：' + errText(err)); }
      }
    }
    if (contextDead) {
      finish({ ok: false, error: '扩展已更新或重新加载，请刷新页面后再试' });
      return;
    }
    if (!runtimeAlive()) {
      // chrome.runtime 已经不可用（扩展被重载）：彻底停手，不再反复尝试
      contextDead = true;
      cancelHover();
      hideBadge();
      closeCard();
      finish({ ok: false, error: '扩展已更新或重新加载，请刷新页面后再试' });
      return;
    }
    try {
      chrome.runtime.sendMessage(message, function (response) {
        var lastErr = null;
        try { lastErr = chrome.runtime.lastError; } catch (err) { lastErr = err; }
        if (lastErr) {
          var text = errText(lastErr);
          if (markDead(text)) finish({ ok: false, error: '扩展已更新，请刷新页面后再试' });
          else finish({ ok: false, error: '扩展通信失败：' + text });
          return;
        }
        if (!response || typeof response !== 'object') {
          finish({ ok: false, error: '扩展没有返回结果，请重试' });
          return;
        }
        finish(response);
      });
    } catch (err) {
      var msg = errText(err);
      if (markDead(msg)) finish({ ok: false, error: '扩展已更新，请刷新页面后再试' });
      else finish({ ok: false, error: '扩展通信失败：' + msg });
    }
  }

  /* =====================================================================
   * 设置 / 白名单
   * =================================================================== */

  function parseWhitelist(list) {
    var out = [];
    if (!Array.isArray(list)) return out;
    for (var i = 0; i < list.length; i++) {
      var entry = String(list[i] == null ? '' : list[i]).trim().toLowerCase();
      if (!entry) continue;
      if (entry.indexOf('://') !== -1) {
        try { entry = new URL(entry).hostname.toLowerCase(); } catch (err) { continue; }
      }
      entry = entry.replace(/^\*\./, '').replace(/\/.*$/, '').replace(/^\./, '');
      if (entry) out.push(entry);
    }
    return out;
  }

  function applySettings(next) {
    if (!next || typeof next !== 'object') return;
    var previous = settings;
    settings = copySettings(next);
    whitelistHosts = parseWhitelist(settings.siteWhitelist);
    // 引擎结果受灵敏度/预设影响：这些变了就丢弃缓存，否则同一个 src 会一直返回旧分数
    if (previous.sensitivity !== settings.sensitivity ||
        previous.preset !== settings.preset ||
        JSON.stringify(previous.customWeights) !== JSON.stringify(settings.customWeights)) {
      cache.clear();
    }
    if (!settings.hoverEnabled || isWhitelisted()) {
      cancelHover();
      hideBadge();
      closeCard();
    }
  }

  function isWhitelisted() {
    if (!whitelistHosts.length) return false;
    var host = '';
    try { host = String(window.location.hostname || '').toLowerCase(); } catch (err) { return false; }
    if (!host) return false;
    for (var i = 0; i < whitelistHosts.length; i++) {
      var entry = whitelistHosts[i];
      if (host === entry) return true;
      if (host.length > entry.length && host.slice(-(entry.length + 1)) === '.' + entry) return true;
    }
    return false;
  }

  /* =====================================================================
   * 图片筛选
   * =================================================================== */

  function isSvgImage(img) {
    var url = String((img.currentSrc || img.src || '')).toLowerCase();
    if (/\.svgz?(\?|#|$)/.test(url)) return true;
    if (url.indexOf('data:image/svg') === 0) return true;
    var type = img.getAttribute ? img.getAttribute('type') : '';
    if (type && /svg/i.test(type)) return true;
    return false;
  }

  function srcOf(img) {
    if (!img) return '';
    return String(img.currentSrc || img.src || '').trim();
  }

  function rectOf(img) {
    if (!img || typeof img.getBoundingClientRect !== 'function') return null;
    var r;
    try { r = img.getBoundingClientRect(); } catch (err) { return null; }
    if (!r) return null;
    if (r.width <= 0 && r.height <= 0) return null;
    return {
      left: r.left, top: r.top, right: r.right, bottom: r.bottom,
      width: r.width, height: r.height
    };
  }

  function eligible(img) {
    if (!img || img.tagName !== 'IMG') return false;
    if (isSvgImage(img)) return false;
    var min = Math.max(1, Number(settings.minImageSize) || FALLBACK_SETTINGS.minImageSize);
    var w = img.naturalWidth || 0;
    var h = img.naturalHeight || 0;
    if (w < min || h < min) return false;
    if (!srcOf(img)) return false;
    var r = rectOf(img);
    if (r && (r.width < 8 || r.height < 8)) return false;
    if (typeof img.getClientRects === 'function' && img.getClientRects().length === 0) return false;
    return true;
  }

  function findImgByUrl(url) {
    if (!url) return null;
    var imgs = document.images || [];
    for (var i = 0; i < imgs.length; i++) {
      var img = imgs[i];
      if (!img) continue;
      if (srcOf(img) === url || String(img.src || '') === url) return img;
    }
    return null;
  }

  /* =====================================================================
   * LRU 缓存（Map 的插入顺序即使用顺序）
   * =================================================================== */

  function cacheGet(key) {
    if (!cache.has(key)) return null;
    var value = cache.get(key);
    cache.delete(key);
    cache.set(key, value);
    return value;
  }

  function cacheSet(key, value) {
    if (cache.has(key)) cache.delete(key);
    cache.set(key, value);
    while (cache.size > CACHE_LIMIT) {
      var oldest = cache.keys().next();
      if (oldest.done) break;
      cache.delete(oldest.value);
    }
  }

  /* =====================================================================
   * 分析
   * =================================================================== */

  /**
   * 请求分析某个图片地址。带 LRU 缓存与并发去重。
   * @param {string} url
   * @param {(res:{ok:boolean, report?:object, error?:string})=>void} done
   */
  function analyzeUrl(url, done) {
    function call(fn, res) {
      if (typeof fn === 'function') {
        try { fn(res); } catch (err) { console.error('[素颜镜] 分析回调异常：' + errText(err)); }
      }
    }
    if (contextDead) { call(done, { ok: false, error: '扩展已更新或重新加载，请刷新页面后再试' }); return; }
    if (!url) { call(done, { ok: false, error: '这张图片没有可用的地址' }); return; }

    var hit = cacheGet(url);
    if (hit) { call(done, hit); return; }

    var waiters = inflight.get(url);
    if (waiters) { waiters.push(done); return; }
    inflight.set(url, [done]);

    function settle(res) {
      var list = inflight.get(url) || [];
      inflight.delete(url);
      if (res && res.ok && res.report) cacheSet(url, res);
      for (var i = 0; i < list.length; i++) call(list[i], res);
    }

    if (/^(blob:|filesystem:|chrome-extension:)/i.test(url)) {
      analyzeViaCanvas(url, settle);
      return;
    }

    sendMessage({ type: 'ANALYZE_URL', url: url }, function (res) {
      if (res && res.ok) { settle(res); return; }
      // 后台取图失败（防盗链、需要页面会话等）时，退回页面 canvas 再试一次。
      analyzeViaCanvas(url, function (localRes) {
        settle(localRes && localRes.ok ? localRes : (res || localRes));
      });
    });
  }

  /** 页面 canvas 取像素（页面自己已加载好的 <img>，同源/CORS 干净时可用） */
  function analyzeViaCanvas(url, done) {
    var img = findImgByUrl(url) || (anchorImg && srcOf(anchorImg) === url ? anchorImg : null);
    if (!img) {
      done({ ok: false, error: '后台无法读取这张图片，页面上也找不到对应的图片元素' });
      return;
    }
    var w0 = img.naturalWidth || 0;
    var h0 = img.naturalHeight || 0;
    if (!w0 || !h0) { done({ ok: false, error: '无法获取图片尺寸' }); return; }
    try {
      var scale = Math.min(1, 512 / Math.max(w0, h0));
      var w = Math.max(1, Math.round(w0 * scale));
      var h = Math.max(1, Math.round(h0 * scale));
      var canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      var ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) throw new Error('无法创建 2D 画布');
      ctx.drawImage(img, 0, 0, w, h);
      var data = ctx.getImageData(0, 0, w, h);
      sendMessage({
        type: 'ANALYZE_IMAGE_DATA',
        imageData: { data: data.data, width: w, height: h }
      }, done);
    } catch (err) {
      done({ ok: false, error: '这张图片受跨域保护，页面无法读取像素，请改用弹窗上传图片' });
    }
  }

  /* =====================================================================
   * 悬停交互
   * =================================================================== */

  function pathOf(event) {
    try {
      if (event && typeof event.composedPath === 'function') return event.composedPath();
    } catch (err) { /* 忽略 */ }
    return [];
  }

  function pathHasUI(event) {
    if (!ui) return false;
    var path = pathOf(event);
    for (var i = 0; i < path.length; i++) if (path[i] === ui.host) return true;
    return false;
  }

  function imgFromEvent(event) {
    var path = pathOf(event);
    for (var i = 0; i < path.length; i++) {
      var node = path[i];
      if (node && node.tagName === 'IMG') return node;
    }
    return null;
  }

  function cancelHover() {
    if (hoverTimer) { clearTimeout(hoverTimer); hoverTimer = null; }
    hoverImg = null;
  }

  function onPointerOver(event) {
    if (contextDead || !settings.hoverEnabled || isWhitelisted()) return;
    if (pathHasUI(event)) { cancelBadgeHide(); return; }
    var img = imgFromEvent(event);
    if (!img) { cancelHover(); return; }
    if (img === hoverImg && (hoverTimer || anchorImg === img)) {
      // 指针又回到同一张图：取消可能已经排队的隐藏
      cancelBadgeHide();
      return;
    }
    cancelHover();
    if (!eligible(img)) return;
    hoverImg = img;
    var delay = Math.max(0, Number(settings.hoverDelay));
    if (!isFinite(delay)) delay = FALLBACK_SETTINGS.hoverDelay;
    hoverTimer = setTimeout(function () {
      hoverTimer = null;
      startHover(img);
    }, delay);
  }

  function onPointerOut(event) {
    if (contextDead) return;
    var img = imgFromEvent(event);
    if (!img) return;
    if (hoverTimer && img === hoverImg) cancelHover();
    if (anchorImg === img) {
      if (event.relatedTarget && ui && event.relatedTarget === ui.host) return;
      scheduleBadgeHide();
    }
  }

  function startHover(img) {
    if (contextDead || !settings.hoverEnabled || isWhitelisted() || !eligible(img)) return;
    anchorImg = img;
    showBadge(img, { text: '检测中…', loading: true });
    var url = srcOf(img);
    analyzeUrl(url, function (res) {
      if (contextDead || anchorImg !== img) return;
      if (!res || !res.ok) {
        showBadge(img, { text: '检测失败', error: true });
        return;
      }
      var report = res.report || {};
      if (report.ok === false) {
        showBadge(img, { text: '无法判断', error: true });
        return;
      }
      // SPEC §3.2：partial / 低置信度必须在角标上如实标注，不能只显示一个漂亮的分数
      var marks = [];
      if (report.partial === true) marks.push('仅供参考');
      if (typeof report.confidence === 'number' && report.confidence < 0.5) marks.push('低置信度');
      var text = '美颜 ' + report.score + ' · ' + (report.level || '');
      if (marks.length) text += ' · ' + marks.join(' · ');
      var hideAlreadyRequested = hideRequested;
      showBadge(img, {
        text: text,
        title: report.partial === true
          ? '仅供参考（未检测到人脸肤色），点击查看完整报告'
          : '点击查看完整报告'
      });
      // 分析返回时鼠标可能已经离开了图片：把之前请求过的隐藏补上，避免角标一直挂着
      if (hideAlreadyRequested) scheduleBadgeHide();
    });
  }

  function onBadgeClick(event) {
    event.preventDefault();
    event.stopPropagation();
    if (contextDead || !anchorImg) return;
    var img = anchorImg;
    var url = srcOf(img);
    var cached = url ? cacheGet(url) : null;
    if (cached && cached.ok) { openCard(img, cached); return; }
    showBadge(img, { text: '检测中…', loading: true });
    analyzeUrl(url, function (res) {
      if (contextDead) return;
      openCard(img, res);
    });
  }

  function scheduleBadgeHide() {
    cancelBadgeHide();
    hideRequested = true;
    badgeHideTimer = setTimeout(function () {
      badgeHideTimer = null;
      hideRequested = false;
      if (!cardOpen) hideBadge();
    }, 500);
  }

  function cancelBadgeHide() {
    if (badgeHideTimer) { clearTimeout(badgeHideTimer); badgeHideTimer = null; }
    hideRequested = false;
  }

  function hideBadge() {
    if (ui && ui.badge) ui.badge.hidden = true;
  }

  function onLayoutChange() {
    if (layoutFrame) return;
    layoutFrame = (window.requestAnimationFrame || function (cb) { return setTimeout(cb, 16); })(function () {
      layoutFrame = null;
      positionBadge();
      if (cardOpen && ui && !ui.card.hidden) positionCard(lastCardAnchor, lastCardPlacement === 'corner');
    });
  }

  function positionBadge() {
    if (!ui || !ui.badge || ui.badge.hidden || !anchorImg) return;
    var r = rectOf(anchorImg);
    if (!r) return;
    var bw = ui.badge.offsetWidth || 130;
    var bh = ui.badge.offsetHeight || 26;
    var vw = window.innerWidth || 0;
    var vh = window.innerHeight || 0;
    var left = clamp(r.left + 6, 4, Math.max(4, vw - bw - 4));
    var top = clamp(r.top + 6, 4, Math.max(4, vh - bh - 4));
    ui.badge.style.left = Math.round(left) + 'px';
    ui.badge.style.top = Math.round(top) + 'px';
  }

  function positionCard(anchor, corner) {
    if (!ui || !ui.card || ui.card.hidden) return;
    var cw = ui.card.offsetWidth || CARD_WIDTH;
    var ch = ui.card.offsetHeight || 260;
    var vw = window.innerWidth || 0;
    var vh = window.innerHeight || 0;
    if (corner) {
      // SPEC §0：右键菜单路径在页面右下角展开
      ui.card.style.left = Math.round(Math.max(8, vw - cw - 16)) + 'px';
      ui.card.style.top = Math.round(Math.max(8, vh - ch - 16)) + 'px';
      return;
    }
    var a = anchor || { left: 12, top: 12, right: 12, bottom: 12, width: 0, height: 0 };
    var left = a.right + 10;
    if (left + cw > vw - 8) left = a.left - cw - 10;
    if (left < 8) left = Math.max(8, Math.min(vw - cw - 8, 8));
    var top = a.top;
    if (top + ch > vh - 8) top = vh - ch - 8;
    if (top < 8) top = 8;
    ui.card.style.left = Math.round(left) + 'px';
    ui.card.style.top = Math.round(top) + 'px';
  }

  function showBadge(img, state) {
    var u = ensureUI();
    if (!u) return;
    cancelBadgeHide();
    u.badge.hidden = false;
    u.badge.classList.toggle('is-loading', !!state.loading);
    u.badge.classList.toggle('is-error', !!state.error);
    u.badge.setAttribute('title', state.title || '点击查看完整报告');
    setText(u.badgeText, state.text || '');
    positionBadge();
  }

  function closeCard() {
    cardOpen = false;
    lastCardRes = null;
    if (ui && ui.card) {
      ui.card.hidden = true;
      clear(ui.card);
    }
  }

  function openCard(img, res, placement) {
    var u = ensureUI();
    if (!u) return;
    cardOpen = true;
    cancelBadgeHide();
    hideBadge();
    var corner = placement === 'corner';
    var anchor = rectOf(img) || lastCardAnchor || { left: 12, top: 12, right: 12, bottom: 12, width: 0, height: 0 };
    lastCardAnchor = anchor;
    lastCardPlacement = corner ? 'corner' : 'anchor';
    lastCardRes = res || null;
    renderCard(u.card, res);
    u.card.hidden = false;
    positionCard(anchor, corner);
  }

  function onKeydown(event) {
    if (event.key !== 'Escape' && event.keyCode !== 27) return;
    if (cardOpen) { closeCard(); return; }
    hideBadge();
  }

  /* =====================================================================
   * 报告卡片渲染
   * =================================================================== */

  function levelSlug(level) {
    return LEVEL_SLUG[level] || 'unknown';
  }

  function chip(cls, text) {
    return el('span', 'bmx-chip ' + cls, text);
  }

  function addMetricsSection(root, report) {
    var metrics = Array.isArray(report.metrics) ? report.metrics : [];
    if (!metrics.length) return;
    root.appendChild(el('div', 'bmx-section-title',
      metrics.length === 5 ? '五个维度' : '维度（' + metrics.length + ' 项）'));
    var list = el('ul', 'bmx-metrics');
    for (var i = 0; i < metrics.length; i++) {
      var m = metrics[i] || {};
      var available = m.available !== false;
      var li = el('li', 'bmx-metric' + (available ? '' : ' is-unavailable'));

      var top = el('div', 'bmx-metric-top');
      top.appendChild(el('span', 'bmx-metric-label', m.label || m.key || '维度'));
      if (typeof m.weightPct === 'number' && m.weightPct > 0) {
        top.appendChild(el('span', 'bmx-metric-weight', '权重 ' + m.weightPct + '%'));
      }
      top.appendChild(el('span', 'bmx-metric-score', available ? String(m.score == null ? '—' : m.score) : '—'));
      li.appendChild(top);

      var bar = el('div', 'bmx-bar');
      var fill = el('div', 'bmx-bar-fill');
      fill.style.width = (available ? clamp(Number(m.score) || 0, 0, 100) : 0) + '%';
      bar.appendChild(fill);
      li.appendChild(bar);

      if (m.hint) li.appendChild(el('p', 'bmx-metric-hint', m.hint));
      if (available) {
        if (m.evidence) li.appendChild(el('p', 'bmx-metric-evidence', m.evidence));
      } else {
        li.appendChild(el('p', 'bmx-metric-evidence', '该项不可用：' + (m.evidence || '数据不足')));
      }
      list.appendChild(li);
    }
    root.appendChild(list);
  }

  function addWarningsSection(root, report, skipText) {
    var warnings = Array.isArray(report.warnings) ? report.warnings : [];
    var shown = [];
    for (var i = 0; i < warnings.length; i++) {
      if (!warnings[i]) continue;
      // ok:false 时引擎会把 error 又塞进 warnings，已经在错误框里显示过的不再重复
      if (skipText && String(warnings[i]).indexOf(skipText) !== -1) continue;
      shown.push(warnings[i]);
    }
    if (!shown.length) return;
    root.appendChild(el('div', 'bmx-section-title', '提示'));
    var list = el('ul', 'bmx-warnings');
    for (var j = 0; j < shown.length; j++) list.appendChild(el('li', null, String(shown[j])));
    root.appendChild(list);
  }

  function addDebugSection(root, report) {
    if (!settings.showDebug) return;
    var debug = report.debug && typeof report.debug === 'object' ? report.debug : null;
    if (!debug) return;
    var details = el('details', 'bmx-debug');
    details.appendChild(el('summary', null, '调试数据'));
    var table = el('table', 'bmx-debug-table');
    Object.keys(debug).forEach(function (key) {
      var value = debug[key];
      if (value == null || typeof value === 'object') return;
      var tr = el('tr');
      tr.appendChild(el('th', null, key));
      tr.appendChild(el('td', null, String(value)));
      table.appendChild(tr);
    });
    details.appendChild(table);
    root.appendChild(details);
  }

  function addActions(root) {
    var actions = el('div', 'bmx-actions');
    var copy = el('button', 'bmx-btn bmx-copy', '复制结论');
    copy.setAttribute('type', 'button');
    var hint = el('span', 'bmx-copy-hint', '');
    actions.appendChild(copy);
    actions.appendChild(hint);
    root.appendChild(actions);
  }

  function renderCard(card, res) {
    clear(card);

    if (!res || !res.ok || !res.report) {
      card.appendChild(errorHeader('无法分析'));
      card.appendChild(el('p', 'bmx-error', (res && res.error) || '分析失败，请重试'));
      card.appendChild(el('p', 'bmx-tip', '提示：换一张更清晰、未加密的图片，或刷新页面后重试。'));
      return;
    }

    var report = res.report;
    if (report.ok === false) {
      var title = report.reason === 'grayscale' ? '黑白 / 近灰度图片' : '这张图无法判断';
      card.appendChild(errorHeader(title));
      card.appendChild(el('p', 'bmx-error', report.error || '无法判断这张图片的美颜程度'));
      card.appendChild(el('p', 'bmx-tip', report.reason === 'grayscale'
        ? '黑白照片没有肤色信息，无法估算美颜程度。'
        : '请换一张更大、色彩正常的人像图片试试。'));
      addWarningsSection(card, report, report.error);
      return;
    }

    /* 头部：分数 + 档位 + 置信度 */
    var head = el('div', 'bmx-card-head');
    var scoreBox = el('div', 'bmx-score');
    scoreBox.appendChild(el('span', 'bmx-score-num', String(report.score == null ? '—' : report.score)));
    scoreBox.appendChild(el('span', 'bmx-score-unit', '/100'));
    head.appendChild(scoreBox);

    var main = el('div', 'bmx-head-main');
    var levelChip = chip('bmx-level', report.level || '未知档位');
    levelChip.setAttribute('data-level', levelSlug(report.level));
    main.appendChild(levelChip);
    if (report.levelDesc) main.appendChild(el('div', 'bmx-level-desc', report.levelDesc));

    var meta = el('div', 'bmx-meta');
    var conf = typeof report.confidence === 'number' ? report.confidence : 0;
    meta.appendChild(chip('bmx-conf', '置信度 ' + Math.round(conf * 100) + '%'));
    if (conf < 0.5) meta.appendChild(chip('bmx-lowconf', '低置信度'));
    if (typeof report.width === 'number' && typeof report.height === 'number') {
      meta.appendChild(chip('bmx-dim', report.width + ' × ' + report.height));
    }
    main.appendChild(meta);
    head.appendChild(main);

    var close = el('button', 'bmx-close', '×');
    close.setAttribute('type', 'button');
    close.setAttribute('aria-label', '关闭');
    head.appendChild(close);
    card.appendChild(head);

    // SPEC §5「分数环形/条形」：卡片里给一条总分条
    var scoreBar = el('div', 'bmx-score-bar');
    var scoreFill = el('div', 'bmx-score-bar-fill');
    scoreFill.style.width = clamp(Number(report.score) || 0, 0, 100) + '%';
    scoreBar.appendChild(scoreFill);
    card.appendChild(scoreBar);

    if (report.partial === true) {
      card.appendChild(el('div', 'bmx-banner', '仅供参考（未检测到人脸肤色）'));
    }

    var summary = report.summary;
    if (!summary && typeof report.score === 'number') {
      summary = '美颜程度 ' + report.score + '/100（' + (report.level || '') + '）' + (report.levelDesc ? '：' + report.levelDesc : '');
    }
    if (summary) card.appendChild(el('p', 'bmx-summary', summary));

    addMetricsSection(card, report);
    addWarningsSection(card, report);
    addDebugSection(card, report);
    addActions(card);
  }

  function errorHeader(title) {
    var head = el('div', 'bmx-card-head');
    var main = el('div', 'bmx-head-main');
    main.appendChild(chip('bmx-level is-error', title));
    main.appendChild(el('div', 'bmx-level-desc', '没有可显示的美颜程度分数'));
    head.appendChild(main);
    var close = el('button', 'bmx-close', '×');
    close.setAttribute('type', 'button');
    close.setAttribute('aria-label', '关闭');
    head.appendChild(close);
    return head;
  }

  function conclusionText(reportCover) {
    var res = reportCover;
    if (!res || !res.ok || !res.report) {
      return '【素颜镜 · 美颜程度检测】\n结论：' + ((res && res.error) || '分析失败');
    }
    var report = res.report;
    if (report.ok === false) {
      return '【素颜镜 · 美颜程度检测】\n结论：' + (report.error || '无法判断');
    }
    var lines = ['【素颜镜 · 美颜程度检测】'];
    lines.push('美颜程度：' + report.score + '/100（' + (report.level || '') + '）' + (report.levelDesc ? '—— ' + report.levelDesc : ''));
    if (report.partial === true) lines.push('注意：未检测到人脸肤色，以上仅为整图参考值。');
    lines.push('置信度：' + Math.round((Number(report.confidence) || 0) * 100) + '%');
    var metrics = Array.isArray(report.metrics) ? report.metrics : [];
    if (metrics.length) {
      lines.push('维度：');
      for (var i = 0; i < metrics.length; i++) {
        var m = metrics[i] || {};
        var head = m.label || m.key || '维度';
        var weight = typeof m.weightPct === 'number' ? '（权重 ' + m.weightPct + '%）' : '';
        if (m.available === false) lines.push('  · ' + head + weight + '：不可用（' + (m.evidence || '数据不足') + '）');
        else lines.push('  · ' + head + weight + '：' + m.score + (m.evidence ? ' —— ' + m.evidence : ''));
      }
    }
    if (Array.isArray(report.warnings)) {
      for (var j = 0; j < report.warnings.length; j++) {
        if (report.warnings[j]) lines.push('提示：' + report.warnings[j]);
      }
    }
    if (report.summary) lines.push('一句话结论：' + report.summary);
    return lines.join('\n');
  }

  function copyText(text, cb) {
    function legacy() {
      var ok = false;
      try {
        var area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', 'readonly');
        area.style.position = 'fixed';
        area.style.top = '-1000px';
        area.style.opacity = '0';
        (document.body || document.documentElement).appendChild(area);
        area.select();
        area.setSelectionRange(0, area.value.length);
        ok = document.execCommand('copy');
        area.parentNode.removeChild(area);
      } catch (err) {
        ok = false;
      }
      cb(ok);
    }
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        navigator.clipboard.writeText(text).then(function () { cb(true); }, function () { legacy(); });
        return;
      }
    } catch (err) { /* 走降级 */ }
    legacy();
  }

  function onCardClick(event) {
    var target = event.target;
    if (!target || typeof target.closest !== 'function') return;
    var closeBtn = target.closest('.bmx-close');
    if (closeBtn) {
      event.preventDefault();
      event.stopPropagation();
      closeCard();
      return;
    }
    var copyBtn = target.closest('.bmx-copy');
    if (copyBtn) {
      event.preventDefault();
      event.stopPropagation();
      var res = lastCardRes;
      if (!res) return;
      var hint = ui && ui.card ? ui.card.querySelector('.bmx-copy-hint') : null;
      var original = copyBtn.textContent;
      copyText(conclusionText(res), function (ok) {
        copyBtn.textContent = ok ? '已复制' : '复制失败';
        setText(hint, ok ? '已复制到剪贴板' : '复制失败，请手动选择文本');
        setTimeout(function () { copyBtn.textContent = original; setText(hint, ''); }, 1600);
      });
    }
  }

  /* =====================================================================
   * Shadow DOM UI
   * =================================================================== */

  function contentCssUrl() {
    try {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.getURL) return '';
      return chrome.runtime.getURL(CONTENT_CSS_PATH);
    } catch (err) {
      return '';
    }
  }

  /**
   * 样式注入（两条路径同时用，互为兜底，内容完全一致、不存在样式副本）：
   *   1) <link href=chrome-extension://…/content.css>：立刻生效、无闪烁；
   *   2) 内容脚本 fetch 取回文本后内联 <style>：页面用 CSP 拦掉外部样式表时这条仍生效。
   * content.css 已登记在 web_accessible_resources，两种方式都能读到。
   */
  function injectStyles(shadow, url) {
    try {
      var link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = url;
      shadow.appendChild(link);
    } catch (err) { /* 忽略，走下面的内联注入 */ }

    try {
      if (typeof fetch !== 'function') return;
      fetch(url)
        .then(function (response) {
          if (!response || !response.ok) throw new Error('样式加载失败');
          return response.text();
        })
        .then(function (css) {
          if (!css) return;
          var style = document.createElement('style');
          style.textContent = css;
          shadow.appendChild(style);
        })
        .catch(function () { /* <link> 已经是兜底 */ });
    } catch (err) { /* 忽略 */ }
  }

  function ensureUI() {
    if (ui) return ui;
    if (contextDead) return null;
    try {
      var host = document.createElement(HOST_TAG);
      host.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;' +
        'z-index:2147483647;pointer-events:none;';
      var shadow = null;
      try {
        shadow = host.attachShadow({ mode: 'open' });
      } catch (err) {
        return null;
      }

      var cssUrl = contentCssUrl();
      if (!cssUrl) { contextDead = true; return null; }
      injectStyles(shadow, cssUrl);

      var root = el('div', 'bmx-root');
      shadow.appendChild(root);

      var badge = el('div', 'bmx-badge');
      badge.hidden = true;
      badge.setAttribute('role', 'button');
      badge.setAttribute('tabindex', '0');
      badge.appendChild(el('span', 'bmx-dot'));
      var badgeText = el('span', 'bmx-text', '');
      badge.appendChild(badgeText);

      var card = el('div', 'bmx-card');
      card.hidden = true;
      card.setAttribute('role', 'dialog');
      card.setAttribute('aria-label', '美颜程度检测报告');

      root.appendChild(badge);
      root.appendChild(card);

      (document.documentElement || document.body).appendChild(host);

      badge.addEventListener('click', onBadgeClick);
      badge.addEventListener('pointerenter', cancelBadgeHide);
      badge.addEventListener('pointerleave', function () { if (!cardOpen) scheduleBadgeHide(); });
      card.addEventListener('click', onCardClick);
      card.addEventListener('pointerenter', cancelBadgeHide);
      card.addEventListener('pointerleave', function () { if (!cardOpen) scheduleBadgeHide(); });

      var stop = function (event) { event.stopPropagation(); };
      badge.addEventListener('pointerdown', stop);
      badge.addEventListener('mousedown', stop);
      card.addEventListener('pointerdown', stop);
      card.addEventListener('mousedown', stop);

      document.addEventListener('keydown', onKeydown, true);
      window.addEventListener('scroll', onLayoutChange, true);
      window.addEventListener('resize', onLayoutChange, true);

      ui = { host: host, shadow: shadow, root: root, badge: badge, badgeText: badgeText, card: card };
      return ui;
    } catch (err) {
      console.error('[素颜镜] 创建界面失败：' + errText(err));
      return null;
    }
  }

  /* =====================================================================
   * 消息处理（content 侧：SHOW_REPORT / FIND_LARGEST_IMAGE / SETTINGS_CHANGED）
   * =================================================================== */

  function handleShowReport(message) {
    var url = message && message.url ? String(message.url) : '';
    var img = findImgByUrl(url);
    var anchor = null;
    if (img) anchor = rectOf(img);
    else if (message && message.anchorRect) anchor = message.anchorRect;

    if (!url) return;

    if (img) {
      anchorImg = img;
      showBadge(img, { text: '检测中…', loading: true });
    }
    var pendingImg = img;
    analyzeUrl(url, function (res) {
      if (contextDead) return;
      if (pendingImg) {
        anchorImg = pendingImg;
        // 右键菜单路径：按 SPEC §0 在页面右下角展开
        openCard(pendingImg, res, 'corner');
      } else {
        // 页面上找不到对应 <img>（懒加载/虚拟列表）：用给定锚点直接弹卡片
        var u = ensureUI();
        if (!u) return;
        cardOpen = true;
        var a = anchor || { left: 12, top: 12, right: 12, bottom: 12, width: 0, height: 0 };
        lastCardAnchor = a;
        lastCardPlacement = 'corner';
        lastCardRes = res || null;
        renderCard(u.card, res);
        u.card.hidden = false;
        positionCard(a, true);
      }
    });
  }

  function findLargestImage() {
    var imgs = document.images || [];
    var best = null;
    var bestArea = 0;
    var fallback = null;
    var fallbackArea = 0;
    for (var i = 0; i < imgs.length; i++) {
      var img = imgs[i];
      if (!img || isSvgImage(img)) continue;
      var w = img.naturalWidth || 0;
      var h = img.naturalHeight || 0;
      var url = srcOf(img);
      if (!w || !h || !url) continue;
      var area = w * h;
      var r = rectOf(img);
      var visible = !!r && r.width >= 8 && r.height >= 8 &&
        (typeof img.getClientRects !== 'function' || img.getClientRects().length > 0);
      if (visible) {
        if (area > bestArea) { bestArea = area; best = img; }
      } else if (area > fallbackArea) {
        fallbackArea = area;
        fallback = img;
      }
    }
    var pick = best || fallback;
    if (!pick) return { ok: false, error: '当前页面没有找到可分析的图片' };
    return {
      ok: true,
      url: srcOf(pick),
      width: pick.naturalWidth,
      height: pick.naturalHeight
    };
  }

  function onRuntimeMessage(message, sender, sendResponse) {
    try {
      if (!message || typeof message.type !== 'string') return;
      if (message.type === 'SHOW_REPORT') {
        // SPEC §5 + 设置页说明：白名单站点完全不检测，右键菜单也不响应
        if (isWhitelisted()) {
          sendResponse({ ok: true, skipped: 'whitelist' });
          return;
        }
        handleShowReport(message);
        sendResponse({ ok: true, accepted: true });
        return;
      }
      if (message.type === 'FIND_LARGEST_IMAGE') {
        var found = findLargestImage();
        // 只在确实找到图片时响应：弹窗会先问主框架、再问所有框架，让「有图的框架」
        // 回话，避免第一个响应的空框架把结果顶掉。
        if (found && found.ok) sendResponse(found);
        return;
      }
      if (message.type === 'SETTINGS_CHANGED') {
        applySettings(message.settings);
        sendResponse({ ok: true });
        return;
      }
    } catch (err) {
      console.error('[素颜镜] 消息处理失败：' + errText(err));
      try { sendResponse({ ok: false, error: errText(err) }); } catch (e) { /* 通道已关闭 */ }
    }
  }

  /* =====================================================================
   * 启动
   * =================================================================== */

  function boot() {
    if (!runtimeAlive()) {
      contextDead = true;
      return;
    }

    try {
      document.addEventListener('pointerover', onPointerOver, true);
      document.addEventListener('pointerout', onPointerOut, true);
    } catch (err) { /* 忽略 */ }

    try {
      chrome.runtime.onMessage.addListener(onRuntimeMessage);
    } catch (err) {
      contextDead = true;
      return;
    }

    sendMessage({ type: 'GET_SETTINGS' }, function (res) {
      if (res && res.ok && res.settings) applySettings(res.settings);
    });
  }

  boot();
})();
