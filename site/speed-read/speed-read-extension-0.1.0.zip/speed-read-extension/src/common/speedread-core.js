/**
 * 一目十行 · 压缩引擎 speedread-core.js
 * ---------------------------------------------------------------------------
 * 纯逻辑、零依赖、零 DOM、零网络（fetch 由调用方注入），四个环境通用：
 *   Chrome Service Worker（importScripts，本文件是传统脚本）/ 扩展页面（<script>）/
 *   内容脚本（<script>）/ Node.js（require，供 node --test 使用）。
 *
 * 职责边界（本文件不碰 DOM，正文抽取在 dom-walk.js）：
 *   1) 文本度量      归一化、CJK 二元切分、词频、句切分、内容指纹
 *   2) 输入压缩      正文分块按信息密度裁剪到 token 预算内（信息最大化，别丢结论）
 *   3) 提示词        把「恰好 3 条 · α/β/γ」的判定规则写成模型可执行的约束
 *   4) 输出解析      模型返回的 JSON 容错解析 + 三条归一化（剥 markdown/引号/前缀）
 *   5) 本地兜底      没有 Key 或调用失败时，用 extractive 打分给出 3 条，面板不留白
 *   6) LLM 客户端    OpenAI 兼容 /chat/completions：URL 归一、超时、退避重试、错误分型
 *   7) 编排          summarizeWithLLM：调用 → 解析 → 失败降级 → 统一结果 schema
 *
 * 三条信息的定位（用户确认口径）：
 *   alpha 阿尔法   全文最重要、读者最先该知道的核心结论
 *   beta  贝塔     第二关键信息：支撑证据 / 代价 / 风险 / 限制 / 反面观点
 *   gamma 人说最多 全页被重复、强调、引用次数最多的议题或主张
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.SpeedReadCore = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = '0.1.0';

  /* =======================================================================
   * 常量
   * ===================================================================== */

  var ITEM_KEYS = ['alpha', 'beta', 'gamma'];

  var ITEM_META = {
    alpha: {
      key: 'alpha',
      label: '阿尔法',
      badge: 'α',
      hint: '全文最重要、最先该知道的核心结论'
    },
    beta: {
      key: 'beta',
      label: '贝塔',
      badge: 'β',
      hint: '第二关键信息：支撑证据 / 代价 / 风险 / 限制 / 反面'
    },
    gamma: {
      key: 'gamma',
      label: '人说最多',
      badge: 'γ',
      hint: '全页重复、强调、引用次数最多的议题'
    }
  };

  /** 中文高频功能字：只用于砍掉「的了」「是在」这类无意义二元组 */
  var CJK_FUNCTION_CHARS = '的了是在和有我你他她它这那就不人都一上也很到说要去会着看好自己之与而为其所以及对从被把让给但只还';
  var FUNCTION_CHAR_SET = new Set(CJK_FUNCTION_CHARS.split(''));

  var STOP_ZH_BIGRAM = new Set([
    '我们', '你们', '他们', '这个', '那个', '什么', '怎么', '因为', '所以', '但是',
    '可以', '可能', '已经', '就是', '不是', '没有', '一个', '一样', '这样', '那样',
    '如果', '虽然', '然后', '而且', '或者', '以及', '为了', '通过', '这些', '那些',
    '时候', '现在', '自己', '大家', '非常', '真的', '觉得', '知道', '需要', '应该'
  ]);

  var STOP_EN = new Set([
    'the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'any', 'can', 'had',
    'her', 'was', 'one', 'our', 'out', 'day', 'get', 'has', 'him', 'his', 'how',
    'its', 'may', 'new', 'now', 'old', 'see', 'two', 'way', 'who', 'boy', 'did',
    'use', 'that', 'this', 'with', 'have', 'from', 'they', 'will', 'would', 'there',
    'their', 'what', 'about', 'which', 'when', 'make', 'like', 'time', 'just',
    'know', 'take', 'into', 'your', 'some', 'them', 'than', 'then', 'only', 'come',
    'over', 'also', 'back', 'after', 'could', 'been', 'were', 'said', 'each',
    'more', 'most', 'other', 'many', 'must', 'such', 'very', 'here', 'does',
    'should', 'because', 'these', 'those', 'being', 'between', 'under', 'while',
    'where', 'through', 'during', 'before', 'against', 'however', 'although',
    'com', 'www', 'http', 'https', 'html', 'cookie', 'cookies', 'privacy', 'terms',
    'subscribe', 'newsletter', 'advertisement', 'login', 'sign'
  ]);

  var HEADING_TAGS = new Set(['H1', 'H2', 'H3', 'H4', 'H5', 'H6']);

  var DEFAULTS_INPUT = {
    maxChars: 6000,
    maxCharsPerItem: 60,
    lang: 'auto'
  };

  var DEFAULT_LLM = {
    baseUrl: '',
    model: '',
    temperature: 0.2,
    maxTokens: 700,
    timeoutMs: 20000,
    retries: 1
  };

  /* =======================================================================
   * 0. 小工具
   * ===================================================================== */

  function clamp(n, lo, hi) {
    n = Number(n);
    if (!isFinite(n)) return lo;
    return n < lo ? lo : n > hi ? hi : n;
  }

  function now() {
    return typeof Date !== 'undefined' && Date.now ? Date.now() : 0;
  }

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, clamp(ms, 0, 10000)); });
  }

  function stripUnsafeControls(s) {
    return String(s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '');
  }

  /** 折叠所有空白；保留句内单空格 */
  function normalizeSpace(text) {
    return stripUnsafeControls(text).replace(/[\t\f\v\u00a0\u2000-\u200a\u202f\u205f\u3000]+/g, ' ').replace(/\s*\n\s*/g, '\n').replace(/ {2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  }

  /** 一句话级别的归一：换行也压成空格 */
  function oneLine(text) {
    return normalizeSpace(text).replace(/\s*\n+\s*/g, ' ').replace(/ {2,}/g, ' ').trim();
  }

  /** CJK 字符数按 1、其余按 1 —— 只用于预算，不用来精确计 token */
  function textLen(text) {
    return String(text || '').length;
  }

  function isCJKChar(ch) {
    var c = ch.charCodeAt(0);
    return (
      (c >= 0x3400 && c <= 0x4dbf) ||
      (c >= 0x4e00 && c <= 0x9fff) ||
      (c >= 0xf900 && c <= 0xfaff) ||
      (c >= 0x3040 && c <= 0x30ff) ||
      (c >= 0xac00 && c <= 0xd7af)
    );
  }

  function cjkRatio(text) {
    var s = String(text || '');
    if (!s.length) return 0;
    var hits = 0;
    for (var i = 0; i < s.length; i++) if (isCJKChar(s[i])) hits++;
    return hits / s.length;
  }

  function guessLanguage(text) {
    return cjkRatio(text) >= 0.12 ? 'zh' : 'en';
  }

  /** 粗略 token 估算：CJK 约 1 字 1 token，拉丁约 4 字符 1 token */
  function estimateTokens(text) {
    var s = String(text || '');
    var cjk = 0;
    for (var i = 0; i < s.length; i++) if (isCJKChar(s[i])) cjk++;
    var rest = s.length - cjk;
    return Math.ceil(cjk * 1.0 + rest / 3.6);
  }

  /* =======================================================================
   * 1. 文本度量
   * ===================================================================== */

  var TOKEN_RE = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]+|[A-Za-z][A-Za-z0-9'’-]*|\d+(?:[.,]\d+)*/g;

  /**
   * 分词：CJK 走二元组（无词典也能拿到稳定主题词），拉丁/数字走整词。
   * 返回原始 token 数组（含重复），供词频统计使用。
   */
  function tokenize(text) {
    var out = [];
    var s = String(text || '');
    var m;
    TOKEN_RE.lastIndex = 0;
    while ((m = TOKEN_RE.exec(s)) !== null) {
      var t = m[0];
      var head = t.charCodeAt(0);
      var isLatin = (head >= 65 && head <= 90) || (head >= 97 && head <= 122);
      var isDigit = head >= 48 && head <= 57;
      if (isLatin) {
        var w = t.toLowerCase();
        if (w.length >= 3 && !STOP_EN.has(w)) out.push(w);
      } else if (isDigit) {
        if (t.replace(/\D/g, '').length >= 2) out.push(t);
      } else if (t.length === 1) {
        if (!FUNCTION_CHAR_SET.has(t)) out.push(t);
      } else {
        for (var i = 0; i < t.length - 1; i++) {
          var bg = t.slice(i, i + 2);
          if (STOP_ZH_BIGRAM.has(bg)) continue;
          if (FUNCTION_CHAR_SET.has(bg[0]) && FUNCTION_CHAR_SET.has(bg[1])) continue;
          out.push(bg);
        }
      }
    }
    return out;
  }

  function termFrequency(tokens) {
    var map = new Map();
    for (var i = 0; i < tokens.length; i++) {
      var t = tokens[i];
      map.set(t, (map.get(t) || 0) + 1);
    }
    return map;
  }

  /**
   * 高频主题词：CJK 二元组按词频降序；同频时更长的词优先（信息量更大）。
   * 用于 ① 作为 γ 的提示词交给模型 ② 无模型时 γ 的兜底。
   */
  function topTerms(text, opts) {
    var o = opts || {};
    var limit = clamp(o.limit == null ? 12 : o.limit, 1, 60);
    var minCount = clamp(o.minCount == null ? 2 : o.minCount, 1, 50);
    var freq = termFrequency(tokenize(text));
    var arr = [];
    freq.forEach(function (count, term) { arr.push({ term: term, count: count }); });
    arr.sort(function (a, b) {
      if (b.count !== a.count) return b.count - a.count;
      if (b.term.length !== a.term.length) return b.term.length - a.term.length;
      return a.term < b.term ? -1 : a.term > b.term ? 1 : 0;
    });
    var kept = arr.filter(function (x) { return x.count >= minCount; });
    if (kept.length < 3) {
      // 短页面：放宽到 count>=1，但至少有 3 个候选才换
      var relaxed = arr.filter(function (x) { return x.count >= 1; });
      if (relaxed.length > kept.length) kept = relaxed;
    }
    return kept.slice(0, limit);
  }

  /**
   * 句切分：换行 / 。！？；!?; 结尾切分；不切小数点与缩写。
   */
  function splitSentences(text) {
    var s = String(text || '');
    if (!s) return [];
    var out = [];
    var lines = s.split(/\n+/);
    for (var li = 0; li < lines.length; li++) {
      var line = lines[li].trim();
      if (!line) continue;
      var re = /[^。！？!?；;]+[。！？!?；;]?/g;
      var m;
      while ((m = re.exec(line)) !== null) {
        var piece = m[0].trim();
        if (piece) out.push(piece);
      }
    }
    return out.filter(function (x) { return textLen(x) >= 4; });
  }

  /** FNV-1a 32bit，十六进制 */
  function hash32(str) {
    var h = 0x811c9dc5;
    var s = String(str);
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(36);
  }

  /** 去掉 hash 与常见跟踪参数，让同一篇文章的不同入口共享缓存 */
  function normalizeUrl(url) {
    var u = String(url || '');
    try {
      var parsed = new URL(u);
      var drop = /^(utm_|fbclid|gclid|ref|ref_src|igshid|spm|from|share_)/i;
      var keep = [];
      parsed.searchParams.forEach(function (value, key) {
        if (!drop.test(key)) keep.push(key + '=' + value);
      });
      var tail = keep.length ? '?' + keep.join('&') : '';
      var path = parsed.pathname.replace(/\/+$/, '');
      return parsed.host + path + tail;
    } catch (e) {
      return u.replace(/#.*$/, '');
    }
  }

  /**
   * 内容指纹：正文变化 → 指纹变化 → 触发重算。
   * 取「去空白正文」的头尾采样 + 总长 + 标题 + 归一 URL。
   */
  function contentFingerprint(input) {
    var text = String((input && input.text) || '');
    var packed = text.replace(/\s+/g, '');
    var head = packed.slice(0, 1200);
    var tail = packed.length > 1200 ? packed.slice(-600) : '';
    var parts = [
      normalizeUrl((input && input.url) || ''),
      oneLine((input && input.title) || '').slice(0, 200),
      String(packed.length),
      head,
      tail
    ];
    return hash32(parts.join('\u0001'));
  }

  /* =======================================================================
   * 2. 输入压缩：在 token 预算内保留信息量最大的句子
   * ===================================================================== */

  function normalizeBlock(block) {
    return {
      tag: String(block.tag || 'P').toUpperCase(),
      text: normalizeSpace(block.text || ''),
      depth: Number(block.depth) || 0,
      weight: block.weight == null ? 1 : Number(block.weight),
      linkDensity: block.linkDensity == null ? 0 : clamp(block.linkDensity, 0, 1)
    };
  }

  /** 单块信息密度分：长度 × 权重 × (1-链接密度) × 标点/数字/标题加成 */
  function blockScore(block) {
    var len = textLen(block.text);
    var s = Math.min(len, 600) * (block.weight || 1);
    s *= 1 - Math.min(0.85, block.linkDensity || 0);
    if (/[。！？!?]/.test(block.text)) s *= 1.15;
    if (/\d/.test(block.text)) s *= 1.08;
    if (HEADING_TAGS.has(block.tag)) s *= 1.25;
    if (len < 25) s *= 0.5;
    return s;
  }

  function dedupeBlocks(blocks) {
    var seen = new Set();
    var out = [];
    for (var i = 0; i < blocks.length; i++) {
      var b = normalizeBlock(blocks[i]);
      if (textLen(b.text) < 6) continue;
      var key = b.text.replace(/\s+/g, '');
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(b);
    }
    return out;
  }

  /**
   * 正文裁剪。
   * 预算分配：标题 ≤20%、正文头部 68%、尾部（结论/总结常在此）剩余。
   * 保留 DOM 顺序输出，被整段跳过的地方标出省略量——读者能看出这是压缩过的。
   */
  function budgetBlocks(blocks, opts) {
    var o = opts || {};
    var maxChars = clamp(o.maxChars == null ? DEFAULTS_INPUT.maxChars : o.maxChars, 400, 60000);
    var clean = dedupeBlocks(blocks || []);
    var totalChars = 0;
    var i;
    for (i = 0; i < clean.length; i++) totalChars += textLen(clean[i].text);

    if (!clean.length) {
      return { text: '', chars: 0, totalChars: 0, kept: 0, total: 0, omittedChars: 0, truncated: false };
    }
    if (totalChars <= maxChars) {
      return {
        text: clean.map(function (b) { return b.text; }).join('\n'),
        chars: totalChars,
        totalChars: totalChars,
        kept: clean.length,
        total: clean.length,
        omittedChars: 0,
        truncated: false
      };
    }

    var scored = clean.map(function (b, idx) {
      return { b: b, idx: idx, score: blockScore(b) };
    });
    var headBudget = Math.round(maxChars * 0.68);
    var headCap = Math.round(headBudget * 0.2);
    var tailBudget = Math.max(0, maxChars - headBudget - 48);
    var chosen = new Set();
    var usedHead = 0;
    var usedHeadings = 0;

    // 2.0 首段几乎总是导语/摘要，信息密度最高：无条件保底（最多占头预算的 25%）。
    //     否则纯按分数选块时，导语常被中段的长段落挤掉 —— 那是「信息最大化」的反面。
    var ledeCap = Math.round(headBudget * 0.25);
    for (i = 0; i < scored.length; i++) {
      if (HEADING_TAGS.has(scored[i].b.tag)) continue;
      if (textLen(scored[i].b.text) < 30) continue;
      if (textLen(scored[i].b.text) <= ledeCap) {
        chosen.add(scored[i].idx);
        usedHead += textLen(scored[i].b.text);
      }
      break;
    }

    // 2.1 结构标题先占位（最多占头部的 20%）
    for (i = 0; i < scored.length; i++) {
      var s = scored[i];
      if (chosen.has(s.idx)) continue;
      if (!HEADING_TAGS.has(s.b.tag)) continue;
      var hl = textLen(s.b.text);
      if (hl > 140) continue;
      if (usedHeadings + hl > headCap) break;
      chosen.add(s.idx);
      usedHeadings += hl;
      usedHead += hl;
    }

    // 2.2 按信息密度填头部
    var byScore = scored.slice().sort(function (a, b) { return b.score - a.score; });
    for (i = 0; i < byScore.length; i++) {
      var cand = byScore[i];
      if (chosen.has(cand.idx)) continue;
      var cl = textLen(cand.b.text);
      if (usedHead + cl > headBudget) continue;
      chosen.add(cand.idx);
      usedHead += cl;
    }

    // 2.3 尾部保底：结尾段落常是结论/总结
    var usedTail = 0;
    for (i = scored.length - 1; i >= 0; i--) {
      var tb = scored[i];
      if (chosen.has(tb.idx)) continue;
      var tl = textLen(tb.b.text);
      if (usedTail + tl > tailBudget) continue;
      chosen.add(tb.idx);
      usedTail += tl;
    }

    // 2.4 按 DOM 顺序输出，标出省略
    var parts = [];
    var keptChars = 0;
    var prevIdx = -1;
    for (i = 0; i < clean.length; i++) {
      if (!chosen.has(i)) continue;
      if (prevIdx >= 0 && i - prevIdx > 1) {
        var gap = 0;
        for (var g = prevIdx + 1; g < i; g++) gap += textLen(clean[g].text);
        if (gap > 160) parts.push('……（此处省略约 ' + gap + ' 字）……');
      }
      parts.push(clean[i].text);
      keptChars += textLen(clean[i].text);
      prevIdx = i;
    }

    var text = parts.join('\n');
    return {
      text: text,
      chars: textLen(text),
      totalChars: totalChars,
      kept: chosen.size,
      total: clean.length,
      omittedChars: Math.max(0, totalChars - keptChars),
      truncated: true
    };
  }

  /* =======================================================================
   * 3. 句子打分（本地兜底 & γ 证据）
   * ===================================================================== */

  function jaccard(aTokens, bTokens) {
    var A = new Set(aTokens);
    var B = new Set(bTokens);
    if (!A.size || !B.size) return 0;
    var inter = 0;
    A.forEach(function (t) { if (B.has(t)) inter++; });
    return inter / (A.size + B.size - inter);
  }

  /**
   * extractive 打分：词频权重 / 长度归一 + 位置加成 + 数字加成 + 标题词加成。
   * 返回按分数降序、且互相不重复（Jaccard < 0.6）的句子。
   */
  function scoreSentences(text, terms, opts) {
    var o = opts || {};
    var sentences = splitSentences(text);
    if (!sentences.length) return [];

    var weight = new Map();
    var list = terms || [];
    if (list.length && typeof list[0] === 'object') {
      for (var t = 0; t < list.length; t++) weight.set(list[t].term, list[t].count);
    } else {
      for (var t2 = 0; t2 < list.length; t2++) weight.set(list[t2], 1);
    }
    var titleTerms = new Set(o.titleTerms || []);
    var n = sentences.length;

    var scored = sentences.map(function (s, idx) {
      var tokens = tokenize(s);
      var uniq = new Set(tokens);
      var raw = 0;
      uniq.forEach(function (tok) {
        var w = weight.get(tok);
        if (w) raw += Math.log(1 + w);
        if (titleTerms.has(tok)) raw += 0.45;
      });
      var norm = raw / Math.log(2 + tokens.length);
      var len = textLen(s);
      var s2 = norm;
      s2 += 0.3 * (1 - idx / n);                                     // 位置：越靠前越可能下结论
      var nums = (s.match(/\d+(?:[.,]\d+)?%?/g) || []).length;
      s2 += 0.28 * Math.min(nums, 3);                                // 数字 = 硬信息
      if (len < 12) s2 *= 0.4;
      if (len > 180) s2 *= 0.75;
      return { text: oneLine(s), score: s2, index: idx, tokens: tokens };
    });

    scored.sort(function (a, b) { return b.score - a.score; });
    var picked = [];
    var pickedTokens = [];
    for (var i = 0; i < scored.length; i++) {
      var cand = scored[i];
      var dup = false;
      for (var j = 0; j < pickedTokens.length; j++) {
        if (jaccard(cand.tokens, pickedTokens[j]) >= 0.6) { dup = true; break; }
      }
      if (dup) continue;
      picked.push(cand);
      pickedTokens.push(cand.tokens);
      if (picked.length >= (o.limit || 12)) break;
    }
    return picked;
  }

  /* =======================================================================
   * 4. 提示词
   * ===================================================================== */

  var LANG_LABEL = { zh: '简体中文', en: 'English' };

  function resolveLang(cfg, text) {
    var lang = (cfg && cfg.lang) || 'auto';
    if (lang === 'zh' || lang === 'en') return lang;
    return guessLanguage(text);
  }

  function buildSystemPrompt(cfg) {
    var maxCharsPerItem = clamp((cfg && cfg.maxCharsPerItem) || 60, 16, 200);
    var lang = (cfg && cfg.lang) || 'auto';
    var langLine = lang === 'auto'
      ? '输出语言：与网页正文主要语言一致。'
      : '输出语言：' + (LANG_LABEL[lang] || lang) + '。';
    return [
      '你是「一目十行」信息压缩引擎。任务只有一件：把给定网页正文压成恰好 3 条信息。',
      '',
      '【三条信息的分工，禁止混淆】',
      'alpha（阿尔法）：全文中最重要的、读者最先该知道的那一条核心结论。它应该能单独回答「这页到底在说什么」。',
      'beta（贝塔）：第二关键信息，且与 alpha 不重复。优先选「支撑 alpha 的关键证据/数据」，其次选「代价、风险、限制、条件、时间点」或「反方观点」。',
      'gamma（人说最多）：全页被重复、强调、引用、讨论次数最多的议题或主张。回答「大家反复在说什么」，不是「最重要的一条」。',
      '',
      '【硬性要求】',
      '1. 每条只写一句话，不超过 ' + maxCharsPerItem + ' 个字。信息密度最大化，直接给结论，禁止「本文介绍了」「整体来看」这类空话、禁止套话、禁止「总之」。',
      '2. 数字、专名、时间、金额、比例必须来自正文，一个字都不许编造或推算。正文没写就换一条。',
      '3. 三条之间不得同义改写、不得换皮重复。',
      '4. gamma 的 evidence 填 3~6 个正文里真实出现的高频词或短语（原词，不要改写）。',
      '5. ' + langLine,
      '6. 只输出 JSON 对象，不要解释、不要寒暄、不要 markdown 代码块。',
      '',
      '【输出格式】',
      '{"alpha":{"text":"..."},"beta":{"text":"..."},"gamma":{"text":"...","evidence":["词1","词2","词3"]}}'
    ].join('\n');
  }

  function buildUserPrompt(input, cfg, packed) {
    var lines = [];
    lines.push('【网页标题】' + (oneLine(input.title) || '（无标题）'));
    lines.push('【网址】' + (input.url || ''));
    lines.push('【语言】' + resolveLang(cfg, input.text));
    if (input.terms && input.terms.length) {
      lines.push('【本地高频词（仅作 γ 的参考，务必核对原文）】' + input.terms.slice(0, 14).map(function (t) {
        return t.term + '×' + t.count;
      }).join('、'));
    }
    lines.push('【正文总长】约 ' + (input.text || '').length + ' 字' + (packed && packed.truncated
      ? '，已按信息密度压缩到 ' + packed.chars + ' 字（省略 ' + packed.omittedChars + ' 字）'
      : '，全文给出'));
    lines.push('');
    lines.push('【正文开始】');
    lines.push((packed && packed.text) || input.text || '');
    lines.push('【正文结束】');
    lines.push('');
    lines.push('现在输出那个 JSON 对象。');
    return lines.join('\n');
  }

  function buildMessages(input, cfg) {
    // 内容脚本已经按预算压缩过一次时（preCompressed）直接复用，避免二次裁剪丢失信息
    var packed = input.preCompressed && input.preCompressed.text
      ? {
        text: input.preCompressed.text,
        chars: input.preCompressed.chars || textLen(input.preCompressed.text),
        truncated: !!input.preCompressed.truncated,
        omittedChars: input.preCompressed.omittedChars || 0
      }
      : budgetBlocks(input.blocks || [], { maxChars: (cfg && cfg.maxChars) || DEFAULTS_INPUT.maxChars });
    var body = packed.text || normalizeSpace(input.text || '');
    return {
      messages: [
        { role: 'system', content: buildSystemPrompt(cfg) },
        {
          role: 'user',
          content: buildUserPrompt(
            { title: input.title, url: input.url, text: input.text, terms: input.terms },
            cfg,
            { text: body, chars: textLen(body), truncated: packed.truncated, omittedChars: packed.omittedChars }
          )
        }
      ],
      packed: packed,
      inputChars: textLen(body),
      inputTokens: estimateTokens(body)
    };
  }

  /* =======================================================================
   * 5. 输出解析
   * ===================================================================== */

  /** 从模型返回里抽出第一个完整的 JSON 对象（容忍 ```json 围栏与前后废话） */
  function extractJsonObject(raw) {
    var s = String(raw == null ? '' : raw).trim();
    if (!s) return null;

    var fenced = s.match(/```(?:json|JSON)?\s*([\s\S]*?)```/);
    if (fenced) s = fenced[1].trim();

    try { return JSON.parse(s); } catch (e) { /* 继续找 */ }

    var start = -1;
    for (var i = 0; i < s.length; i++) {
      if (s[i] === '{') { start = i; break; }
    }
    if (start < 0) return null;

    var depth = 0;
    var inStr = false;
    var esc = false;
    for (var j = start; j < s.length; j++) {
      var ch = s[j];
      if (inStr) {
        if (esc) esc = false;
        else if (ch === '\\') esc = true;
        else if (ch === '"') inStr = false;
        continue;
      }
      if (ch === '"') { inStr = true; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) {
          var candidate = s.slice(start, j + 1);
          try { return JSON.parse(candidate); } catch (e2) { return null; }
        }
      }
    }
    return null;
  }

  function stripDecorations(text) {
    var s = oneLine(text);
    s = s.replace(/```[a-zA-Z]*/g, '');
    s = s.replace(/\*\*/g, '');                                            // 先干掉 markdown 粗体
    s = s.replace(/^\s*[*\-•·]\s*/, '');                                    // 再去列表符号
    s = s.replace(/^\s*(?:\d+\s*[.、)）]|\([^)]{0,4}\)|\[[^\]]{0,6}\])\s*/, '');
    // 只剥「一层」标签前缀：模型可能写 γ 或「人说最多」，连剥两层会吃掉正文本身
    s = s.replace(/^\s*(?:(?:alpha|beta|gamma|α|β|γ)\s*[:：\-–—]\s*|(?:alpha|beta|gamma)\s+|(?:阿尔法|贝塔|人说最多|人说得最多|高频|热议)\s*[:：\-–—]\s*)/i, '');
    s = s.replace(/^[「『"'"'“‘]+/, '');
    s = s.replace(/[」』"'"'”’]+$/, '');
    s = s.replace(/^\s*[:：\-–—]\s*/, '');
    return oneLine(s);
  }

  function clampItem(text, maxCharsPerItem) {
    var limit = clamp(maxCharsPerItem || 60, 16, 200);
    var s = stripDecorations(text);
    if (textLen(s) <= limit) return s;

    var head = s.slice(0, Math.round(limit * 1.35));
    // 优先切在真句读上（句号/问号/分号），实在没有才退到逗号/空格
    var ends = ['。', '！', '？', '；', '.', '!', '?', ';'];
    var cut = -1;
    for (var i = 0; i < ends.length; i++) cut = Math.max(cut, head.lastIndexOf(ends[i]));
    if (cut >= limit * 0.5) return head.slice(0, cut + 1);
    var soft = Math.max(head.lastIndexOf('，'), head.lastIndexOf(','), head.lastIndexOf(' '));
    if (soft >= limit * 0.6) return head.slice(0, soft) + '…';
    return s.slice(0, limit - 1) + '…';
  }

  function valueToItem(key, value, maxCharsPerItem) {
    var text = '';
    var evidence = [];
    if (typeof value === 'string') {
      text = value;
    } else if (value && typeof value === 'object') {
      text = value.text || value.content || value.value || value.summary || value.info || '';
      if (typeof value.evidence === 'string') evidence = [value.evidence];
      else if (Array.isArray(value.evidence)) evidence = value.evidence;
      else if (Array.isArray(value.keywords)) evidence = value.keywords;
      else if (Array.isArray(value.terms)) evidence = value.terms;
    }
    return {
      key: key,
      label: ITEM_META[key].label,
      badge: ITEM_META[key].badge,
      text: clampItem(text, maxCharsPerItem),
      evidence: evidence.map(function (e) { return oneLine(String(e)).slice(0, 24); }).filter(Boolean).slice(0, 6)
    };
  }

  /**
   * 把模型输出解析成恰好 3 条（顺序固定 α/β/γ）。
   * 支持三种形态：规范 JSON / items 数组 / 纯文本编号列表。
   */
  function parseSummary(raw, opts) {
    var o = opts || {};
    var maxCharsPerItem = o.maxCharsPerItem || 60;
    var warnings = [];
    var items = { alpha: null, beta: null, gamma: null };

    var obj = extractJsonObject(raw);
    if (obj && typeof obj === 'object') {
      if (Array.isArray(obj.items)) {
        for (var i = 0; i < obj.items.length && i < 3; i++) {
          var it = obj.items[i];
          var k = ITEM_KEYS[i];
          if (it && typeof it === 'object') {
            if (typeof it.key === 'string' && ITEM_META[it.key]) k = it.key;
            else if (typeof it.role === 'string' && ITEM_META[it.role]) k = it.role;
          }
          if (!items[k]) items[k] = valueToItem(k, it, maxCharsPerItem);
        }
      }
      for (var ki = 0; ki < ITEM_KEYS.length; ki++) {
        var key = ITEM_KEYS[ki];
        if (items[key]) continue;
        var hit = pickKeyFor(key, obj);
        if (hit != null) items[key] = valueToItem(key, hit, maxCharsPerItem);
      }
    }

    if (!items.alpha && !items.beta && !items.gamma) {
      var lines = String(raw == null ? '' : raw).split(/\n+/).map(function (x) { return x.trim(); }).filter(Boolean);
      var texts = [];
      for (var li = 0; li < lines.length; li++) {
        var line = lines[li];
        if (/^[\[{]/.test(line)) continue;
        if (/^```/.test(line)) continue;
        var cleaned = stripDecorations(line);
        if (textLen(cleaned) < 6) continue;
        texts.push(cleaned);
        if (texts.length >= 3) break;
      }
      for (var ti = 0; ti < texts.length; ti++) {
        items[ITEM_KEYS[ti]] = valueToItem(ITEM_KEYS[ti], texts[ti], maxCharsPerItem);
      }
      if (texts.length) warnings.push('模型未返回规范 JSON，已按编号列表降级解析。');
    }

    var ordered = [];
    var seen = [];
    for (var oi = 0; oi < ITEM_KEYS.length; oi++) {
      var kk = ITEM_KEYS[oi];
      var item = items[kk];
      if (!item || !item.text) {
        warnings.push(ITEM_META[kk].label + '缺失。');
        item = { key: kk, label: ITEM_META[kk].label, badge: ITEM_META[kk].badge, text: '', evidence: [] };
      } else {
        var flat = item.text.replace(/\s+/g, '');
        if (seen.indexOf(flat) >= 0) {
          warnings.push(ITEM_META[kk].label + '与前面的条目重复。');
          item.duplicate = true;
        } else {
          seen.push(flat);
        }
      }
      ordered.push(item);
    }

    return {
      ok: ordered.every(function (x) { return !!x.text; }),
      items: ordered,
      warnings: warnings
    };
  }

  /** pickKey 只返回命中的第一个别名，这里按 key 精确取 */
  function pickKeyFor(key, obj) {
    var aliases = {
      alpha: ['alpha', 'Alpha', 'ALPHA', 'α', '阿尔法', 'core', 'main'],
      beta: ['beta', 'Beta', 'BETA', 'β', '贝塔', 'second', 'risk'],
      gamma: ['gamma', 'Gamma', 'GAMMA', 'γ', '人说最多', '人说得最多', '高频', '热议', 'most', 'repeat']
    }[key];
    for (var i = 0; i < aliases.length; i++) {
      if (Object.prototype.hasOwnProperty.call(obj, aliases[i]) && obj[aliases[i]] != null) {
        return obj[aliases[i]];
      }
    }
    return null;
  }

  /* =======================================================================
   * 6. 本地兜底：没有 Key / 调用失败时也要给出 3 条
   * ===================================================================== */

  function localFallback(input, opts) {
    var o = opts || {};
    var maxCharsPerItem = o.maxCharsPerItem || 60;
    var text = String((input && input.text) || '');
    var title = oneLine((input && input.title) || '');

    var bodyTerms = topTerms(text, { limit: 14, minCount: 2 });
    var titleTerms = topTerms(title, { limit: 8, minCount: 1 });
    var titleTermSet = new Set(titleTerms.map(function (t) { return t.term; }));

    var sents = scoreSentences(text, bodyTerms, { titleTerms: titleTermSet, limit: 8 });

    function mk(key, value) {
      return valueToItem(key, value, maxCharsPerItem);
    }

    var alpha = mk('alpha', sents[0] ? sents[0].text : (title || text.slice(0, maxCharsPerItem)));
    var beta = mk('beta', sents[1] ? sents[1].text : (sents[0] ? sents[0].text : ''));

    var gamma;
    if (bodyTerms.length >= 2) {
      var words = bodyTerms.slice(0, 3).map(function (t) { return t.term; });
      var counts = bodyTerms.slice(0, 3).map(function (t) { return t.count; });
      var topic = words.join('、');
      var detail = counts.join('/');
      var support = sents.slice(0, 5).sort(function (a, b) {
        var hitA = 0;
        var hitB = 0;
        words.forEach(function (w) {
          if (a.text.indexOf(w) >= 0) hitA++;
          if (b.text.indexOf(w) >= 0) hitB++;
        });
        return hitB - hitA;
      })[0];
      gamma = mk('gamma', {
        text: '反复出现最多的议题是「' + topic + '」（提及 ' + detail + ' 次）' +
          (support && support.text.indexOf(words[0]) >= 0 ? '，代表原句：' + support.text : '。'),
        evidence: words
      });
    } else {
      gamma = mk('gamma', '正文过短，无法统计高频议题。');
    }

    var parsed = parseSummary(JSON.stringify({
      alpha: { text: alpha.text },
      beta: { text: beta.text },
      gamma: { text: gamma.text, evidence: gamma.evidence }
    }), { maxCharsPerItem: maxCharsPerItem });

    parsed.source = 'local';
    parsed.warnings = parsed.warnings.concat(['本结果由本地词频+句子打分生成（未调用模型），精度低于 AI 摘要。']);
    return parsed;
  }

  /* =======================================================================
   * 7. LLM 客户端（OpenAI 兼容 /chat/completions）
   * ===================================================================== */

  function srError(code, message, hint, extra) {
    var err = new Error(message || code);
    err.code = code;
    if (hint) err.hint = hint;
    if (extra) {
      for (var k in extra) {
        if (Object.prototype.hasOwnProperty.call(extra, k)) err[k] = extra[k];
      }
    }
    return err;
  }

  function resolveChatUrl(baseUrl) {
    var u = String(baseUrl || '').trim().replace(/\/+$/, '');
    if (!u) return '';
    if (/\/chat\/completions$/i.test(u)) return u;
    if (/\/completions$/i.test(u)) return u.replace(/\/completions$/i, '/chat/completions');
    return u + '/chat/completions';
  }

  function classifyError(status, bodyText, err) {
    var snippet = String(bodyText || '').replace(/\s+/g, ' ').slice(0, 240);
    var s = status || 0;
    if (err && (err.name === 'AbortError' || err.code === 'ABORT_ERR')) {
      return { code: 'TIMEOUT', retryable: true, message: '请求超时。', hint: '网络慢或模型排队；可在设置里调大超时时间或换更快的模型。' };
    }
    if (err && err.name === 'TypeError') {
      return { code: 'NETWORK', retryable: true, message: '无法连接到模型服务。', hint: '检查 Base URL、网络/代理，以及该域名是否被拦。原文：' + snippet };
    }
    if (s === 400) return { code: 'BAD_REQUEST', retryable: false, message: '请求被拒（400）。', hint: '多半是模型名不对，或该网关不支持 JSON 输出模式。原文：' + snippet };
    if (s === 401 || s === 403) return { code: 'AUTH', retryable: false, message: 'API Key 无效或被拒（' + s + '）。', hint: '到设置页重新粘贴 Key，注意不要带 Bearer 前缀和首尾空格。' };
    if (s === 402) return { code: 'QUOTA', retryable: false, message: '账户余额/额度不足（402）。', hint: '去服务商充值或换一个有余额的 Key。' };
    if (s === 404) return { code: 'NOT_FOUND', retryable: false, message: '接口地址或模型不存在（404）。', hint: 'Base URL 应形如 https://xxx/v1（不要带 /chat/completions），模型名要写全。原文：' + snippet };
    if (s === 408 || s === 504) return { code: 'TIMEOUT', retryable: true, message: '网关超时（' + s + '）。', hint: '稍后重试或换模型。' };
    if (s === 413) return { code: 'TOO_LARGE', retryable: false, message: '正文太长被拒（413）。', hint: '把「单次送入模型的字数上限」调小，例如 4000。' };
    if (s === 429) return { code: 'RATE_LIMIT', retryable: true, message: '触发限流（429）。', hint: '等几秒再试；把自动更新的最小间隔调大一些。' };
    if (s >= 500) return { code: 'SERVER', retryable: true, message: '模型服务端错误（' + s + '）。', hint: '服务商临时故障，稍后重试。原文：' + snippet };
    return { code: 'UNKNOWN', retryable: false, message: '请求失败' + (s ? '（HTTP ' + s + '）' : '') + '。', hint: snippet || '未知错误。' };
  }

  function buildRequestBody(cfg, messages, opts) {
    var o = opts || {};
    var body = {
      model: cfg.model,
      messages: messages,
      temperature: clamp(cfg.temperature == null ? 0.2 : cfg.temperature, 0, 2),
      max_tokens: clamp(cfg.maxTokens || 700, 64, 8192),
      stream: false
    };
    if (o.jsonMode) body.response_format = { type: 'json_object' };
    return body;
  }

  function readContent(json) {
    var choice = json && json.choices && json.choices[0];
    if (!choice) return '';
    var msg = choice.message || choice.delta || {};
    var content = msg.content;
    if (typeof content === 'string') return content;
    if (Array.isArray(content)) {
      return content.map(function (part) {
        if (typeof part === 'string') return part;
        if (part && typeof part.text === 'string') return part.text;
        return '';
      }).join('');
    }
    if (typeof choice.text === 'string') return choice.text;
    return '';
  }

  /**
   * 调一次 OpenAI 兼容 chat completions。
   * 注入 fetchImpl 才能单测；超时用 AbortController；429/5xx/网络错误按 retries 退避重试。
   */
  async function callChat(options) {
    var o = options || {};
    var cfg = o.cfg || {};
    var fetchImpl = o.fetchImpl;
    if (typeof fetchImpl !== 'function') throw srError('NO_FETCH', '缺少 fetch 实现。');
    var url = resolveChatUrl(cfg.baseUrl);
    if (!url) throw srError('NO_BASE_URL', '还没配置模型接口地址。', '打开扩展设置，选一个服务商预设或手填 Base URL。');
    if (!cfg.model) throw srError('NO_MODEL', '还没配置模型名。', '在设置页填写模型名，例如 deepseek-chat。');
    if (!cfg.apiKey) throw srError('NO_KEY', '还没配置 API Key。', '打开扩展设置填入 Key。');

    var timeoutMs = clamp(cfg.timeoutMs || 20000, 3000, 180000);
    var maxAttempts = 1 + clamp(cfg.retries == null ? 1 : cfg.retries, 0, 3);
    var jsonMode = o.jsonMode !== false;
    var started = now();
    var lastError = null;

    for (var attempt = 1; attempt <= maxAttempts; attempt++) {
      var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var timer = null;
      if (controller) {
        timer = setTimeout(function () { controller.abort(); }, timeoutMs);
      }
      try {
        var headers = {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + cfg.apiKey
        };
        if (o.extraHeaders) {
          for (var hk in o.extraHeaders) {
            if (Object.prototype.hasOwnProperty.call(o.extraHeaders, hk)) headers[hk] = o.extraHeaders[hk];
          }
        }
        var res = await fetchImpl(url, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify(buildRequestBody(cfg, o.messages, { jsonMode: jsonMode })),
          signal: controller ? controller.signal : undefined
        });
        var text = await res.text();
        if (!res.ok) {
          var info = classifyError(res.status, text, null);
          // 许多网关不支持 response_format：400 时自动去掉再试一次，不算重试次数
          if (res.status === 400 && jsonMode) {
            jsonMode = false;
            if (timer) clearTimeout(timer);
            attempt--;
            continue;
          }
          if (info.retryable && attempt < maxAttempts) {
            lastError = srError(info.code, info.message, info.hint, { status: res.status });
            if (timer) clearTimeout(timer);
            await sleep(500 * Math.pow(2, attempt - 1));
            continue;
          }
          throw srError(info.code, info.message, info.hint, { status: res.status, body: text.slice(0, 600) });
        }
        var json;
        try {
          json = JSON.parse(text);
        } catch (parseErr) {
          throw srError('BAD_RESPONSE', '模型服务返回的不是 JSON。', '检查 Base URL 是否指向 OpenAI 兼容接口。原文：' + text.replace(/\s+/g, ' ').slice(0, 200));
        }
        var content = readContent(json);
        if (!content || !String(content).trim()) {
          throw srError('EMPTY_CONTENT', '模型返回了空内容。', '可能被内容策略拦截，或 max_tokens 太小。');
        }
        return {
          text: String(content),
          usage: json.usage || null,
          model: json.model || cfg.model,
          jsonModeUsed: jsonMode,
          ms: now() - started,
          attempts: attempt,
          url: url
        };
      } catch (err) {
        // 我们自己抛的（BAD_RESPONSE / EMPTY_CONTENT 等）分类不出来，直接上抛
        if (err && err.code && classifyError(0, '', err).code === 'UNKNOWN') throw err;
        var mapped = classifyError(0, '', err);
        if (mapped.retryable && attempt < maxAttempts) {
          lastError = srError(mapped.code, mapped.message, mapped.hint);
          if (timer) clearTimeout(timer);
          await sleep(500 * Math.pow(2, attempt - 1));
          continue;
        }
        throw srError(mapped.code, mapped.message, mapped.hint);
      } finally {
        if (timer) clearTimeout(timer);
      }
    }
    throw lastError || srError('UNKNOWN', '请求失败。');
  }

  /* =======================================================================
   * 8. 编排
   * ===================================================================== */

  function validateConfig(cfg) {
    var issues = [];
    if (!cfg) return { ok: false, issues: ['没有配置。'] };
    if (!String(cfg.baseUrl || '').trim()) issues.push('缺少 Base URL');
    if (!String(cfg.model || '').trim()) issues.push('缺少模型名');
    if (!String(cfg.apiKey || '').trim()) issues.push('缺少 API Key');
    return { ok: issues.length === 0, issues: issues };
  }

  function cacheKeyOf(fingerprint, cfg) {
    var host = '';
    try { host = new URL(resolveChatUrl(cfg.baseUrl)).host; } catch (e) { host = String(cfg.baseUrl || ''); }
    return [
      'sr.cache',
      fingerprint,
      host,
      cfg.model || '',
      cfg.lang || 'auto',
      String(cfg.maxCharsPerItem || 60),
      String(cfg.maxChars || 6000),
      cfg.fallbackLocal === false ? 'nolocal' : 'local'
    ].join('|');
  }

  /**
   * 主流程：模型优先；任何失败且在允许兜底时，退到本地 extractive，保证面板永远有 3 条。
   * 返回统一 schema：{ok, source, items, warnings, meta}，失败时 ok=false 且带 error。
   */
  async function summarizeWithLLM(input, cfg, options) {
    var o = options || {};
    var started = now();
    var warnings = [];
    var terms = (input.terms && input.terms.length ? input.terms : topTerms(input.text || '', { limit: 14, minCount: 2 }));
    var prepared = buildMessages({ title: input.title, url: input.url, text: input.text, blocks: input.blocks, terms: terms }, cfg);
    var meta = {
      fingerprint: input.fingerprint || contentFingerprint(input),
      inputChars: prepared.inputChars,
      inputTokens: prepared.inputTokens,
      compressed: prepared.packed.truncated,
      omittedChars: prepared.packed.omittedChars,
      model: cfg.model || '',
      endpointHost: '',
      ms: 0,
      usage: null
    };
    try { meta.endpointHost = new URL(resolveChatUrl(cfg.baseUrl)).host; } catch (e) { meta.endpointHost = ''; }

    var configCheck = validateConfig(cfg);
    if (!configCheck.ok) {
      if (cfg.fallbackLocal === false) {
        return {
          ok: false,
          source: 'none',
          items: [],
          warnings: warnings,
          meta: meta,
          error: { code: 'NO_KEY', message: '还没配置模型：' + configCheck.issues.join('、'), hint: '打开扩展设置填入 API 信息；或打开「本地兜底」先看 3 条。' }
        };
      }
      var localOnly = localFallback(input, { maxCharsPerItem: cfg.maxCharsPerItem });
      meta.ms = now() - started;
      return {
        ok: true,
        source: 'local',
        items: localOnly.items,
        warnings: localOnly.warnings,
        meta: meta,
        error: { code: 'NO_KEY', message: '未配置模型（' + configCheck.issues.join('、') + '），已用本地兜底。', hint: '打开扩展设置填入 API 信息以获得 AI 摘要。' }
      };
    }

    try {
      var call = await callChat({
        fetchImpl: o.fetchImpl,
        cfg: cfg,
        messages: prepared.messages,
        jsonMode: true
      });
      meta.usage = call.usage;
      meta.model = call.model;
      meta.attempts = call.attempts;
      meta.jsonModeUsed = call.jsonModeUsed;

      var parsed = parseSummary(call.text, { maxCharsPerItem: cfg.maxCharsPerItem });

      // 解析失败 / 条目缺失：用更强的约束再要一次（最多 cfg.repairAttempts 次）
      var repairs = clamp(o.repairAttempts == null ? 1 : o.repairAttempts, 0, 2);
      for (var r = 0; r < repairs && !parsed.ok; r++) {
        var repairMessages = prepared.messages.concat([
          { role: 'assistant', content: String(call.text).slice(0, 1500) },
          {
            role: 'user',
            content: '上一个回答不合格：必须恰好给出 alpha / beta / gamma 三个非空 text。只输出这一个 JSON 对象，不要任何其他字符。'
          }
        ]);
        var retry = await callChat({ fetchImpl: o.fetchImpl, cfg: cfg, messages: repairMessages, jsonMode: true });
        call = retry;
        meta.usage = retry.usage;
        parsed = parseSummary(retry.text, { maxCharsPerItem: cfg.maxCharsPerItem });
        warnings.push('已自动重试一次以修正输出格式。');
      }

      meta.ms = now() - started;
      if (parsed.ok) {
        return { ok: true, source: 'llm', items: parsed.items, warnings: warnings.concat(parsed.warnings), meta: meta };
      }
      warnings.push('模型输出无法解析为 3 条。');
      if (cfg.fallbackLocal === false) {
        return {
          ok: false,
          source: 'none',
          items: [],
          warnings: warnings,
          meta: meta,
          error: { code: 'BAD_OUTPUT', message: '模型输出无法解析成 3 条。', hint: '换一个更强的模型（如 gpt-4o-mini / deepseek-chat）再试。' }
        };
      }
      var localFromBad = localFallback(input, { maxCharsPerItem: cfg.maxCharsPerItem });
      return { ok: true, source: 'local', items: localFromBad.items, warnings: warnings.concat(localFromBad.warnings), meta: meta };
    } catch (err) {
      meta.ms = now() - started;
      var error = {
        code: err.code || 'UNKNOWN',
        message: err.message || String(err),
        hint: err.hint || ''
      };
      if (cfg.fallbackLocal === false) {
        return { ok: false, source: 'none', items: [], warnings: warnings, meta: meta, error: error };
      }
      var local = localFallback(input, { maxCharsPerItem: cfg.maxCharsPerItem });
      return {
        ok: true,
        source: 'local',
        items: local.items,
        warnings: warnings.concat(local.warnings, [error.message]),
        meta: meta,
        error: error
      };
    }
  }

  /* =======================================================================
   * 导出
   * ===================================================================== */

  return {
    VERSION: VERSION,
    ITEM_KEYS: ITEM_KEYS,
    ITEM_META: ITEM_META,
    DEFAULT_LLM: DEFAULT_LLM,
    DEFAULTS_INPUT: DEFAULTS_INPUT,
    // 文本度量
    normalizeSpace: normalizeSpace,
    oneLine: oneLine,
    textLen: textLen,
    isCJKChar: isCJKChar,
    cjkRatio: cjkRatio,
    guessLanguage: guessLanguage,
    estimateTokens: estimateTokens,
    tokenize: tokenize,
    termFrequency: termFrequency,
    topTerms: topTerms,
    splitSentences: splitSentences,
    hash32: hash32,
    normalizeUrl: normalizeUrl,
    contentFingerprint: contentFingerprint,
    // 压缩
    blockScore: blockScore,
    dedupeBlocks: dedupeBlocks,
    budgetBlocks: budgetBlocks,
    // 打分
    jaccard: jaccard,
    scoreSentences: scoreSentences,
    // 提示词 & 解析
    buildSystemPrompt: buildSystemPrompt,
    buildUserPrompt: buildUserPrompt,
    buildMessages: buildMessages,
    extractJsonObject: extractJsonObject,
    stripDecorations: stripDecorations,
    clampItem: clampItem,
    parseSummary: parseSummary,
    localFallback: localFallback,
    resolveLang: resolveLang,
    // LLM
    srError: srError,
    resolveChatUrl: resolveChatUrl,
    classifyError: classifyError,
    buildRequestBody: buildRequestBody,
    readContent: readContent,
    callChat: callChat,
    validateConfig: validateConfig,
    cacheKeyOf: cacheKeyOf,
    summarizeWithLLM: summarizeWithLLM
  };
});
