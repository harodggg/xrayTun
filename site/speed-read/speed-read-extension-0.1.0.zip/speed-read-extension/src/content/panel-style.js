/**
 * 一目十行 · 面板样式
 * ---------------------------------------------------------------------------
 * 全部样式塞进 Shadow Root，宿主页面的 CSS 进不来、我们的 CSS 也出不去。
 * 用 CSS 变量接收设置页的宽度/字号/透明度，主题靠 [data-theme] 切换。
 */
'use strict';

self.__SR_PANEL_CSS = `
:host{all:initial;}
*,*::before,*::after{box-sizing:border-box;}
.sr-panel{
  --sr-fs:13px;
  position:relative;
  font:400 var(--sr-fs)/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",system-ui,sans-serif;
  color:#e6edf3;
  background:linear-gradient(180deg,rgba(22,27,34,.98),rgba(13,17,23,.98));
  border:1px solid rgba(240,246,252,.14);
  border-radius:14px;
  box-shadow:0 12px 32px rgba(0,0,0,.42),0 2px 6px rgba(0,0,0,.3);
  overflow:hidden;
  backdrop-filter:blur(10px);
  -webkit-backdrop-filter:blur(10px);
}
.sr-panel[data-theme="light"]{
  color:#1f2328;
  background:linear-gradient(180deg,rgba(255,255,255,.99),rgba(246,248,250,.99));
  border-color:rgba(31,35,40,.16);
  box-shadow:0 12px 32px rgba(31,35,40,.2),0 2px 6px rgba(31,35,40,.12);
}
.sr-bar{
  display:flex;align-items:center;gap:6px;
  padding:6px 7px 6px 10px;
  cursor:grab;user-select:none;
  background:rgba(255,255,255,.045);
  border-bottom:1px solid rgba(240,246,252,.1);
}
.sr-panel[data-theme="light"] .sr-bar{background:rgba(31,35,40,.04);border-bottom-color:rgba(31,35,40,.1);}
.sr-bar:active{cursor:grabbing;}
.sr-dot{width:7px;height:7px;border-radius:50%;background:#6e7681;flex:0 0 auto;box-shadow:0 0 0 3px rgba(110,118,129,.16);}
.sr-dot[data-s="loading"]{background:#d29922;animation:sr-pulse 1s ease-in-out infinite;}
.sr-dot[data-s="ok"]{background:#3fb950;box-shadow:0 0 0 3px rgba(63,185,80,.16);}
.sr-dot[data-s="local"]{background:#d29922;box-shadow:0 0 0 3px rgba(210,153,34,.16);}
.sr-dot[data-s="error"]{background:#f85149;box-shadow:0 0 0 3px rgba(248,81,73,.16);}
.sr-dot[data-s="idle"]{background:#6e7681;}
@keyframes sr-pulse{0%,100%{opacity:1;}50%{opacity:.35;}}
.sr-brand{font-weight:650;font-size:calc(var(--sr-fs) - 1px);letter-spacing:.02em;white-space:nowrap;}
.sr-status{
  flex:1 1 auto;min-width:0;
  font-size:calc(var(--sr-fs) - 2.5px);opacity:.66;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.sr-tools{display:flex;align-items:center;gap:2px;flex:0 0 auto;}
.sr-btn{
  all:unset;cursor:pointer;
  width:20px;height:20px;border-radius:6px;
  display:flex;align-items:center;justify-content:center;
  font-size:calc(var(--sr-fs) - 1px);line-height:1;opacity:.6;
  transition:background .12s ease,opacity .12s ease;
}
.sr-btn:hover{background:rgba(255,255,255,.12);opacity:1;}
.sr-panel[data-theme="light"] .sr-btn:hover{background:rgba(31,35,40,.1);}
.sr-btn[disabled]{opacity:.25;cursor:default;}
.sr-body{display:block;}
.sr-rows{margin:0;padding:0;list-style:none;max-height:62vh;overflow-y:auto;overscroll-behavior:contain;}
.sr-row{
  display:grid;grid-template-columns:24px 1fr;gap:9px;
  padding:8px 11px 8px 9px;
  cursor:pointer;
}
.sr-row + .sr-row{border-top:1px solid rgba(240,246,252,.075);}
.sr-panel[data-theme="light"] .sr-row + .sr-row{border-top-color:rgba(31,35,40,.08);}
.sr-row:hover{background:rgba(255,255,255,.04);}
.sr-panel[data-theme="light"] .sr-row:hover{background:rgba(31,35,40,.035);}
.sr-badge{
  width:22px;height:22px;border-radius:7px;
  display:flex;align-items:center;justify-content:center;
  font-size:calc(var(--sr-fs) - 1px);font-weight:700;line-height:1;
  margin-top:1px;
}
.sr-badge[data-k="alpha"]{background:rgba(88,166,255,.18);color:#79c0ff;border:1px solid rgba(88,166,255,.38);}
.sr-badge[data-k="beta"]{background:rgba(210,153,34,.18);color:#e3b341;border:1px solid rgba(210,153,34,.38);}
.sr-badge[data-k="gamma"]{background:rgba(63,185,80,.18);color:#56d364;border:1px solid rgba(63,185,80,.38);}
.sr-panel[data-theme="light"] .sr-badge[data-k="alpha"]{background:rgba(9,105,218,.1);color:#0969da;border-color:rgba(9,105,218,.3);}
.sr-panel[data-theme="light"] .sr-badge[data-k="beta"]{background:rgba(154,103,0,.1);color:#9a6700;border-color:rgba(154,103,0,.3);}
.sr-panel[data-theme="light"] .sr-badge[data-k="gamma"]{background:rgba(26,127,55,.1);color:#1a7f37;border-color:rgba(26,127,55,.3);}
.sr-main{min-width:0;}
.sr-text{
  display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;
  overflow:hidden;word-break:break-word;
  font-weight:500;
}
.sr-row[data-expanded="1"] .sr-text{-webkit-line-clamp:unset;display:block;}
.sr-ev{
  margin-top:3px;font-size:calc(var(--sr-fs) - 3px);opacity:.55;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.sr-foot{
  display:flex;align-items:center;gap:6px;flex-wrap:wrap;
  padding:5px 10px;border-top:1px solid rgba(240,246,252,.075);
  font-size:calc(var(--sr-fs) - 3.5px);opacity:.6;
}
.sr-panel[data-theme="light"] .sr-foot{border-top-color:rgba(31,35,40,.08);}
.sr-tag{
  padding:1px 5px;border-radius:5px;
  background:rgba(255,255,255,.09);
}
.sr-panel[data-theme="light"] .sr-tag{background:rgba(31,35,40,.07);}
.sr-tag[data-warn="1"]{background:rgba(210,153,34,.22);color:#e3b341;}
.sr-msg{padding:12px 12px 14px;font-size:calc(var(--sr-fs) - 1px);}
.sr-msg-title{font-weight:600;margin-bottom:4px;}
.sr-msg-hint{opacity:.62;font-size:calc(var(--sr-fs) - 2px);line-height:1.5;}
.sr-msg-actions{display:flex;gap:6px;margin-top:9px;}
.sr-link{
  all:unset;cursor:pointer;
  padding:4px 9px;border-radius:7px;font-size:calc(var(--sr-fs) - 2px);
  background:rgba(88,166,255,.16);color:#79c0ff;border:1px solid rgba(88,166,255,.32);
}
.sr-link:hover{background:rgba(88,166,255,.26);}
.sr-panel[data-theme="light"] .sr-link{background:rgba(9,105,218,.1);color:#0969da;border-color:rgba(9,105,218,.28);}
.sr-skel{padding:9px 11px;display:grid;grid-template-columns:24px 1fr;gap:9px;}
.sr-skel-i{height:11px;border-radius:5px;background:linear-gradient(90deg,rgba(255,255,255,.09),rgba(255,255,255,.2),rgba(255,255,255,.09));background-size:200% 100%;animation:sr-shim 1.25s linear infinite;}
.sr-skel-i:first-child{grid-column:1;}
.sr-skel-i:nth-child(2){grid-column:2;width:92%;}
.sr-skel-i:nth-child(3){grid-column:2;width:70%;}
@keyframes sr-shim{0%{background-position:200% 0;}100%{background-position:-200% 0;}}
.sr-collapsed .sr-body{display:none;}
.sr-panel[data-hidden="1"]{display:none;}
@media (prefers-reduced-motion:reduce){
  .sr-dot[data-s="loading"],.sr-skel-i{animation:none;}
}
`;
