/**
 * 一目十行 · 后台 Service Worker
 * ---------------------------------------------------------------------------
 * 为什么所有模型调用都放在这里（而不是内容脚本里）：
 *   1) 内容脚本的 fetch 受宿主页面 CSP(connect-src) 约束，很多站点会直接掐掉请求；
 *      扩展 Service Worker 走扩展源，只受 manifest host_permissions 约束。
 *   2) API Key 只存在于扩展侧，内容脚本永远拿不到，页面里跑的第三方脚本更拿不到。
 *   3) 跨标签共享「内容指纹 → 结果」缓存，同一篇文章开两个标签只花一次钱。
 *
 * 这里负责：配置读取、黑名单、缓存、并发去重、限流、调用模型、降级、按标签存最近结果、通知面板。
 */
'use strict';

importScripts('../common/speedread-core.js', '../common/settings.js');

var Core = self.SpeedReadCore;
var Settings = self.SpeedReadSettings;

var CACHE_INDEX_KEY = 'sr.cacheIndex';
var CACHE_MAX_ENTRIES = 120;

/** 同一 cacheKey 正在飞的请求，避免同页多次 mutation 触发多次计费 */
var inflight = new Map();
/** tabId -> 上次真实调用时间 */
var lastCallByTab = new Map();
var settingsCache = null;

/* ------------------------------ 存储小工具 ------------------------------ */

function sessionArea() {
  try {
    if (chrome.storage && chrome.storage.session) return chrome.storage.session;
  } catch (e) { /* 老版本没有 session，退回 local */ }
  return chrome.storage.local;
}

function localArea() {
  return chrome.storage.local;
}

function areaGet(area, key, dflt) {
  return new Promise(function (resolve) {
    try {
      area.get(key, function (res) {
        if (chrome.runtime.lastError) return resolve(dflt);
        resolve(res && res[key] !== undefined ? res[key] : dflt);
      });
    } catch (e) {
      resolve(dflt);
    }
  });
}

function areaSet(area, patch) {
  return new Promise(function (resolve) {
    try {
      area.set(patch, function () { resolve(!chrome.runtime.lastError); });
    } catch (e) {
      resolve(false);
    }
  });
}

function areaRemove(area, keys) {
  return new Promise(function (resolve) {
    try {
      area.remove(keys, function () { resolve(true); });
    } catch (e) {
      resolve(false);
    }
  });
}

/* -------------------------------- 配置 -------------------------------- */

async function readSettings(force) {
  if (settingsCache && !force) return settingsCache;
  var raw = await areaGet(localArea(), Settings.STORAGE_KEY, null);
  settingsCache = Settings.mergeSettings(raw);
  return settingsCache;
}

chrome.storage.onChanged.addListener(function (changes, area) {
  if (area === 'local' && changes[Settings.STORAGE_KEY]) settingsCache = null;
});

/* -------------------------------- 缓存 -------------------------------- */

async function cacheGet(key, ttlMs) {
  if (ttlMs <= 0) return null;
  var entry = await areaGet(sessionArea(), key, null);
  if (!entry || !entry.at) return null;
  if (Date.now() - entry.at > ttlMs) return null;
  return entry;
}

async function cacheSet(key, value, ttlMs) {
  if (ttlMs <= 0) return;
  var area = sessionArea();
  var patch = {};
  patch[key] = Object.assign({ at: Date.now() }, value);
  await areaSet(area, patch);

  var index = await areaGet(area, CACHE_INDEX_KEY, []);
  if (!Array.isArray(index)) index = [];
  index = index.filter(function (row) { return row && row.k !== key; });
  index.push({ k: key, at: Date.now() });

  var keep = [];
  var drop = [];
  for (var i = index.length - 1; i >= 0; i--) {
    var row = index[i];
    var expired = Date.now() - row.at > Math.max(ttlMs, 60000);
    if (expired || keep.length >= CACHE_MAX_ENTRIES) drop.push(row.k);
    else keep.push(row);
  }
  keep.reverse();
  await areaSet(area, (function () {
    var p = {};
    p[CACHE_INDEX_KEY] = keep;
    return p;
  })());
  if (drop.length) await areaRemove(area, drop);
}

async function clearCache() {
  var area = sessionArea();
  var index = await areaGet(area, CACHE_INDEX_KEY, []);
  var keys = Array.isArray(index) ? index.map(function (r) { return r.k; }) : [];
  keys.push(CACHE_INDEX_KEY);
  await areaRemove(area, keys);
  return keys.length;
}

/* ------------------------------ 按标签状态 ------------------------------ */

function tabKey(tabId) {
  return Settings.TAB_PREFIX + tabId;
}

async function setTabState(tabId, state) {
  if (tabId == null) return;
  var patch = {};
  patch[tabKey(tabId)] = Object.assign({ at: Date.now() }, state);
  await areaSet(sessionArea(), patch);
}

async function getTabState(tabId) {
  return areaGet(sessionArea(), tabKey(tabId), null);
}

/* ------------------------------- 响应构造 ------------------------------- */

function fail(error) {
  return {
    ok: false,
    source: 'none',
    items: [],
    warnings: [],
    error: error
  };
}

/* ---------------------------- 内容脚本补注入 ---------------------------- */

/**
 * 内容脚本文件清单以 manifest 为准（而不是在代码里再抄一份），两处永远不会漂移。
 */
function contentScriptFiles() {
  try {
    var manifest = chrome.runtime.getManifest();
    var entry = (manifest.content_scripts || [])[0];
    return (entry && entry.js) || [];
  } catch (e) {
    return [];
  }
}

function executeScriptIn(tabId, files) {
  return new Promise(function (resolve) {
    try {
      chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: false }, files: files }, function () {
        resolve(chrome.runtime.lastError ? { ok: false, message: chrome.runtime.lastError.message } : { ok: true });
      });
    } catch (e) {
      resolve({ ok: false, message: String((e && e.message) || e) });
    }
  });
}

/**
 * 补注入：内容脚本只在「页面加载那一刻」注入。
 * 于是扩展装好之前就已经打开的标签页永远不会有任何反应 —— 用户看到的就是
 * 「明明装了插件，网页上却什么都没显示」。安装/更新/浏览器启动时主动补一遍。
 * 内容脚本自身有 window.__SR_CONTENT_LOADED__ 幂等锁，补注入不会导致重复挂载。
 */
async function injectIntoExistingTabs(reason) {
  var files = contentScriptFiles();
  if (!files.length) return { reason: reason, injected: 0, failed: 0, scanned: 0 };
  var tabs = await new Promise(function (resolve) {
    chrome.tabs.query({}, function (list) {
      void chrome.runtime.lastError;
      resolve(list || []);
    });
  });
  var injected = 0;
  var failed = 0;
  var scanned = 0;
  for (var i = 0; i < tabs.length; i++) {
    var tab = tabs[i];
    if (!tab || tab.id == null) continue;
    if (!/^https?:\/\//i.test(tab.url || '')) continue;
    scanned++;
    var res = await executeScriptIn(tab.id, files);
    if (res.ok) injected++;
    else failed++;
  }
  return { reason: reason, injected: injected, failed: failed, scanned: scanned };
}

/* ------------------------------- 诊断 ------------------------------- */

function tabInfo(tabId) {
  return new Promise(function (resolve) {
    try {
      chrome.tabs.get(tabId, function (tab) {
        resolve(chrome.runtime.lastError ? null : tab || null);
      });
    } catch (e) {
      resolve(null);
    }
  });
}

function sendToTab(tabId, message) {
  return new Promise(function (resolve) {
    try {
      chrome.tabs.sendMessage(tabId, message, function (res) {
        resolve(chrome.runtime.lastError ? null : res || null);
      });
    } catch (e) {
      resolve(null);
    }
  });
}

function hasOriginPermission(url) {
  return new Promise(function (resolve) {
    var pattern;
    try {
      pattern = new URL(url).origin + '/*';
    } catch (e) {
      return resolve(null);
    }
    try {
      chrome.permissions.contains({ origins: [pattern] }, function (granted) {
        void chrome.runtime.lastError;
        resolve(!!granted);
      });
    } catch (e) {
      resolve(null);
    }
  });
}

/**
 * 「什么都没显示」的完整体检报告。弹窗用它把原因直接说清楚，而不是让用户猜。
 */
async function handleDiagnose(msg) {
  var cfg = await readSettings();
  var tabId = msg && msg.tabId != null ? msg.tabId : null;
  var tab = tabId != null ? await tabInfo(tabId) : null;
  var url = (msg && msg.url) || (tab && tab.url) || '';

  var report = {
    ok: true,
    tabId: tabId,
    url: url,
    title: (tab && tab.title) || '',
    isHttp: /^https?:\/\//i.test(url),
    supported: Settings.isSupportedUrl(url, cfg),
    allowFileUrls: cfg.allowFileUrls,
    blacklisted: Settings.isBlacklisted(url, cfg.blacklist),
    autoUpdate: cfg.autoUpdate,
    hasApiKey: !!cfg.apiKey,
    model: cfg.model || '',
    endpointHost: Settings.hostOf(cfg.baseUrl),
    fallbackLocal: cfg.fallbackLocal,
    skipTinyChars: cfg.skipTinyChars,
    panelHidden: cfg.panel.hidden === true,
    originPermission: null,
    contentScript: 'unknown',
    contentError: null,
    ping: null,
    lastRun: null
  };

  if (report.isHttp) report.originPermission = await hasOriginPermission(url);

  if (tabId != null) {
    var ping = await sendToTab(tabId, { type: 'SR_PING' });
    if (ping && ping.ok) {
      report.contentScript = 'alive';
      report.ping = ping;
      report.contentError = ping.bootError || null;
    } else {
      report.contentScript = 'missing';
    }
    var state = await getTabState(tabId);
    if (state && state.result) {
      report.lastRun = {
        at: state.at || 0,
        ok: state.result.ok !== false,
        source: state.result.source || '',
        items: (state.result.items || []).length,
        error: (state.result.error && {
          code: state.result.error.code,
          message: state.result.error.message,
          hint: state.result.error.hint
        }) || null
      };
    }
  }

  // 一句话结论：用户看一眼就知道「为什么没显示」
  if (!report.isHttp) {
    report.verdict = url && /^file:/i.test(url)
      ? '这是本地文件页面。到设置页打开「也处理本地 file:// 页面」后刷新。'
      : '这个页面类型浏览器不允许扩展注入（chrome:// 、扩展页、应用商店等）。请打开一个普通网页。';
  } else if (report.blacklisted) {
    report.verdict = '该站点在「不运行的站点」黑名单里，扩展故意不动作。到设置页移除即可。';
  } else if (report.originPermission === false) {
    report.verdict = '扩展没有被授予这个站点的访问权限。到 chrome://extensions 点本扩展的「详情」→「网站访问权限」改成「在所有网站上」。';
  } else if (report.contentScript === 'missing') {
    report.verdict = '内容脚本没注入到这一页（最常见原因：这个标签页是在扩展安装之前就打开的）。点下面的按钮立刻补注入，无需刷新。';
  } else if (report.panelHidden) {
    report.verdict = '面板被关掉了（设置里 panel.hidden = true）。点下面的按钮重新显示。';
  } else if (report.contentError) {
    report.verdict = '内容脚本启动失败：' + report.contentError;
  } else if (!report.hasApiKey && !report.fallbackLocal) {
    report.verdict = '没有 API Key，而且「本地兜底」是关的，所以永远不会出结果。二选一：填 Key，或打开本地兜底。';
  } else if (report.lastRun && report.lastRun.ok === false && report.lastRun.error) {
    report.verdict = '最近一次运行失败：' + report.lastRun.error.message;
  } else if (report.lastRun && report.lastRun.items === 3) {
    report.verdict = '这一页已经算出 3 条了（' + (report.lastRun.source === 'llm' ? 'AI 摘要' : '本地兜底') + '）。如果看不到，检查面板是不是被拖到屏幕外了 —— 到设置页点「重置面板位置」。';
  } else {
    report.verdict = '内容脚本在运行，但还没有结果。可能正文太短（低于 ' + report.skipTinyChars + ' 字），或摘要还没回来。';
  }
  return report;
}

/* ------------------------------- 主流程 ------------------------------- */

async function handleSummarize(msg, sender) {
  var cfg = await readSettings();
  var input = msg.input || {};
  var tabId = sender && sender.tab ? sender.tab.id : null;
  var url = input.url || (sender && sender.tab && sender.tab.url) || '';

  if (!Settings.isSupportedUrl(url, cfg)) {
    return fail({ code: 'UNSUPPORTED_URL', message: '这个页面类型不支持（只处理 http/https）。', hint: '' });
  }
  if (Settings.isBlacklisted(url, cfg.blacklist)) {
    return fail({ code: 'BLACKLISTED', message: '该站点在「不运行」黑名单里。', hint: '到设置页把域名从黑名单移除即可。' });
  }

  var textLen = (input.text || '').length;
  if (textLen < cfg.skipTinyChars) {
    return fail({
      code: 'TOO_SHORT',
      message: '正文只有 ' + textLen + ' 字，没有可压缩的信息。',
      hint: settingsHint(cfg)
    });
  }

  var fingerprint = input.fingerprint || Core.contentFingerprint(input);
  var cacheKey = Core.cacheKeyOf(fingerprint, cfg);

  if (!msg.force) {
    var cached = await cacheGet(cacheKey, cfg.cacheTtlMs);
    if (cached) {
      var hit = {
        ok: true,
        source: cached.source,
        items: cached.items,
        warnings: (cached.warnings || []).concat(['命中缓存（同一内容已算过，没重复调用模型）。']),
        meta: Object.assign({}, cached.meta, { fingerprint: fingerprint, cached: true, ms: 0 }),
        cached: true
      };
      await setTabState(tabId, { url: url, fingerprint: fingerprint, result: hit });
      return hit;
    }
  }

  // 并发去重：同一内容只发一次请求，其他调用共享结果
  var existing = inflight.get(cacheKey);
  if (existing) {
    var shared = await existing;
    return Object.assign({}, shared, {
      warnings: (shared.warnings || []).concat(['与同一页面的另一次请求合并（并发去重）。']),
      meta: Object.assign({}, shared.meta, { deduped: true })
    });
  }

  // 限流：同一标签页两次真实调用之间的最小间隔
  var now = Date.now();
  var last = tabId != null ? lastCallByTab.get(tabId) : null;
  if (cfg.minIntervalMs > 0 && last && now - last < cfg.minIntervalMs) {
    return {
      ok: true,
      throttled: true,
      retryAfterMs: cfg.minIntervalMs - (now - last),
      source: 'throttled',
      items: [],
      warnings: ['页面变化太频繁，已按最小间隔排队，稍后自动重算。'],
      meta: { fingerprint: fingerprint }
    };
  }
  if (tabId != null) lastCallByTab.set(tabId, now);

  var run = (async function () {
    var result = await Core.summarizeWithLLM(input, cfg, {
      fetchImpl: function (u, init) { return fetch(u, init); },
      repairAttempts: cfg.repairAttempts
    });
    result.meta = Object.assign({}, result.meta, { fingerprint: fingerprint });
    if (result.ok) {
      await cacheSet(cacheKey, {
        items: result.items,
        source: result.source,
        meta: result.meta,
        warnings: (result.warnings || []).slice(0, 4)
      }, cfg.cacheTtlMs);
      await setTabState(tabId, { url: url, fingerprint: fingerprint, result: result });
      await bumpStats(result);
    } else {
      await setTabState(tabId, { url: url, fingerprint: fingerprint, result: result });
    }
    updateBadge(tabId, result);
    return result;
  })();

  inflight.set(cacheKey, run);
  try {
    return await run;
  } finally {
    inflight.delete(cacheKey);
  }
}

function settingsHint(cfg) {
  if (!cfg.apiKey) return '打开扩展设置填入 API Key，或降低「跳过短文阈值」。';
  return '换一个信息量更大的页面试试，或降低「跳过短文阈值」。';
}

/* ------------------------------- 统计 / 徽标 ------------------------------- */

async function bumpStats(result) {
  var stats = await areaGet(localArea(), Settings.STATS_KEY, null) || {
    runs: 0, llm: 0, local: 0, cached: 0, lastAt: 0, lastModel: ''
  };
  stats.runs++;
  if (result.source === 'llm') stats.llm++;
  if (result.source === 'local') stats.local++;
  stats.lastAt = Date.now();
  stats.lastModel = (result.meta && result.meta.model) || '';
  await areaSet(localArea(), (function () {
    var p = {};
    p[Settings.STATS_KEY] = stats;
    return p;
  })());
}

function updateBadge(tabId, result) {
  if (tabId == null) return;
  try {
    var ok = result && result.ok;
    chrome.action.setBadgeText({ tabId: tabId, text: ok ? '3' : '!' });
    chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: ok ? '#1f6feb' : '#b3261e' });
    chrome.action.setTitle({
      tabId: tabId,
      title: ok
        ? '一目十行 · 已压缩 ' + (result.items || []).length + ' 条（' + (result.source === 'llm' ? 'AI' : '本地兜底') + '）'
        : '一目十行 · ' + ((result && result.error && result.error.message) || '未生成')
    });
  } catch (e) { /* 标签页可能已关闭 */ }
}

/* ------------------------------- 连通性测试 ------------------------------- */

async function handleTestConnection(overrides) {
  var cfg = Settings.mergeSettings(Settings.deepMerge(await readSettings(true), overrides || {}));
  var check = Core.validateConfig(cfg);
  if (!check.ok) {
    return { ok: false, code: 'CONFIG', message: '配置不完整：' + check.issues.join('、'), hint: '补齐 Base URL / 模型名 / API Key。' };
  }
  var messages = [
    { role: 'system', content: '你是连通性探针。只输出 JSON 对象，不要别的内容。' },
    { role: 'user', content: '输出：{"ok":true,"note":"随便一个中文词"}' }
  ];
  var t0 = Date.now();
  try {
    var call = await Core.callChat({
      fetchImpl: function (u, init) { return fetch(u, init); },
      cfg: Object.assign({}, cfg, { maxTokens: 64, retries: 0, timeoutMs: Math.min(cfg.timeoutMs, 30000) }),
      messages: messages,
      jsonMode: true
    });
    return {
      ok: true,
      ms: Date.now() - t0,
      model: call.model,
      url: call.url,
      jsonModeUsed: call.jsonModeUsed,
      sample: String(call.text).slice(0, 160),
      usage: call.usage
    };
  } catch (err) {
    return {
      ok: false,
      ms: Date.now() - t0,
      code: err.code || 'UNKNOWN',
      message: err.message || String(err),
      hint: err.hint || ''
    };
  }
}

/* ------------------------------- 消息路由 ------------------------------- */

async function handleMessage(msg, sender) {
  switch (msg && msg.type) {
    case 'SR_SUMMARIZE':
      return handleSummarize(msg, sender);
    case 'SR_GET_PUBLIC_SETTINGS':
      return { ok: true, settings: Settings.publicSettings(await readSettings()) };
    case 'SR_GET_TAB_STATE': {
      var tabId = sender && sender.tab ? sender.tab.id : msg.tabId;
      return { ok: true, tabId: tabId, state: await getTabState(tabId), settings: Settings.publicSettings(await readSettings()) };
    }
    case 'SR_TEST_CONNECTION':
      return handleTestConnection(msg.overrides);
    case 'SR_CLEAR_CACHE': {
      var cleared = await clearCache();
      return { ok: true, cleared: cleared };
    }
    case 'SR_SETTINGS_CHANGED': {
      settingsCache = null;
      await broadcast({ type: 'SR_SETTINGS_CHANGED' });
      return { ok: true };
    }
    case 'SR_OPEN_OPTIONS': {
      try { chrome.runtime.openOptionsPage(); } catch (e) { /* ignore */ }
      return { ok: true };
    }
    case 'SR_DIAGNOSE':
      return handleDiagnose(msg);
    case 'SR_INJECT_HERE': {
      var targetTab = (sender && sender.tab ? sender.tab.id : null) != null ? sender.tab.id : msg.tabId;
      if (targetTab == null) return { ok: false, message: '拿不到标签页 id' };
      var result = await executeScriptIn(targetTab, contentScriptFiles());
      if (result.ok) return { ok: true, injected: contentScriptFiles().length };
      return { ok: false, message: result.message || '注入失败' };
    }
    case 'SR_HELLO': {
      // 内容脚本刚挂载：给工具栏一个「本页已激活」的信号
      if (sender && sender.tab) {
        try {
          chrome.action.setBadgeBackgroundColor({ tabId: sender.tab.id, color: '#6e7681' });
          chrome.action.setBadgeText({ tabId: sender.tab.id, text: '十' });
          chrome.action.setTitle({ tabId: sender.tab.id, title: '一目十行 · 本页已激活，正在压缩…' });
        } catch (e) { /* ignore */ }
      }
      return { ok: true };
    }
    case 'SR_STATS': {
      var stats = await areaGet(localArea(), Settings.STATS_KEY, null);
      return { ok: true, stats: stats };
    }
    default:
      return { ok: false, error: { code: 'UNKNOWN_MESSAGE', message: '未知消息：' + (msg && msg.type) } };
  }
}

function broadcast(message) {
  return new Promise(function (resolve) {
    try {
      chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }, function (tabs) {
        if (chrome.runtime.lastError || !tabs) return resolve(false);
        for (var i = 0; i < tabs.length; i++) {
          try { chrome.tabs.sendMessage(tabs[i].id, message, function () { void chrome.runtime.lastError; }); } catch (e) { /* 页面已卸载 */ }
        }
        resolve(true);
      });
    } catch (e) {
      resolve(false);
    }
  });
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  handleMessage(msg, sender).then(function (result) {
    sendResponse(result);
  }).catch(function (err) {
    sendResponse(fail({
      code: (err && err.code) || 'INTERNAL',
      message: (err && err.message) || String(err),
      hint: '扩展内部错误，可尝试重新加载扩展。'
    }));
  });
  return true; // 异步响应
});

/* ------------------------------- 生命周期 ------------------------------- */

chrome.runtime.onInstalled.addListener(async function (details) {
  await clearCache();
  lastCallByTab.clear();
  if (details.reason === 'install') {
    // 首次安装：没有 Key 就是废的，直接把设置页打开
    try { chrome.runtime.openOptionsPage(); } catch (e) { /* ignore */ }
  }
  // 关键：把内容脚本补注入到「扩展装好之前就已经打开」的标签页。
  // 不做这一步，用户装完扩展盯着已经开着的网页，会认为插件完全没生效。
  var report = await injectIntoExistingTabs(details.reason || 'install');
  try { console.log('[一目十行] 补注入完成', report); } catch (e) { /* ignore */ }
});

// 浏览器重启后同样是「页面先于扩展就绪」，再补一遍
chrome.runtime.onStartup.addListener(function () {
  injectIntoExistingTabs('startup');
});

/**
 * 兜底：在 chrome://extensions 里点「重新加载」未打包扩展时，onInstalled 不一定会触发，
 * 而用户此刻最可能的状态就是「盯着一个已经开着的网页」。Service Worker 每次被唤醒都会
 * 重新求值，所以这里做一次「本会话只补一次」的检查，保证已打开的标签页最终一定被覆盖。
 * 内容脚本自身幂等（window.__SR_CONTENT_LOADED__），重复注入不会重复挂载面板。
 */
(async function ensureInjectedOncePerSession() {
  try {
    var flag = await areaGet(sessionArea(), 'sr.injectedOnce', null);
    if (flag) return;
    await areaSet(sessionArea(), 'sr.injectedOnce', Date.now());
    var report = await injectIntoExistingTabs('sw-wake');
    try { console.log('[一目十行] SW 唤醒兜底补注入', report); } catch (e) { /* ignore */ }
  } catch (e) { /* 补注入失败不影响其他功能 */ }
})();

chrome.tabs.onRemoved.addListener(function (tabId) {
  lastCallByTab.delete(tabId);
  var area = sessionArea();
  areaRemove(area, [tabKey(tabId)]);
});

chrome.commands.onCommand.addListener(function (command) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (chrome.runtime.lastError || !tabs || !tabs[0]) return;
    var type = command === 'force-refresh' ? 'SR_FORCE_REFRESH' : 'SR_TOGGLE_PANEL';
    try {
      chrome.tabs.sendMessage(tabs[0].id, { type: type, reason: 'shortcut' }, function () { void chrome.runtime.lastError; });
    } catch (e) { /* 该页没有内容脚本 */ }
  });
});

// 标签页开始导航时清掉上一页的限流记录与徽标，避免新页面被上一页的时间戳卡住
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo) {
  if (changeInfo.status !== 'loading') return;
  lastCallByTab.delete(tabId);
  try { chrome.action.setBadgeText({ tabId: tabId, text: '' }); } catch (e) { /* ignore */ }
});
