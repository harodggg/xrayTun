/**
 * 素颜镜 · 美颜程度检测 —— 后台 Service Worker
 * ---------------------------------------------------------------------------
 * 职责（见 docs/SPEC.md §4）：
 *   1) 右键菜单「检测这张图的美颜程度」→ 通知内容脚本弹报告卡片（SHOW_REPORT）。
 *   2) 跨域取图分析：fetch(url) → blob → createImageBitmap → OffscreenCanvas
 *      → getImageData → BeautyEngine.analyze。走后台可以绕开页面 canvas 的跨域污染。
 *   3) 设置读写：chrome.storage.sync 键 beautyMeterSettings，合并默认值后返回，
 *      并在变化时向所有标签页广播 SETTINGS_CHANGED。
 *
 * 注意：这是 classic worker（不是 module），引擎用 importScripts 加载，
 * 加载后挂在 self.BeautyEngine 上。
 */
'use strict';

/* =======================================================================
 * 引擎加载（classic worker: importScripts）
 * ===================================================================== */

var engineReady = false;
var engineLoadError = '';
var MAX_SIDE = 512;

try {
  importScripts('../common/beauty-engine.js');
  engineReady = !!(self.BeautyEngine && typeof self.BeautyEngine.analyze === 'function');
  if (self.BeautyEngine && self.BeautyEngine.DEFAULTS && self.BeautyEngine.DEFAULTS.maxSide) {
    MAX_SIDE = self.BeautyEngine.DEFAULTS.maxSide;
  }
} catch (err) {
  engineReady = false;
  engineLoadError = textOf(err);
}

/* =======================================================================
 * 常量
 * ===================================================================== */

var SETTINGS_KEY = 'beautyMeterSettings';
var CONTEXT_MENU_ID = 'beauty-meter-analyze-image';
var CONTEXT_MENU_TITLE = '检测这张图的美颜程度';

var DEFAULT_SETTINGS = {
  hoverEnabled: true,
  minImageSize: 160,
  hoverDelay: 300,
  sensitivity: 1.0,
  preset: 'balanced',          // balanced | smoothing | whitening | custom
  customWeights: null,
  showDebug: false,
  siteWhitelist: []
};

/* 预设权重（引擎会自行归一化，这里只体现「偏向」）。
 * 这是唯一的权威定义：设置页/弹窗通过 GET_SETTINGS 的 presetWeights 字段读取，
 * 不要在别处复制这张表。 */
var PRESET_WEIGHTS = {
  balanced: { smoothing: 0.40, whitening: 0.20, uniformity: 0.18, chroma: 0.11, contrast: 0.11 },
  smoothing: { smoothing: 0.55, whitening: 0.15, uniformity: 0.15, chroma: 0.075, contrast: 0.075 },
  whitening: { smoothing: 0.25, whitening: 0.45, uniformity: 0.15, chroma: 0.075, contrast: 0.075 }
};

var PRESET_NAMES = ['balanced', 'smoothing', 'whitening', 'custom'];
var METRIC_KEYS = ['smoothing', 'whitening', 'uniformity', 'chroma', 'contrast'];

/* =======================================================================
 * 小工具
 * ===================================================================== */

function textOf(err) {
  if (!err) return '未知错误';
  if (typeof err === 'string') return err;
  if (err.message) return String(err.message);
  return String(err);
}

function clampNumber(value, lo, hi, fallback) {
  var n = Number(value);
  if (!isFinite(n)) return fallback;
  if (n < lo) return lo;
  if (n > hi) return hi;
  return n;
}

/** 面向用户的错误文案必须是中文：英文/无中文的底层错误前面补一句中文说明 */
function friendlyError(err, fallback) {
  var text = textOf(err);
  if (/[\u4e00-\u9fff]/.test(text)) return text;
  return (fallback || '分析失败') + '：' + text;
}

function hasUsableWeights(weights) {
  if (!weights || typeof weights !== 'object') return false;
  var sum = 0;
  for (var i = 0; i < METRIC_KEYS.length; i++) {
    var v = Number(weights[METRIC_KEYS[i]]);
    if (isFinite(v) && v > 0) sum += v;
  }
  return sum > 0;
}

/** 合并默认值 + 类型收敛，任何字段坏了都不会污染其它字段 */
function normalizeSettings(raw) {
  var src = (raw && typeof raw === 'object') ? raw : {};
  var out = {
    hoverEnabled: typeof src.hoverEnabled === 'boolean' ? src.hoverEnabled : DEFAULT_SETTINGS.hoverEnabled,
    minImageSize: Math.round(clampNumber(src.minImageSize, 32, 4000, DEFAULT_SETTINGS.minImageSize)),
    hoverDelay: Math.round(clampNumber(src.hoverDelay, 0, 3000, DEFAULT_SETTINGS.hoverDelay)),
    sensitivity: clampNumber(src.sensitivity, 0.2, 3, DEFAULT_SETTINGS.sensitivity),
    preset: PRESET_NAMES.indexOf(src.preset) !== -1 ? src.preset : DEFAULT_SETTINGS.preset,
    customWeights: null,
    showDebug: typeof src.showDebug === 'boolean' ? src.showDebug : DEFAULT_SETTINGS.showDebug,
    siteWhitelist: []
  };

  var cw = src.customWeights;
  if (cw && typeof cw === 'object') {
    var clean = {};
    var any = false;
    for (var i = 0; i < METRIC_KEYS.length; i++) {
      var key = METRIC_KEYS[i];
      var v = clampNumber(cw[key], 0, 1, 0);
      clean[key] = v;
      if (v > 0) any = true;
    }
    out.customWeights = any ? clean : null;
  }

  if (Array.isArray(src.siteWhitelist)) {
    var seen = {};
    for (var j = 0; j < src.siteWhitelist.length && out.siteWhitelist.length < 200; j++) {
      var entry = String(src.siteWhitelist[j] == null ? '' : src.siteWhitelist[j]).trim();
      if (!entry) continue;
      var low = entry.toLowerCase();
      if (seen[low]) continue;
      seen[low] = true;
      out.siteWhitelist.push(entry);
    }
  }
  return out;
}

/* =======================================================================
 * 设置读写（每次 chrome API 调用都检查 chrome.runtime.lastError）
 * ===================================================================== */

var settingsCache = null;

function readArea(area, key, cb) {
  try {
    var store = area === 'local' ? chrome.storage.local : chrome.storage.sync;
    store.get(key, function (items) {
      var err = null;
      try { err = chrome.runtime.lastError; } catch (e) { err = e; }
      if (err) { cb(null, textOf(err)); return; }
      cb(items ? items[key] : null, null);
    });
  } catch (err) {
    cb(null, textOf(err));
  }
}

/** 读取原始设置：sync 失败时退回 local，再退回默认值 */
function readRawSettings(cb) {
  readArea('sync', SETTINGS_KEY, function (raw, err) {
    if (!err) { cb(raw, null); return; }
    readArea('local', SETTINGS_KEY, function (localRaw, localErr) {
      if (!localErr) { cb(localRaw, err); return; }
      cb(null, err);
    });
  });
}

function loadSettings() {
  return new Promise(function (resolve) {
    if (settingsCache) { resolve(settingsCache); return; }
    readRawSettings(function (raw) {
      settingsCache = normalizeSettings(raw);
      resolve(settingsCache);
    });
  });
}

function warmUpSettings() {
  loadSettings().then(function () { /* 预热缓存，忽略结果 */ }, function () { /* 同上 */ });
}

function broadcastSettings(settings) {
  try {
    chrome.tabs.query({}, function (tabs) {
      try { void chrome.runtime.lastError; } catch (e) { /* 忽略 */ }
      if (!tabs || !tabs.length) return;
      for (var i = 0; i < tabs.length; i++) {
        var tab = tabs[i];
        if (!tab || typeof tab.id !== 'number') continue;
        try {
          chrome.tabs.sendMessage(tab.id, { type: 'SETTINGS_CHANGED', settings: settings }, function () {
            try { void chrome.runtime.lastError; } catch (e) { /* 该标签页没有内容脚本，忽略 */ }
          });
        } catch (e) { /* 忽略单个标签页的失败 */ }
      }
    });
  } catch (err) { /* 忽略 */ }
}

function onStorageChanged(changes, area) {
  try {
    if (area !== 'sync' && area !== 'local') return;
    if (!changes || !Object.prototype.hasOwnProperty.call(changes, SETTINGS_KEY)) return;
    settingsCache = normalizeSettings(changes[SETTINGS_KEY] ? changes[SETTINGS_KEY].newValue : null);
    broadcastSettings(settingsCache);
  } catch (err) { /* 忽略 */ }
}

/* =======================================================================
 * 右键菜单
 * ===================================================================== */

function installContextMenu() {
  try {
    chrome.contextMenus.removeAll(function () {
      try { void chrome.runtime.lastError; } catch (e) { /* 忽略 */ }
      try {
        chrome.contextMenus.create({
          id: CONTEXT_MENU_ID,
          title: CONTEXT_MENU_TITLE,
          contexts: ['image']
        }, function () {
          try { void chrome.runtime.lastError; } catch (e) { /* 已存在则忽略 */ }
        });
      } catch (err) { /* 忽略 */ }
    });
  } catch (err) { /* 忽略 */ }
}

function onContextMenuClicked(info, tab) {
  try {
    if (!info || info.menuItemId !== CONTEXT_MENU_ID) return;
    if (!tab || typeof tab.id !== 'number') return;
    var url = info.srcUrl || info.linkUrl || '';
    if (!url) return;
    var frameId = typeof info.frameId === 'number' ? info.frameId : 0;
    chrome.tabs.sendMessage(
      tab.id,
      { type: 'SHOW_REPORT', url: url, anchorRect: null },
      { frameId: frameId },
      function () {
        try {
          var err = chrome.runtime.lastError;
          if (err) console.warn('[素颜镜] 无法在该页面显示报告卡片：' + textOf(err));
        } catch (e) { /* 忽略 */ }
      }
    );
  } catch (err) {
    console.warn('[素颜镜] 右键菜单处理失败：' + textOf(err));
  }
}

/* =======================================================================
 * 分析：fetch → blob → createImageBitmap → OffscreenCanvas → analyze
 * ===================================================================== */

/** 由当前设置决定引擎 options */
function buildOptions(overrides) {
  return loadSettings().then(function (settings) {
    var weights = null;
    if (settings.preset === 'custom' && hasUsableWeights(settings.customWeights)) {
      weights = settings.customWeights;
    } else if (settings.preset === 'smoothing' || settings.preset === 'whitening') {
      weights = PRESET_WEIGHTS[settings.preset];
    }
    var options = { sensitivity: settings.sensitivity, weights: weights };
    if (overrides && typeof overrides === 'object') {
      if (typeof overrides.sensitivity === 'number') options.sensitivity = overrides.sensitivity;
      if (overrides.weights && typeof overrides.weights === 'object') options.weights = overrides.weights;
      if (typeof overrides.maxSide === 'number') options.maxSide = overrides.maxSide;
      if (typeof overrides.minSkinRatio === 'number') options.minSkinRatio = overrides.minSkinRatio;
      if (typeof overrides.strictSkinRatio === 'number') options.strictSkinRatio = overrides.strictSkinRatio;
      if (typeof overrides.minConfidentSide === 'number') options.minConfidentSide = overrides.minConfidentSide;
    }
    return options;
  });
}

/** 把 ImageBitmap 画到 OffscreenCanvas 并取回像素（先缩到工作分辨率） */
function pixelsFromBitmap(bitmap, maxSide) {
  var w0 = bitmap.width || 0;
  var h0 = bitmap.height || 0;
  if (!w0 || !h0) throw new Error('无法获取图片尺寸');
  var side = maxSide && maxSide > 0 ? maxSide : MAX_SIDE;
  var scale = Math.min(1, side / Math.max(w0, h0));
  var w = Math.max(1, Math.round(w0 * scale));
  var h = Math.max(1, Math.round(h0 * scale));

  if (typeof OffscreenCanvas === 'undefined') {
    throw new Error('当前浏览器不支持 OffscreenCanvas，无法读取图片像素');
  }
  var canvas = new OffscreenCanvas(w, h);
  var ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('无法创建 2D 画布上下文');
  ctx.imageSmoothingEnabled = true;
  if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(bitmap, 0, 0, w, h);
  var imageData = ctx.getImageData(0, 0, w, h);
  return { data: imageData.data, width: w, height: h };
}

function engineMissing() {
  return { ok: false, error: '分析引擎未能加载，请重新加载扩展（' + (engineLoadError || '未知原因') + '）' };
}

function analyzeUrl(url, overrides) {
  if (!engineReady) return Promise.resolve(engineMissing());
  if (!url || typeof url !== 'string') {
    return Promise.resolve({ ok: false, error: '缺少图片地址' });
  }

  return new Promise(function (resolve) {
    var bitmap = null;
    // cache 用默认策略：宁可重新取一次，也不要用 HTTP 缓存里可能已经过期的旧图做判断
    fetch(url, { credentials: 'include', cache: 'default' })
      .catch(function (err) {
        throw new Error('图片下载失败（网络不可达或地址被拒绝）：' + textOf(err));
      })
      .then(function (response) {
        if (!response || !response.ok) {
          throw new Error('图片下载失败（HTTP ' + ((response && response.status) || '?') + '）');
        }
        return response.blob().catch(function (err) {
          throw new Error('读取图片数据失败：' + textOf(err));
        });
      })
      .then(function (blob) {
        if (!blob || !blob.size) throw new Error('图片内容为空');
        var type = blob.type || '';
        if (type && type.indexOf('image/') !== 0) {
          throw new Error('这个地址返回的不是图片（' + type + '）');
        }
        return createImageBitmap(blob).catch(function () {
          throw new Error('无法解码这张图片，可能已损坏或格式不受支持');
        });
      })
      .then(function (bmp) {
        bitmap = bmp;
        return buildOptions(overrides);
      })
      .then(function (options) {
        var pixels = null;
        try {
          pixels = pixelsFromBitmap(bitmap, options.maxSide);
        } catch (pixelErr) {
          throw new Error('读取图片像素失败：' + textOf(pixelErr));
        }
        var report = self.BeautyEngine.analyze(
          { data: pixels.data, width: pixels.width, height: pixels.height },
          options
        );
        return { ok: true, report: report };
      })
      .then(function (result) {
        if (bitmap && typeof bitmap.close === 'function') { try { bitmap.close(); } catch (e) { /* 忽略 */ } }
        resolve(result);
      })
      .catch(function (err) {
        if (bitmap && typeof bitmap.close === 'function') { try { bitmap.close(); } catch (e) { /* 忽略 */ } }
        resolve({ ok: false, error: friendlyError(err, '分析失败') });
      });
  });
}

function analyzeImageData(imageData, overrides) {
  if (!engineReady) return Promise.resolve(engineMissing());
  if (!imageData || !imageData.data || !imageData.width || !imageData.height) {
    return Promise.resolve({ ok: false, error: '缺少像素数据（需要 {data,width,height}）' });
  }
  var data = imageData.data;
  if (!(data instanceof Uint8ClampedArray)) {
    try {
      data = new Uint8ClampedArray(data);
    } catch (err) {
      return Promise.resolve({ ok: false, error: '像素数据格式不正确' });
    }
  }
  return buildOptions(overrides).then(function (options) {
    try {
      var report = self.BeautyEngine.analyze(
        { data: data, width: imageData.width, height: imageData.height },
        options
      );
      return { ok: true, report: report };
    } catch (err) {
      return { ok: false, error: '分析失败：' + textOf(err) };
    }
  });
}

/* =======================================================================
 * 消息路由
 * ===================================================================== */

function handleMessage(message) {
  if (!message || typeof message.type !== 'string') {
    return Promise.resolve({ ok: false, error: '无法识别的消息' });
  }
  switch (message.type) {
    case 'GET_SETTINGS':
      return loadSettings().then(function (settings) {
        return { ok: true, settings: settings, presetWeights: PRESET_WEIGHTS };
      });
    case 'ANALYZE_URL':
    case 'ANALYZE_DATA_URL':
      return analyzeUrl(message.url, message.options);
    case 'ANALYZE_IMAGE_DATA':
      return analyzeImageData(message.imageData, message.options);
    case 'OPEN_OPTIONS':
      try {
        chrome.runtime.openOptionsPage(function () {
          try { void chrome.runtime.lastError; } catch (e) { /* 忽略 */ }
        });
        return Promise.resolve({ ok: true });
      } catch (err) {
        return Promise.resolve({ ok: false, error: textOf(err) });
      }
    default:
      return Promise.resolve({ ok: false, error: '未知消息类型：' + message.type });
  }
}

try {
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    handleMessage(message).then(
      function (result) {
        try { sendResponse(result); } catch (e) { /* 通道已关闭 */ }
      },
      function (err) {
        try { sendResponse({ ok: false, error: friendlyError(err, '分析失败') }); } catch (e) { /* 通道已关闭 */ }
      }
    );
    return true; // 异步响应
  });
} catch (err) {
  console.error('[素颜镜] 注册消息监听失败：' + textOf(err));
}

try {
  chrome.runtime.onInstalled.addListener(function () {
    installContextMenu();
    warmUpSettings();
  });
} catch (err) { /* 忽略 */ }

try {
  if (chrome.runtime.onStartup) {
    chrome.runtime.onStartup.addListener(function () {
      installContextMenu();
      warmUpSettings();
    });
  }
} catch (err) { /* 忽略 */ }

try {
  chrome.contextMenus.onClicked.addListener(onContextMenuClicked);
} catch (err) { /* 忽略 */ }

try {
  chrome.storage.onChanged.addListener(onStorageChanged);
} catch (err) { /* 忽略 */ }

// Service Worker 被唤醒后先预热一次设置，避免首次消息多绕一圈。
warmUpSettings();
