/**
 * 素颜镜 · 设置页脚本（options.js）
 * ---------------------------------------------------------------------------
 * 字段：hoverEnabled / minImageSize / hoverDelay / sensitivity / preset /
 *       customWeights / showDebug / siteWhitelist
 * 保存：chrome.storage.sync，键 beautyMeterSettings，改动即时保存 + 中文「已保存」提示。
 * 预设权重的权威定义在后台（service-worker.js），这里只通过 GET_SETTINGS 的
 * presetWeights 字段读取用于预览，不复制权重表。
 */
(function () {
  'use strict';

  var SETTINGS_KEY = 'beautyMeterSettings';
  var METRIC_KEYS = ['smoothing', 'whitening', 'uniformity', 'chroma', 'contrast'];
  var METRIC_LABELS = {
    smoothing: '磨皮去纹理',
    whitening: '美白提亮',
    uniformity: '肤色均匀',
    chroma: '去色低饱和',
    contrast: '通透度压缩'
  };
  var PRESET_LABELS = {
    balanced: '均衡',
    smoothing: '磨皮优先',
    whitening: '美白优先',
    custom: '自定义'
  };
  var DEFAULTS = {
    hoverEnabled: true,
    minImageSize: 160,
    hoverDelay: 300,
    sensitivity: 1.0,
    preset: 'balanced',
    customWeights: null,
    showDebug: false,
    siteWhitelist: []
  };

  var $ = function (id) { return document.getElementById(id); };
  var els = {};
  var state = {
    settings: null,
    presetWeights: null,
    lastWrittenJson: '',
    saveTimer: null,
    hintTimer: null,
    suppress: false
  };

  /* =====================================================================
   * 工具
   * =================================================================== */

  function errText(err) {
    if (!err) return '未知错误';
    if (typeof err === 'string') return err;
    return String(err.message || err);
  }

  function clampNumber(value, lo, hi, fallback) {
    var n = Number(value);
    if (!isFinite(n)) return fallback;
    return Math.min(hi, Math.max(lo, n));
  }

  function clampInt(value, lo, hi, fallback) {
    return Math.round(clampNumber(value, lo, hi, fallback));
  }

  function runtimeAlive() {
    try {
      return typeof chrome !== 'undefined' && !!chrome.runtime && !!chrome.runtime.id;
    } catch (err) {
      return false;
    }
  }

  function showHint(text, isError) {
    if (!els.saveHint) return;
    els.saveHint.textContent = text || '';
    els.saveHint.classList.toggle('is-error', !!isError);
    els.saveHint.classList.toggle('is-visible', !!text);
    if (state.hintTimer) clearTimeout(state.hintTimer);
    if (text) {
      state.hintTimer = setTimeout(function () {
        els.saveHint.classList.remove('is-visible');
      }, 2000);
    }
  }

  /* =====================================================================
   * 读取 / 写入
   * =================================================================== */

  function normalizeSettings(raw) {
    var src = (raw && typeof raw === 'object') ? raw : {};
    var out = {
      hoverEnabled: typeof src.hoverEnabled === 'boolean' ? src.hoverEnabled : DEFAULTS.hoverEnabled,
      minImageSize: clampInt(src.minImageSize, 32, 4000, DEFAULTS.minImageSize),
      hoverDelay: clampInt(src.hoverDelay, 0, 3000, DEFAULTS.hoverDelay),
      sensitivity: clampNumber(src.sensitivity, 0.2, 3, DEFAULTS.sensitivity),
      preset: Object.prototype.hasOwnProperty.call(PRESET_LABELS, src.preset) ? src.preset : DEFAULTS.preset,
      customWeights: null,
      showDebug: typeof src.showDebug === 'boolean' ? src.showDebug : DEFAULTS.showDebug,
      siteWhitelist: []
    };
    var cw = src.customWeights;
    if (cw && typeof cw === 'object') {
      var clean = {};
      var any = false;
      for (var i = 0; i < METRIC_KEYS.length; i++) {
        var key = METRIC_KEYS[i];
        var value = clampNumber(cw[key], 0, 1, 0);
        clean[key] = value;
        if (value > 0) any = true;
      }
      out.customWeights = any ? clean : null;
    }
    if (Array.isArray(src.siteWhitelist)) {
      var seen = {};
      for (var j = 0; j < src.siteWhitelist.length && out.siteWhitelist.length < 200; j++) {
        var entry = String(src.siteWhitelist[j] == null ? '' : src.siteWhitelist[j]).trim();
        if (!entry) continue;
        var low = entry.toLowerCase();
        if (seen[low]) continue;
        seen[low] = true;
        out.siteWhitelist.push(entry);
      }
    }
    return out;
  }

  function readFromStorage(cb) {
    try {
      chrome.storage.sync.get(SETTINGS_KEY, function (items) {
        var lastErr = null;
        try { lastErr = chrome.runtime.lastError; } catch (err) { lastErr = err; }
        if (lastErr) { cb(null, errText(lastErr)); return; }
        cb(items ? items[SETTINGS_KEY] : null, null);
      });
    } catch (err) {
      cb(null, errText(err));
    }
  }

  function loadSettings() {
    if (!runtimeAlive()) {
      applyLoaded(normalizeSettings(null), null, '扩展已更新，请重新打开设置页');
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, function (response) {
        var lastErr = null;
        try { lastErr = chrome.runtime.lastError; } catch (err) { lastErr = err; }
        if (lastErr) {
          readFromStorage(function (raw, storageErr) {
            applyLoaded(normalizeSettings(raw), null, storageErr ? '读取设置失败：' + storageErr : null);
          });
          return;
        }
        if (!response || !response.ok || !response.settings) {
          readFromStorage(function (raw, storageErr) {
            applyLoaded(normalizeSettings(raw), null, storageErr ? '读取设置失败：' + storageErr : null);
          });
          return;
        }
        applyLoaded(normalizeSettings(response.settings), response.presetWeights || null, null);
      });
    } catch (err) {
      readFromStorage(function (raw, storageErr) {
        applyLoaded(normalizeSettings(raw), null, storageErr ? '读取设置失败：' + storageErr : null);
      });
    }
  }

  function applyLoaded(settings, presetWeights, errorText) {
    state.settings = settings;
    state.presetWeights = presetWeights || null;
    state.lastWrittenJson = JSON.stringify(settings);
    fillForm(settings);
    if (errorText) showHint(errorText, true);
  }

  function save(settings) {
    var payload = normalizeSettings(settings);
    var json = JSON.stringify(payload);
    state.settings = payload;
    state.lastWrittenJson = json;
    if (!runtimeAlive()) {
      showHint('扩展已更新，请重新打开设置页', true);
      return;
    }
    try {
      chrome.storage.sync.set({ beautyMeterSettings: payload }, function () {
        var lastErr = null;
        try { lastErr = chrome.runtime.lastError; } catch (err) { lastErr = err; }
        if (lastErr) {
          showHint('保存失败：' + errText(lastErr), true);
          return;
        }
        showHint('已保存', false);
      });
    } catch (err) {
      showHint('保存失败：' + errText(err), true);
    }
  }

  function scheduleSave() {
    if (state.suppress) return;
    updatePreview();
    if (state.saveTimer) clearTimeout(state.saveTimer);
    state.saveTimer = setTimeout(function () {
      state.saveTimer = null;
      save(collect());
    }, 300);
  }

  function saveNow() {
    if (state.saveTimer) { clearTimeout(state.saveTimer); state.saveTimer = null; }
    updatePreview();
    save(collect());
  }

  /* =====================================================================
   * 表单 <-> 设置
   * =================================================================== */

  function fillForm(settings) {
    state.suppress = true;
    els.hoverEnabled.checked = !!settings.hoverEnabled;
    els.minImageSize.value = String(settings.minImageSize);
    els.hoverDelay.value = String(settings.hoverDelay);
    els.sensitivity.value = String(settings.sensitivity);
    els.sensitivityValue.textContent = Number(settings.sensitivity).toFixed(2);
    els.showDebug.checked = !!settings.showDebug;
    els.siteWhitelist.value = (settings.siteWhitelist || []).join('\n');

    var radios = document.querySelectorAll('input[name="preset"]');
    for (var i = 0; i < radios.length; i++) radios[i].checked = (radios[i].value === settings.preset);

    var weights = settings.customWeights;
    for (var j = 0; j < METRIC_KEYS.length; j++) {
      var key = METRIC_KEYS[j];
      var input = els.weights[key];
      var value = weights && typeof weights[key] === 'number' ? weights[key] : 0;
      input.value = String(Math.round(value * 100));
    }
    state.suppress = false;
    updateWeightSum();
    updateCustomGroupState();
    updatePreview();
  }

  function collect() {
    return {
      hoverEnabled: !!els.hoverEnabled.checked,
      minImageSize: clampInt(els.minImageSize.value, 32, 4000, DEFAULTS.minImageSize),
      hoverDelay: clampInt(els.hoverDelay.value, 0, 3000, DEFAULTS.hoverDelay),
      sensitivity: Math.round(clampNumber(els.sensitivity.value, 0.2, 3, DEFAULTS.sensitivity) * 100) / 100,
      preset: selectedPreset(),
      customWeights: collectCustomWeights(),
      showDebug: !!els.showDebug.checked,
      siteWhitelist: parseWhitelist(els.siteWhitelist.value)
    };
  }

  function selectedPreset() {
    var radios = document.querySelectorAll('input[name="preset"]');
    for (var i = 0; i < radios.length; i++) if (radios[i].checked) return radios[i].value;
    return DEFAULTS.preset;
  }

  function collectCustomWeights() {
    var weights = {};
    var total = 0;
    for (var i = 0; i < METRIC_KEYS.length; i++) {
      var key = METRIC_KEYS[i];
      var percent = clampNumber(els.weights[key].value, 0, 100, 0);
      weights[key] = percent / 100;
      total += percent;
    }
    return total > 0 ? weights : null;
  }

  function parseWhitelist(text) {
    var lines = String(text || '').split(/\r?\n/);
    var out = [];
    var seen = {};
    for (var i = 0; i < lines.length && out.length < 200; i++) {
      var entry = lines[i].trim();
      if (!entry) continue;
      var low = entry.toLowerCase();
      if (seen[low]) continue;
      seen[low] = true;
      out.push(entry);
    }
    return out;
  }

  function updateWeightSum() {
    var total = 0;
    for (var i = 0; i < METRIC_KEYS.length; i++) {
      total += clampNumber(els.weights[METRIC_KEYS[i]].value, 0, 100, 0);
    }
    if (!els.weightSum) return;
    if (total <= 0) {
      els.weightSum.textContent = '合计 0%：权重全为 0，将按引擎默认权重计算。';
    } else {
      els.weightSum.textContent = '合计 ' + Math.round(total) + '%，实际计算时会自动归一化。';
    }
  }

  function updateCustomGroupState() {
    var isCustom = selectedPreset() === 'custom';
    els.customGroup.disabled = !isCustom;
  }

  /** 预览当前生效权重（来自后台的 presetWeights，或自定义输入） */
  function updatePreview() {
    var tbody = els.effectiveWeights;
    if (!tbody) return;
    while (tbody.firstChild) tbody.removeChild(tbody.firstChild);

    var preset = selectedPreset();
    var raw = null;
    var note = '';
    if (preset === 'custom') {
      raw = collectCustomWeights();
      if (!raw) note = '权重全为 0，实际按引擎默认权重计算';
    } else if (state.presetWeights && state.presetWeights[preset]) {
      raw = state.presetWeights[preset];
    } else {
      note = '未能读取预设权重（后台暂时不可用）';
    }

    var sum = 0;
    if (raw) {
      for (var i = 0; i < METRIC_KEYS.length; i++) {
        var value = Number(raw[METRIC_KEYS[i]]);
        if (isFinite(value) && value > 0) sum += value;
      }
    }

    for (var j = 0; j < METRIC_KEYS.length; j++) {
      var key = METRIC_KEYS[j];
      var tr = document.createElement('tr');
      var th = document.createElement('th');
      th.textContent = METRIC_LABELS[key] || key;
      var td = document.createElement('td');
      td.className = 'num';
      var percent = (raw && sum > 0 && isFinite(Number(raw[key]))) ? Math.round(Number(raw[key]) / sum * 100) : 0;
      td.textContent = (raw && sum > 0) ? (percent + '%') : '—';
      tr.appendChild(th);
      tr.appendChild(td);
      tbody.appendChild(tr);
    }

    if (note) {
      var noteRow = document.createElement('tr');
      var noteCell = document.createElement('td');
      noteCell.setAttribute('colspan', '2');
      noteCell.textContent = note;
      noteRow.appendChild(noteCell);
      tbody.appendChild(noteRow);
    }

    var presetRow = document.createElement('tr');
    var presetTh = document.createElement('th');
    presetTh.textContent = '当前预设';
    var presetTd = document.createElement('td');
    presetTd.className = 'num';
    presetTd.textContent = PRESET_LABELS[preset] || preset;
    presetRow.appendChild(presetTh);
    presetRow.appendChild(presetTd);
    tbody.appendChild(presetRow);
  }

  /* =====================================================================
   * 事件绑定
   * =================================================================== */

  function bind() {
    els.hoverEnabled.addEventListener('change', saveNow);
    els.showDebug.addEventListener('change', saveNow);

    els.minImageSize.addEventListener('input', scheduleSave);
    els.minImageSize.addEventListener('change', function () {
      els.minImageSize.value = String(clampInt(els.minImageSize.value, 32, 4000, DEFAULTS.minImageSize));
      saveNow();
    });
    els.hoverDelay.addEventListener('input', scheduleSave);
    els.hoverDelay.addEventListener('change', function () {
      els.hoverDelay.value = String(clampInt(els.hoverDelay.value, 0, 3000, DEFAULTS.hoverDelay));
      saveNow();
    });

    els.sensitivity.addEventListener('input', function () {
      els.sensitivityValue.textContent = Number(clampNumber(els.sensitivity.value, 0.2, 3, 1)).toFixed(2);
      scheduleSave();
    });
    els.sensitivity.addEventListener('change', function () {
      els.sensitivity.value = String(Math.round(clampNumber(els.sensitivity.value, 0.2, 3, 1) * 100) / 100);
      els.sensitivityValue.textContent = Number(els.sensitivity.value).toFixed(2);
      saveNow();
    });

    var radios = document.querySelectorAll('input[name="preset"]');
    for (var i = 0; i < radios.length; i++) {
      radios[i].addEventListener('change', function () {
        if (this.value === 'custom') prefillCustomWeights();
        updateCustomGroupState();
        saveNow();
      });
    }

    for (var j = 0; j < METRIC_KEYS.length; j++) {
      var input = els.weights[METRIC_KEYS[j]];
      input.addEventListener('input', function () {
        updateWeightSum();
        scheduleSave();
      });
      input.addEventListener('change', function () {
        this.value = String(clampNumber(this.value, 0, 100, 0));
        updateWeightSum();
        saveNow();
      });
    }

    els.siteWhitelist.addEventListener('input', scheduleSave);
    els.siteWhitelist.addEventListener('change', saveNow);
    els.siteWhitelist.addEventListener('blur', saveNow);

    els.resetDefaults.addEventListener('click', function () {
      state.suppress = true;
      state.settings = normalizeSettings(DEFAULTS);
      fillForm(state.settings);
      state.suppress = false;
      updatePreview();
      save(state.settings);
      showHint('已恢复默认设置', false);
    });

    try {
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area !== 'sync' && area !== 'local') return;
        if (!changes || !changes[SETTINGS_KEY]) return;
        var incoming = JSON.stringify(normalizeSettings(changes[SETTINGS_KEY].newValue));
        if (incoming === state.lastWrittenJson) return; // 自己写入的，忽略
        state.settings = normalizeSettings(changes[SETTINGS_KEY].newValue);
        state.lastWrittenJson = incoming;
        state.suppress = true;
        fillForm(state.settings);
        state.suppress = false;
        showHint('设置已从其它页面更新', false);
      });
    } catch (err) { /* 忽略 */ }
  }

  /** 切到「自定义」时，若权重还是空的，用当前生效权重预填，省得用户从 0 开始 */
  function prefillCustomWeights() {
    var total = 0;
    for (var i = 0; i < METRIC_KEYS.length; i++) {
      total += clampNumber(els.weights[METRIC_KEYS[i]].value, 0, 100, 0);
    }
    if (total > 0) return;
    var source = (state.presetWeights && (state.presetWeights.balanced || state.presetWeights.smoothing)) || null;
    for (var j = 0; j < METRIC_KEYS.length; j++) {
      var key = METRIC_KEYS[j];
      var value = source && isFinite(Number(source[key])) ? Math.round(Number(source[key]) * 100) : 0;
      els.weights[key].value = String(value);
    }
    updateWeightSum();
  }

  function init() {
    els.saveHint = $('save-hint');
    els.resetDefaults = $('reset-defaults');
    els.hoverEnabled = $('hover-enabled');
    els.minImageSize = $('min-image-size');
    els.hoverDelay = $('hover-delay');
    els.sensitivity = $('sensitivity');
    els.sensitivityValue = $('sensitivity-value');
    els.customGroup = $('custom-group');
    els.weightSum = $('weight-sum');
    els.effectiveWeights = $('effective-weights');
    els.siteWhitelist = $('site-whitelist');
    els.showDebug = $('show-debug');
    els.engineVersion = $('engine-version');
    els.weights = {
      smoothing: $('w-smoothing'),
      whitening: $('w-whitening'),
      uniformity: $('w-uniformity'),
      chroma: $('w-chroma'),
      contrast: $('w-contrast')
    };

    if (els.engineVersion) {
      var version = '1.0.0';
      try { version = chrome.runtime.getManifest().version; } catch (err) { /* 用兜底版本号 */ }
      els.engineVersion.textContent = '素颜镜 v' + version + ' · 分析引擎由后台 Service Worker 加载';
    }

    bind();
    loadSettings();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
