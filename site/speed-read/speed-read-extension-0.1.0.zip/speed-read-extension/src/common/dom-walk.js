/**
 * 一目十行 · 正文抽取 dom-walk.js
 * ---------------------------------------------------------------------------
 * 只做一件事：把一个 DOM 子树变成「按阅读顺序排列的正文块」。
 * 刻意不用 querySelectorAll / getComputedStyle / innerText —— 只用
 * nodeType / tagName / childNodes / getAttribute / style，于是：
 *   · 在真实 Chrome 里跑得动；
 *   · 在 node --test 里用 20 行假 DOM 就能覆盖，不需要 jsdom 之类的依赖。
 *
 * 抽取策略（readability 的轻量做法）：
 *   1) 先按「正文长度 × (1-链接密度) × 句读密度 × 标签加成」选一个最佳容器，
 *      把导航/页脚/侧栏/广告整块甩掉；
 *   2) 再在容器内按块收集文本（p/h1-h6/li/td/blockquote/pre…）；
 *   3) 遇到「只有内联子元素」的 div，把它当成段落块 —— X/微博这类 div 站才抓得到；
 *   4) 结果保持 DOM 顺序，交给 speedread-core 按信息密度裁剪。
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.SpeedReadDom = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var SKIP_TAGS = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'SVG', 'CANVAS', 'IFRAME', 'OBJECT',
    'EMBED', 'VIDEO', 'AUDIO', 'SOURCE', 'TRACK', 'FORM', 'INPUT', 'TEXTAREA',
    'SELECT', 'OPTION', 'OPTGROUP', 'BUTTON', 'MENU', 'DIALOG', 'LINK', 'META',
    'HEAD', 'BASE', 'PARAM', 'MAP', 'AREA', 'PROGRESS', 'METER', 'OUTPUT', 'SLOT'
  ]);

  /** 结构性容器：不直接产块，继续往下走 */
  var CONTAINER_TAGS = new Set([
    'ARTICLE', 'MAIN', 'SECTION', 'DIV', 'BODY', 'HTML', 'NAV', 'HEADER', 'FOOTER',
    'ASIDE', 'UL', 'OL', 'DL', 'TABLE', 'THEAD', 'TBODY', 'TFOOT', 'TR', 'FIGURE',
    'PICTURE', 'DETAILS', 'FIELDSET', 'CENTER', 'ADDRESS'
  ]);

  /** 天然段落：直接产块，不再向下递归（避免重复计数） */
  var BLOCK_TAGS = new Set([
    'P', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'LI', 'TD', 'TH', 'BLOCKQUOTE', 'PRE',
    'DD', 'DT', 'FIGCAPTION', 'SUMMARY', 'CAPTION', 'LEGEND', 'LABEL'
  ]);

  var INLINE_TAGS = new Set([
    'A', 'SPAN', 'STRONG', 'B', 'EM', 'I', 'U', 'S', 'DEL', 'INS', 'SMALL', 'MARK',
    'CODE', 'KBD', 'SAMP', 'VAR', 'SUB', 'SUP', 'ABBR', 'TIME', 'CITE', 'Q', 'BR',
    'WBR', 'FONT', 'BDI', 'BDO', 'RUBY', 'RT', 'RP', 'IMG', 'PICTURE', 'NOBR', 'TT'
  ]);

  var BLOCK_WEIGHT = {
    H1: 1.18, H2: 1.14, H3: 1.1, H4: 1.06, H5: 1.04, H6: 1.02,
    P: 1.0, BLOCKQUOTE: 1.0, LI: 0.96, TD: 0.9, TH: 0.92, DD: 0.96, DT: 1.0,
    FIGCAPTION: 0.86, SUMMARY: 0.9, CAPTION: 0.86, PRE: 0.86, LABEL: 0.8,
    DIV: 0.92
  };

  var MAX_NODES = 24000;
  var MAX_BLOCKS = 1500;
  var MIN_BLOCK_CHARS = 12;
  var MIN_CONTAINER_CHARS = 240;

  /**
   * 样板区名字。语义标签（nav/footer/aside）之外，大量站点用 div 冒充，
   * 所以 id/class 命中这些名字的容器整块丢掉。
   */
  var BOILERPLATE_NAME = /(^|[\s_-])(nav|navbar|navigation|nav-bar|sidebar|side-bar|menu|breadcrumb|footer|foot-bar|topbar|top-bar|toolbar|masthead|site-header|siteheader|comment-form|commentform|advert|advertisement|promo)([\s_-]|$)/;

  var CJK_OR_WORD = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]|[A-Za-z]{2,}|\d/;
  var SENTENCE_END = /[。！？!?；;]/g;

  function tagOf(node) {
    return String((node && node.tagName) || '').toUpperCase();
  }

  function attr(el, name) {
    if (!el || typeof el.getAttribute !== 'function') return null;
    return el.getAttribute(name);
  }

  /** 该节点是否属于「一目十行」自己的面板（绝不能把自己摘要了） */
  function isOwnUi(el) {
    if (attr(el, 'data-sr-root') != null) return true;
    var cls = attr(el, 'class') || '';
    var id = attr(el, 'id') || '';
    return /(^|[\s-])sr-(panel|host|root)([\s-]|$)/.test(cls) || /speedread-(panel|host|root)/.test(id);
  }

  function isHidden(el, depth) {
    if (isOwnUi(el)) return true;
    if (el.hasAttribute && el.hasAttribute('hidden')) return true;
    if (attr(el, 'aria-hidden') === 'true') return true;
    if (attr(el, 'data-sr-skip') != null) return true;
    var style = el.style;
    if (style && typeof style === 'object') {
      var display = style.display || '';
      var visibility = style.visibility || '';
      if (display === 'none' || visibility === 'hidden') return true;
    }
    var tag = tagOf(el);
    if (tag === 'NAV' || tag === 'ASIDE' || tag === 'FOOTER' || tag === 'DIALOG') return true;
    // 浅层 header 基本是站点导航空壳；文章内部的 header 仍然保留
    if (tag === 'HEADER' && depth <= 3) return true;
    // id/class 里的样板名：现代站点大量用 div 冒充 nav/footer（没有语义标签可用）
    if (tag === 'DIV' || tag === 'SECTION' || tag === 'UL' || tag === 'SPAN') {
      var hint = ((attr(el, 'id') || '') + ' ' + (attr(el, 'class') || '')).toLowerCase();
      if (BOILERPLATE_NAME.test(hint)) return true;
    }
    return false;
  }

  /** 递归取文本；跳过 SKIP_TAGS 与隐藏子树；<br> 记成换行 */
  function textOf(el, budget) {
    var limit = budget == null ? 200000 : budget;
    var out = [];

    function visit(node) {
      if (out.length > limit) return;
      var type = node.nodeType;
      if (type === 3 || type === 4) {
        var data = node.data == null ? node.textContent : node.data;
        if (data) out.push(String(data));
        return;
      }
      if (type !== 1) return;
      var tag = tagOf(node);
      if (tag === 'BR') { out.push('\n'); return; }
      if (SKIP_TAGS.has(tag)) return;
      if (isOwnUi(node)) return;
      if (node.hasAttribute && node.hasAttribute('hidden')) return;
      if (attr(node, 'aria-hidden') === 'true') return;
      var kids = node.childNodes;
      if (!kids) return;
      for (var i = 0; i < kids.length; i++) visit(kids[i]);
    }

    visit(el);
    return out.join('');
  }

  function collapse(text) {
    return String(text || '')
      .replace(/\u00a0|\u2000-\u200a|\u3000|\u202f|\u205f/g, ' ')
      .replace(/\s+/g, ' ')
      .replace(/^[\s·•|]+|[\s·•|]+$/g, '')
      .trim();
  }

  function elementChildren(el) {
    var kids = el.childNodes || [];
    var out = [];
    for (var i = 0; i < kids.length; i++) if (kids[i].nodeType === 1) out.push(kids[i]);
    return out;
  }

  /** 链接文本占该子树文本的比例（导航/列表页的判据） */
  function linkStats(el, acc) {
    var a = acc || { total: 0, link: 0 };
    var kids = el.childNodes || [];
    for (var i = 0; i < kids.length; i++) {
      var node = kids[i];
      if (node.nodeType === 3) { a.total += String(node.data || '').length; continue; }
      if (node.nodeType !== 1) continue;
      var tag = tagOf(node);
      if (SKIP_TAGS.has(tag)) continue;
      var sub = linkStats(node, { total: 0, link: 0 });
      a.total += sub.total;
      a.link += sub.link;
      if (tag === 'A') a.link += sub.total;
    }
    return a;
  }

  function linkDensity(el) {
    var st = linkStats(el);
    if (!st.total) return 0;
    return Math.min(1, st.link / st.total);
  }

  function countSentenceEnds(text) {
    var m = text.match(SENTENCE_END);
    return m ? m.length : 0;
  }

  function countTextNodes(el, cap) {
    var n = 0;
    var stack = [el];
    while (stack.length && n < cap) {
      var cur = stack.pop();
      var kids = cur.childNodes || [];
      for (var i = 0; i < kids.length; i++) {
        if (kids[i].nodeType === 3) n++;
        else if (kids[i].nodeType === 1) stack.push(kids[i]);
      }
    }
    return n;
  }

  /** 容器加分：语义标签 + role/id/class 提示 */
  function containerBonus(el) {
    var tag = tagOf(el);
    var bonus = 1;
    if (tag === 'ARTICLE') bonus *= 1.35;
    else if (tag === 'MAIN') bonus *= 1.3;
    else if (tag === 'BODY') bonus *= 0.95;
    else if (tag === 'TD') bonus *= 0.92;
    if (attr(el, 'role') === 'main') bonus *= 1.22;
    if (attr(el, 'itemprop') === 'articleBody') bonus *= 1.3;
    var hint = ((attr(el, 'id') || '') + ' ' + (attr(el, 'class') || '')).toLowerCase();
    if (/(article|post|content|entry|story|main|markdown|prose|rich_?text|body)/.test(hint)) bonus *= 1.16;
    if (/(comment|reply|sidebar|widget|related|recommend|footer|header|nav|advert|promo|breadcrumb)/.test(hint)) bonus *= 0.8;
    return bonus;
  }

  function scoreContainer(el, depth, minChars) {
    var text = collapse(textOf(el, 120000));
    var len = text.length;
    if (len < (minChars || MIN_CONTAINER_CHARS)) return null;
    var ld = linkDensity(el);
    if (ld > 0.55) return null;
    var ends = countSentenceEnds(text);
    var expectedEnds = Math.max(1, len / 130);
    var punctBonus = Math.min(1.2, ends / expectedEnds);
    var density = (1 - Math.min(0.9, ld));
    var score = len * Math.pow(density, 1.5) * (1 + 0.18 * punctBonus) * containerBonus(el);
    score *= 1 + Math.min(depth, 10) * 0.012;
    var textNodes = countTextNodes(el, 4000);
    // 只有一两个文本节点的容器多半是标题栏，不是正文
    if (textNodes <= 2 && len < 600) score *= 0.7;
    return { el: el, score: score, text: text, chars: len, linkDensity: ld, depth: depth, textNodes: textNodes };
  }

  /** 找一个最佳正文容器；找不到就退回传入的根 */
  function findMainContainer(rootEl, opts) {
    var o = opts || {};
    var maxVisits = o.maxVisits || 4000;
    var best = null;
    var visited = 0;
    var queue = [{ el: rootEl, depth: 0 }];

    // 阈值随页面长度自适应：短页面（div 汤、卡片页）正文可能只有一百多字，
    // 固定 240 字会让它选不出容器、退化成「整个 body 都算正文」，把导航也带上。
    var rootChars = collapse(textOf(rootEl, 120000)).length;
    var minChars = Math.min(MIN_CONTAINER_CHARS, Math.max(120, Math.round(rootChars * 0.35)));

    while (queue.length && visited < maxVisits) {
      var cur = queue.shift();
      visited++;
      var el = cur.el;
      if (!el || el.nodeType !== 1) continue;

      var stat = scoreContainer(el, cur.depth, minChars);
      if (stat && (!best || stat.score > best.score)) best = stat;

      var tag = tagOf(el);
      if (tag === 'SECTION' || tag === 'ARTICLE' || tag === 'DIV' || tag === 'MAIN' || tag === 'BODY' || tag === 'HTML') {
        var kids = elementChildren(el);
        for (var i = 0; i < kids.length; i++) {
          if (isHidden(kids[i], cur.depth + 1)) continue;
          queue.push({ el: kids[i], depth: cur.depth + 1 });
        }
      }
    }

    if (!best) {
      var rootText = collapse(textOf(rootEl, 120000));
      return { el: rootEl, score: 0, text: rootText, chars: rootText.length, linkDensity: linkDensity(rootEl), depth: 0, fallback: true };
    }
    return best;
  }

  /** 只有内联子元素 → 当成段落 */
  function isLeafish(el) {
    var kids = elementChildren(el);
    if (!kids.length) return true;
    for (var i = 0; i < kids.length; i++) {
      var tag = tagOf(kids[i]);
      if (!INLINE_TAGS.has(tag)) return false;
    }
    return kids.length <= 20;
  }

  function makeBlock(el, text, depth, tagOverride) {
    var tag = tagOverride || tagOf(el) || 'DIV';
    var ld = linkDensity(el);
    return {
      tag: tag,
      text: collapse(text),
      depth: depth,
      weight: (BLOCK_WEIGHT[tag] || 0.9) * (ld > 0.5 ? 0.7 : 1),
      linkDensity: ld
    };
  }

  /** 在容器内按阅读顺序收集正文块 */
  function collectBlocks(container, opts) {
    var o = opts || {};
    var minChars = o.minChars == null ? MIN_BLOCK_CHARS : o.minChars;
    var maxBlocks = o.maxBlocks || MAX_BLOCKS;
    var maxLinkDensity = o.maxLinkDensity == null ? 0.6 : o.maxLinkDensity;
    var allowAllLinks = o.allowAllLinks === true;
    var blocks = [];
    var guard = { nodes: 0 };

    function walk(el, depth) {
      if (blocks.length >= maxBlocks || guard.nodes > MAX_NODES) return;
      guard.nodes++;
      if (!el || el.nodeType !== 1) return;
      var tag = tagOf(el);
      if (SKIP_TAGS.has(tag)) return;
      if (isHidden(el, depth)) return;
      if (isOwnUi(el)) return;

      if (BLOCK_TAGS.has(tag)) {
        var text = collapse(textOf(el, 20000));
        if (text.length >= minChars && CJK_OR_WORD.test(text)) blocks.push(makeBlock(el, text, depth));
        return;
      }

      var kids = elementChildren(el);
      if (isLeafish(el)) {
        var leaf = collapse(textOf(el, 20000));
        if (leaf.length >= minChars && CJK_OR_WORD.test(leaf)) {
          var block = makeBlock(el, leaf, depth, 'DIV');
          // 几乎全是链接的块就是导航/相关阅读，不是正文
          if (allowAllLinks || block.linkDensity < maxLinkDensity) blocks.push(block);
        }
        return;
      }

      for (var i = 0; i < kids.length; i++) walk(kids[i], depth + 1);
    }

    var rootKids = elementChildren(container);
    if (!rootKids.length) {
      walk(container, 0);
    } else {
      for (var i = 0; i < rootKids.length; i++) walk(rootKids[i], 1);
    }

    // 安全网：如果整页正文本身就是一堆链接（导航站 / 链接聚合页），
    // 过滤后会一条不剩，那就关掉过滤重来一次，宁可噪音也不要空结果。
    if (!blocks.length && !allowAllLinks) {
      return collectBlocks(container, Object.assign({}, o, { allowAllLinks: true }));
    }
    return blocks;
  }

  /**
   * 抽取入口。
   * opts: { root, title, description, url, maxBlocks, minChars }
   * 返回 { blocks, text, chars, container:{chars,linkDensity,score}, stats }
   */
  function extractPage(opts) {
    var o = opts || {};
    var rootEl = o.root;
    var result = { blocks: [], text: '', chars: 0, stats: { parsed: false, reason: '' } };
    if (!rootEl || rootEl.nodeType !== 1) {
      result.stats.reason = 'no-root';
      return result;
    }

    var container = findMainContainer(rootEl, { maxVisits: o.maxVisits });
    var blocks = collectBlocks(container.el, { minChars: o.minChars, maxBlocks: o.maxBlocks });

    // 元信息：描述常是高质量的一句话结论，放最前面但权重不拔高
    var description = collapse(o.description || '');
    if (description.length >= 30) {
      blocks.unshift({
        tag: 'P',
        text: description,
        depth: 0,
        weight: 1.0,
        linkDensity: 0,
        source: 'description'
      });
    }

    var texts = [];
    var total = 0;
    for (var i = 0; i < blocks.length; i++) {
      texts.push(blocks[i].text);
      total += blocks[i].text.length;
    }

    result.blocks = blocks;
    result.text = texts.join('\n');
    result.chars = total;
    result.container = {
      tag: tagOf(container.el),
      chars: container.chars || 0,
      linkDensity: Number((container.linkDensity || 0).toFixed(3)),
      score: Math.round(container.score || 0),
      fallback: !!container.fallback
    };
    result.stats = {
      parsed: blocks.length > 0,
      reason: blocks.length ? '' : 'no-blocks',
      blockCount: blocks.length,
      containerChars: container.chars || 0,
      droppedByContainer: Math.max(0, (container.chars || 0) - total)
    };
    return result;
  }

  return {
    SKIP_TAGS: SKIP_TAGS,
    BLOCK_TAGS: BLOCK_TAGS,
    CONTAINER_TAGS: CONTAINER_TAGS,
    BLOCK_WEIGHT: BLOCK_WEIGHT,
    MIN_CONTAINER_CHARS: MIN_CONTAINER_CHARS,
    tagOf: tagOf,
    isHidden: isHidden,
    isOwnUi: isOwnUi,
    textOf: textOf,
    collapse: collapse,
    linkDensity: linkDensity,
    countSentenceEnds: countSentenceEnds,
    containerBonus: containerBonus,
    scoreContainer: scoreContainer,
    findMainContainer: findMainContainer,
    isLeafish: isLeafish,
    collectBlocks: collectBlocks,
    extractPage: extractPage
  };
});
