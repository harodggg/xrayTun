/**
 * 一目十行 · 设置页
 * ---------------------------------------------------------------------------
 * 一个声明式字段映射表把表单和配置连起来：加字段只改 FIELDS。
 * 改动 500ms 防抖自动保存；「保存」按钮立即落盘并广播给所有已打开页面。
 */
'use strict';

var Settings = window.SpeedReadSettings;
var $ = function (id) { return document.getElementById(id); };

var FIELDS = [
  { id: 'model', path: 'model', type: 'text' },
  { id: 'baseUrl', path: 'baseUrl', type: 'text' },
  { id: 'apiKey', path: 'apiKey', type: 'text' },
  { id: 'lang', path: 'lang', type: 'select' },
  { id: 'maxCharsPerItem', path: 'maxCharsPerItem', type: 'number' },
  { id: 'maxChars', path: 'maxChars', type: 'number' },
  { id: 'temperature', path: 'temperature', type: 'number' },
  { id: 'maxTokens', path: 'maxTokens', type: 'number' },
  { id: 'timeoutMs', path: 'timeoutMs', type: 'number' },
  { id: 'fallbackLocal', path: 'fallbackLocal', type: 'check' },
  { id: 'autoUpdate', path: 'autoUpdate', type: 'check' },
  { id: 'dirtyOnScroll', path: 'dirtyOnScroll', type: 'check' },
  { id: 'debounceMs', path: 'debounceMs', type: 'number' },
  { id: 'minIntervalMs', path: 'minIntervalMs', type: 'number' },
  { id: 'minDeltaChars', path: 'minDeltaChars', type: 'number' },
  { id: 'minDeltaRatio', path: 'minDeltaRatio', type: 'number' },
  { id: 'pollMs', path: 'pollMs', type: 'number' },
  { id: 'cacheTtlMs', path: 'cacheTtlMs', type: 'number' },
  { id: 'corner', path: 'panel.corner', type: 'select' },
  { id: 'theme', path: 'panel.theme', type: 'select' },
  { id: 'width', path: 'panel.width', type: 'number' },
  { id: 'fontSize', path: 'panel.fontSize', type: 'number' },
  { id: 'opacity', path: 'panel.opacity', type: 'number' },
  { id: 'showEvidence', path: 'panel.showEvidence', type: 'check' },
  { id: 'showFoot', path: 'panel.showFoot', type: 'check' },
  { id: 'skipTinyChars', path: 'skipTinyChars', type: 'number' },
  { id: 'allowFileUrls', path: 'allowFileUrls', type: 'check' },
  { id: 'blacklist', path: 'blacklist', type: 'lines' }
];

var current = null;
var saveTimer = null;

function getPath(obj, path) {
  return path.split('.').reduce(function (acc, key) {
    return acc && typeof acc === 'object' ? acc[key] : undefined;
  }, obj);
}

function setPath(obj, path, value) {
  var keys = path.split('.');
  var cur = obj;
  for (var i = 0; i < keys.length - 1; i++) {
    if (!cur[keys[i]] || typeof cur[keys[i]] !== 'object') cur[keys[i]] = {};
    cur = cur[keys[i]];
  }
  cur[keys[keys.length - 1]] = value;
}

function send(message) {
  return new Promise(function (resolve) {
    chrome.runtime.sendMessage(message, function (res) {
      void chrome.runtime.lastError;
      resolve(res || null);
    });
  });
}

function hint(text, kind) {
  var node = $('saveHint');
  node.textContent = text;
  node.className = 'save-hint' + (kind ? ' ' + kind : '');
  if (kind === 'ok') setTimeout(function () { if (node.textContent === text) node.textContent = ''; }, 2400);
}

function fillPresets() {
  var select = $('provider');
  select.textContent = '';
  Object.keys(Settings.PRESETS).forEach(function (key) {
    var option = document.createElement('option');
    option.value = key;
    option.textContent = Settings.PRESETS[key].label;
    select.appendChild(option);
  });
}

function writeForm(cfg) {
  current = cfg;
  FIELDS.forEach(function (field) {
    var node = $(field.id);
    if (!node) return;
    var value = getPath(cfg, field.path);
    if (field.type === 'check') node.checked = !!value;
    else if (field.type === 'lines') node.value = (value || []).join('\n');
    else node.value = value == null ? '' : String(value);
  });
  $('provider').value = cfg.provider || 'custom';
  renderStats();
}

function readForm() {
  var patch = {};
  FIELDS.forEach(function (field) {
    var node = $(field.id);
    if (!node) return;
    if (field.type === 'check') setPath(patch, field.path, !!node.checked);
    else if (field.type === 'lines') {
      setPath(patch, field.path, String(node.value || '').split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean));
    } else if (field.type === 'number') setPath(patch, field.path, node.value === '' ? undefined : Number(node.value));
    else setPath(patch, field.path, node.value);
  });
  patch.provider = $('provider').value;
  return patch;
}

function applyPresetToForm(key) {
  var preset = Settings.PRESETS[key];
  if (!preset || key === 'custom') return;
  $('baseUrl').value = preset.baseUrl;
  $('model').value = preset.model;
}

async function save(quiet) {
  var patch = readForm();
  var merged = Settings.mergeSettings(Settings.deepMerge(current || {}, patch));
  var report = Settings.validate(merged);
  await Settings.saveSettings(Settings.makeStore(chrome.storage.local), merged);
  current = merged;
  await send({ type: 'SR_SETTINGS_CHANGED' });
  if (!quiet) {
    var bad = report.issues.filter(function (i) { return i.level === 'warn'; });
    if (!report.ok) hint('已保存，但配置还不完整', 'bad');
    else if (bad.length) hint('已保存 ⚠ ' + bad[0].message, 'bad');
    else hint('已保存，所有已打开的页面会立刻重算', 'ok');
  }
  return merged;
}

function autosave() {
  clearTimeout(saveTimer);
  hint('正在保存…');
  saveTimer = setTimeout(function () { save(false); }, 500);
}

async function renderStats() {
  var res = await send({ type: 'SR_STATS' });
  var stats = res && res.stats;
  var lines = [];
  if (!stats) {
    lines.push('还没有运行记录。');
  } else {
    lines.push('总运行次数      ' + stats.runs);
    lines.push('其中 AI 摘要    ' + stats.llm);
    lines.push('其中本地兜底    ' + stats.local);
    lines.push('最近一次        ' + (stats.lastAt ? new Date(stats.lastAt).toLocaleString() : '—'));
    lines.push('最近使用的模型  ' + (stats.lastModel || '—'));
  }
  var check = Settings.validate(current || {});
  lines.push('');
  lines.push('配置检查        ' + (check.ok ? '通过' : check.issues.filter(function (i) { return i.level === 'error'; }).map(function (i) { return i.message; }).join('、')));
  check.issues.filter(function (i) { return i.level === 'warn'; }).forEach(function (i) {
    lines.push('提示            ' + i.message);
  });
  $('stats').textContent = lines.join('\n');
}

function boot() {
  fillPresets();

  Settings.loadSettings(Settings.makeStore(chrome.storage.local)).then(function (cfg) {
    writeForm(cfg);
  });

  FIELDS.forEach(function (field) {
    var node = $(field.id);
    if (!node) return;
    var event = (field.type === 'check' || field.type === 'select') ? 'change' : 'input';
    node.addEventListener(event, autosave);
    if (field.type === 'number') node.addEventListener('change', autosave);
  });

  $('provider').addEventListener('change', function () {
    applyPresetToForm($('provider').value);
    autosave();
  });

  $('toggleKey').addEventListener('click', function () {
    var input = $('apiKey');
    var shown = input.type === 'text';
    input.type = shown ? 'password' : 'text';
    $('toggleKey').textContent = shown ? '显示' : '隐藏';
  });

  $('save').addEventListener('click', function () { save(false); });

  $('test').addEventListener('click', async function () {
    var btn = $('test');
    var out = $('testResult');
    btn.disabled = true;
    out.className = 'test-result';
    out.textContent = '请求中…';
    var patch = readForm();
    var res = await send({ type: 'SR_TEST_CONNECTION', overrides: Settings.mergeSettings(patch) });
    btn.disabled = false;
    if (res && res.ok) {
      out.className = 'test-result ok';
      out.textContent = '连接成功 · ' + res.model + ' · ' + res.ms + 'ms · ' + (res.jsonModeUsed ? '支持 JSON 模式' : '已自动降级为纯文本模式') + (res.sample ? ' · 回包：' + res.sample : '');
    } else {
      out.className = 'test-result bad';
      out.textContent = '失败：' + ((res && res.message) || '未知错误') + ((res && res.hint) ? ' —— ' + res.hint : '');
    }
  });

  $('clearCache').addEventListener('click', async function () {
    var res = await send({ type: 'SR_CLEAR_CACHE' });
    $('cacheResult').className = 'test-result ok';
    $('cacheResult').textContent = res && res.ok ? '已清空 ' + res.cleared + ' 条缓存' : '清空失败';
  });

  $('resetPos').addEventListener('click', async function () {
    var store = Settings.makeStore(chrome.storage.local);
    var panel = await Settings.loadPanel(store);
    panel.x = null;
    panel.y = null;
    panel.hidden = false;
    panel.collapsed = false;
    await Settings.savePanel(store, panel);
    await send({ type: 'SR_SETTINGS_CHANGED' });
    if (current) { current.panel = Settings.deepMerge(current.panel, { x: null, y: null, hidden: false, collapsed: false }); writeForm(current); }
    hint('面板位置已重置', 'ok');
  });

  $('reset').addEventListener('click', async function () {
    if (!confirm('恢复默认设置？API Key 也会被清掉。')) return;
    var defaults = Settings.mergeSettings({});
    await Settings.saveSettings(Settings.makeStore(chrome.storage.local), defaults);
    writeForm(defaults);
    await send({ type: 'SR_CLEAR_CACHE' });
    await send({ type: 'SR_SETTINGS_CHANGED' });
    hint('已恢复默认', 'ok');
  });

  $('export').addEventListener('click', function () {
    var clone = JSON.parse(JSON.stringify(current || {}));
    delete clone.apiKey;
    var blob = new Blob([JSON.stringify(clone, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'speedread-settings.json';
    a.click();
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
    hint('已导出（不含 API Key）', 'ok');
  });

  $('import').addEventListener('click', function () { $('importFile').click(); });
  $('importFile').addEventListener('change', function () {
    var file = $('importFile').files && $('importFile').files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var parsed = JSON.parse(String(reader.result));
        var merged = Settings.mergeSettings(Settings.deepMerge(current || {}, parsed));
        writeForm(merged);
        save(false);
      } catch (e) {
        hint('导入失败：' + e.message, 'bad');
      }
    };
    reader.readAsText(file);
  });

  setInterval(renderStats, 5000);
}

boot();
