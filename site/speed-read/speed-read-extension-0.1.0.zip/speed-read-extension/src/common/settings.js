/**
 * 一目十行 · 配置 settings.js
 * ---------------------------------------------------------------------------
 * 单一事实来源：默认值、服务商预设、合并/清洗规则、站点黑名单匹配。
 * 存储层由调用方注入（chrome.storage.local / chrome.storage.session 或测试用的假 storage），
 * 本文件本身不做任何 I/O，便于单测。
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.SpeedReadSettings = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var STORAGE_KEY = 'sr.settings';
  var PANEL_KEY = 'sr.panel';
  var STATS_KEY = 'sr.stats';
  var CACHE_PREFIX = 'sr.cache.';
  var TAB_PREFIX = 'sr.tab.';

  /**
   * 服务商预设：全部走 OpenAI 兼容的 /chat/completions，只换 Base URL 与默认模型。
   * Base URL 只写到 /v1 一级，不要带 /chat/completions（客户端会自动补）。
   */
  var PRESETS = {
    openrouter: { label: 'OpenRouter（一个 Key 用多家模型）', baseUrl: 'https://openrouter.ai/api/v1', model: 'openai/gpt-4o-mini' },
    openai: { label: 'OpenAI 官方', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
    deepseek: { label: 'DeepSeek 官方', baseUrl: 'https://api.deepseek.com/v1', model: 'deepseek-chat' },
    moonshot: { label: 'Moonshot / Kimi', baseUrl: 'https://api.moonshot.cn/v1', model: 'moonshot-v1-8k' },
    dashscope: { label: '阿里云百炼（通义）', baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1', model: 'qwen-plus' },
    siliconflow: { label: '硅基流动 SiliconFlow', baseUrl: 'https://api.siliconflow.cn/v1', model: 'Qwen/Qwen2.5-7B-Instruct' },
    zhipu: { label: '智谱 GLM', baseUrl: 'https://open.bigmodel.cn/api/paas/v4', model: 'glm-4-flash' },
    volcengine: { label: '火山方舟（豆包）', baseUrl: 'https://ark.cn-beijing.volces.com/api/v3', model: 'doubao-pro-32k' },
    custom: { label: '自定义 / 自建网关', baseUrl: '', model: '' }
  };

  var DEFAULTS = {
    // —— 模型 ——
    provider: 'openrouter',
    baseUrl: PRESETS.openrouter.baseUrl,
    model: PRESETS.openrouter.model,
    apiKey: '',
    temperature: 0.2,
    maxTokens: 700,
    timeoutMs: 20000,
    retries: 1,
    repairAttempts: 1,
    fallbackLocal: true,

    // —— 摘要 ——
    lang: 'auto',              // auto | zh | en
    maxChars: 6000,            // 单次送入模型的正文上限（越大越贵）
    maxCharsPerItem: 60,       // 每条信息字数上限

    // —— 自动更新（用户核心诉求：页面一变就重算）——
    autoUpdate: true,
    debounceMs: 1600,          // 页面静默多久后重算
    minIntervalMs: 5000,       // 两次真实 API 调用之间的最小间隔
    minDeltaChars: 200,        // 正文变化少于这么多字，视为噪声
    minDeltaRatio: 0.12,       // 或变化比例低于此值，视为噪声
    pollMs: 20000,             // 兜底轮询（应对无 DOM 变化的轮询式页面）
    cacheTtlMs: 1800000,       // 同一内容 30 分钟内复用结果，不重复花钱
    dirtyOnScroll: false,      // 是否在滚动后再核一次（懒加载站点可开）

    // —— 跳过 ——
    skipTinyChars: 260,        // 正文太短的页面直接跳过
    blacklist: [],             // 形如 example.com / *.bank.com / 192.168.
    allowFileUrls: false,

    // —— 面板 ——
    panel: {
      corner: 'top-right',     // top-right | top-left | bottom-right | bottom-left
      x: null,
      y: null,
      width: 420,
      fontSize: 13,
      opacity: 0.98,
      theme: 'dark',           // dark | light
      collapsed: false,
      hidden: false,
      showEvidence: true,
      // 严格「只显示 3 条」：关掉后底部连来源/耗时都不显示，面板上只剩 3 行
      showFoot: true
    }
  };

  function isPlainObject(v) {
    return !!v && typeof v === 'object' && !Array.isArray(v);
  }

  function clone(v) {
    if (Array.isArray(v)) return v.map(clone);
    if (isPlainObject(v)) {
      var out = {};
      for (var k in v) if (Object.prototype.hasOwnProperty.call(v, k)) out[k] = clone(v[k]);
      return out;
    }
    return v;
  }

  function deepMerge(base, patch) {
    var out = clone(base);
    if (!isPlainObject(patch)) return out;
    for (var k in patch) {
      if (!Object.prototype.hasOwnProperty.call(patch, k)) continue;
      var pv = patch[k];
      if (isPlainObject(pv) && isPlainObject(out[k])) out[k] = deepMerge(out[k], pv);
      else if (pv !== undefined) out[k] = clone(pv);
    }
    return out;
  }

  function num(v, lo, hi, dflt) {
    var n = Number(v);
    if (!isFinite(n)) return dflt;
    return n < lo ? lo : n > hi ? hi : n;
  }

  function str(v, max) {
    var s = String(v == null ? '' : v).trim();
    return max && s.length > max ? s.slice(0, max) : s;
  }

  function normalizeList(list) {
    if (!Array.isArray(list)) return [];
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var p = str(list[i], 200).toLowerCase();
      if (p && out.indexOf(p) < 0) out.push(p);
      if (out.length >= 200) break;
    }
    return out;
  }

  /** 合并存储值 → 永远返回一份完整、合法、已 clamp 的配置 */
  function mergeSettings(stored) {
    var s = deepMerge(DEFAULTS, stored || {});
    s.provider = PRESETS[s.provider] ? s.provider : 'custom';
    s.baseUrl = str(s.baseUrl, 400).replace(/\/+$/, '');
    s.model = str(s.model, 200);
    s.apiKey = str(s.apiKey, 400);
    s.temperature = num(s.temperature, 0, 2, DEFAULTS.temperature);
    s.maxTokens = Math.round(num(s.maxTokens, 64, 8192, DEFAULTS.maxTokens));
    s.timeoutMs = Math.round(num(s.timeoutMs, 3000, 180000, DEFAULTS.timeoutMs));
    s.retries = Math.round(num(s.retries, 0, 3, DEFAULTS.retries));
    s.repairAttempts = Math.round(num(s.repairAttempts, 0, 2, DEFAULTS.repairAttempts));
    s.fallbackLocal = s.fallbackLocal !== false;
    s.lang = ['auto', 'zh', 'en'].indexOf(s.lang) >= 0 ? s.lang : 'auto';
    s.maxChars = Math.round(num(s.maxChars, 800, 60000, DEFAULTS.maxChars));
    s.maxCharsPerItem = Math.round(num(s.maxCharsPerItem, 16, 200, DEFAULTS.maxCharsPerItem));
    s.autoUpdate = s.autoUpdate !== false;
    s.debounceMs = Math.round(num(s.debounceMs, 300, 15000, DEFAULTS.debounceMs));
    s.minIntervalMs = Math.round(num(s.minIntervalMs, 0, 300000, DEFAULTS.minIntervalMs));
    s.minDeltaChars = Math.round(num(s.minDeltaChars, 0, 20000, DEFAULTS.minDeltaChars));
    s.minDeltaRatio = num(s.minDeltaRatio, 0, 1, DEFAULTS.minDeltaRatio);
    s.pollMs = Math.round(num(s.pollMs, 5000, 600000, DEFAULTS.pollMs));
    s.cacheTtlMs = Math.round(num(s.cacheTtlMs, 0, 86400000, DEFAULTS.cacheTtlMs));
    s.dirtyOnScroll = s.dirtyOnScroll === true;
    s.skipTinyChars = Math.round(num(s.skipTinyChars, 0, 10000, DEFAULTS.skipTinyChars));
    s.blacklist = normalizeList(s.blacklist);
    s.allowFileUrls = s.allowFileUrls === true;
    s.panel = deepMerge(DEFAULTS.panel, s.panel);
    s.panel.corner = ['top-right', 'top-left', 'bottom-right', 'bottom-left'].indexOf(s.panel.corner) >= 0 ? s.panel.corner : 'top-right';
    s.panel.width = Math.round(num(s.panel.width, 300, 900, DEFAULTS.panel.width));
    s.panel.fontSize = Math.round(num(s.panel.fontSize, 11, 20, DEFAULTS.panel.fontSize));
    s.panel.opacity = num(s.panel.opacity, 0.5, 1, DEFAULTS.panel.opacity);
    s.panel.theme = s.panel.theme === 'light' ? 'light' : 'dark';
    s.panel.collapsed = s.panel.collapsed === true;
    s.panel.hidden = s.panel.hidden === true;
    s.panel.showEvidence = s.panel.showEvidence !== false;
    s.panel.showFoot = s.panel.showFoot !== false;
    s.panel.x = s.panel.x == null ? null : Math.round(num(s.panel.x, -4000, 12000, 0));
    s.panel.y = s.panel.y == null ? null : Math.round(num(s.panel.y, -4000, 12000, 0));
    return s;
  }

  /** 发给内容脚本/弹窗的版本：不带 Key，只带「有没有配」 */
  function publicSettings(s) {
    var out = clone(s);
    delete out.apiKey;
    delete out.blacklist;
    out.hasApiKey = !!(s && s.apiKey);
    out.endpointHost = hostOf(s && s.baseUrl);
    return out;
  }

  function hostOf(url) {
    try { return new URL(String(url)).host; } catch (e) { return ''; }
  }

  function validate(s) {
    var issues = [];
    if (!s.baseUrl) issues.push({ field: 'baseUrl', level: 'error', message: 'Base URL 为空' });
    if (!s.model) issues.push({ field: 'model', level: 'error', message: '模型名为空' });
    if (!s.apiKey) issues.push({ field: 'apiKey', level: 'warn', message: '没有 API Key，将只能使用本地兜底摘要' });
    if (s.apiKey && /\s/.test(s.apiKey)) issues.push({ field: 'apiKey', level: 'warn', message: 'API Key 里含空格，可能粘贴时带进了换行' });
    if (/^bearer\s/i.test(s.apiKey)) issues.push({ field: 'apiKey', level: 'warn', message: 'API Key 不要带 "Bearer " 前缀' });
    if (/\/chat\/completions/i.test(s.baseUrl)) issues.push({ field: 'baseUrl', level: 'warn', message: 'Base URL 不需要带 /chat/completions，填到 /v1 即可' });
    if (s.maxChars > 20000) issues.push({ field: 'maxChars', level: 'warn', message: '单次送入 ' + s.maxChars + ' 字会明显变慢变贵' });
    return { ok: issues.filter(function (i) { return i.level === 'error'; }).length === 0, issues: issues };
  }

  /** 把预设应用到配置上（切服务商时用） */
  function applyPreset(s, providerKey) {
    var preset = PRESETS[providerKey];
    if (!preset) return s;
    var out = deepMerge(s, {});
    out.provider = providerKey;
    if (providerKey !== 'custom') {
      out.baseUrl = preset.baseUrl;
      out.model = preset.model;
    }
    return out;
  }

  /** 黑名单匹配：支持 * 通配、裸域名、含路径的片段 */
  function compilePattern(pattern) {
    var p = String(pattern || '').trim().toLowerCase();
    if (!p) return null;
    if (p.indexOf('*') >= 0) {
      var escaped = p.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
      try { return new RegExp('^' + escaped + '$'); } catch (e) { return null; }
    }
    return { test: function (s) { return s.indexOf(p) >= 0; } };
  }

  function isBlacklisted(url, list) {
    if (!list || !list.length) return false;
    var target = String(url || '').toLowerCase();
    var host = hostOf(url).toLowerCase();
    for (var i = 0; i < list.length; i++) {
      var re = compilePattern(list[i]);
      if (!re) continue;
      if (re.test(host) || re.test(target)) return true;
    }
    return false;
  }

  /** 该 URL 是否在扩展的工作范围内（http/https，或显式允许 file） */
  function isSupportedUrl(url, s) {
    var u = String(url || '');
    if (/^https?:\/\//i.test(u)) return true;
    if (s && s.allowFileUrls && /^file:\/\//i.test(u)) return true;
    return false;
  }

  function settingsCacheToken(s) {
    return [s.model, s.lang, s.maxCharsPerItem, s.maxChars, s.fallbackLocal ? 'L' : 'N'].join('|');
  }

  /* ----------------------------- 存储适配 ----------------------------- */

  /** 把 chrome.storage.local 风格的 area 包装成 Promise 接口（也用于测试假实现） */
  function makeStore(area) {
    function get(key, dflt) {
      return new Promise(function (resolve) {
        if (!area || typeof area.get !== 'function') return resolve(dflt);
        area.get(key, function (result) {
          var err = null;
          // chrome.runtime.lastError 在 callback 内读取
          try { err = root && root.chrome && root.chrome.runtime && root.chrome.runtime.lastError; } catch (e) { err = null; }
          if (err || !result || result[key] === undefined) resolve(dflt);
          else resolve(result[key]);
        });
      });
    }
    function set(key, value) {
      return new Promise(function (resolve) {
        if (!area || typeof area.set !== 'function') return resolve(false);
        var patch = {};
        patch[key] = value;
        area.set(patch, function () { resolve(true); });
      });
    }
    return { get: get, set: set };
  }

  function loadSettings(store) {
    return store.get(STORAGE_KEY, null).then(function (raw) { return mergeSettings(raw); });
  }

  function saveSettings(store, s) {
    var merged = mergeSettings(s);
    return store.set(STORAGE_KEY, merged).then(function () { return merged; });
  }

  function loadPanel(store) {
    return store.get(PANEL_KEY, null).then(function (raw) {
      return deepMerge(DEFAULTS.panel, raw || {});
    });
  }

  function savePanel(store, panel) {
    var merged = deepMerge(DEFAULTS.panel, panel || {});
    return store.set(PANEL_KEY, merged).then(function () { return merged; });
  }

  return {
    STORAGE_KEY: STORAGE_KEY,
    PANEL_KEY: PANEL_KEY,
    STATS_KEY: STATS_KEY,
    CACHE_PREFIX: CACHE_PREFIX,
    TAB_PREFIX: TAB_PREFIX,
    PRESETS: PRESETS,
    DEFAULTS: DEFAULTS,
    deepMerge: deepMerge,
    clone: clone,
    mergeSettings: mergeSettings,
    publicSettings: publicSettings,
    validate: validate,
    applyPreset: applyPreset,
    normalizeList: normalizeList,
    compilePattern: compilePattern,
    isBlacklisted: isBlacklisted,
    isSupportedUrl: isSupportedUrl,
    settingsCacheToken: settingsCacheToken,
    hostOf: hostOf,
    makeStore: makeStore,
    loadSettings: loadSettings,
    saveSettings: saveSettings,
    loadPanel: loadPanel,
    savePanel: savePanel
  };
});
