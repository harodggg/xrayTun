/**
 * 素颜镜 · 弹窗脚本（popup.js）
 * ---------------------------------------------------------------------------
 * 四种输入：拖拽文件 / 选择文件 / 粘贴剪贴板 / 分析当前页面最大的图片。
 * 分析统一走后台（ANALYZE_URL / ANALYZE_DATA_URL），跨域图片也能取到像素；
 * 若消息通道失败，退回弹窗内用 BeautyEngine.analyzeSource 本地分析。
 * 见 docs/SPEC.md §5「弹窗」「结果视图」。
 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };

  var els = {};
  var state = {
    settings: null,
    presetWeights: null,
    busy: false,
    lastResult: null
  };

  var LEVEL_SLUG = {
    '原生': 'native',
    '轻度美颜': 'mild',
    '中度美颜': 'moderate',
    '重度美颜': 'heavy',
    '极致美颜': 'extreme'
  };

  /* =====================================================================
   * 基础工具
   * =================================================================== */

  function errText(err) {
    if (!err) return '未知错误';
    if (typeof err === 'string') return err;
    return String(err.message || err);
  }

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = String(text);
    return node;
  }

  function clear(node) {
    while (node && node.firstChild) node.removeChild(node.firstChild);
  }

  function levelSlug(level) { return LEVEL_SLUG[level] || 'unknown'; }

  /* =====================================================================
   * 通信（统一处理 chrome.runtime.lastError / 扩展上下文失效）
   * =================================================================== */

  function runtimeAlive() {
    try {
      return typeof chrome !== 'undefined' && !!chrome.runtime && !!chrome.runtime.id;
    } catch (err) {
      return false;
    }
  }

  function sendRequest(message, cb) {
    function finish(res) { if (typeof cb === 'function') cb(res); }
    if (!runtimeAlive()) { finish({ ok: false, error: '扩展已更新，请重新打开弹窗' }); return; }
    try {
      chrome.runtime.sendMessage(message, function (response) {
        var lastErr = null;
        try { lastErr = chrome.runtime.lastError; } catch (err) { lastErr = err; }
        if (lastErr) { finish({ ok: false, error: '扩展通信失败：' + errText(lastErr) }); return; }
        if (!response || typeof response !== 'object') { finish({ ok: false, error: '扩展没有返回结果' }); return; }
        finish(response);
      });
    } catch (err) {
      finish({ ok: false, error: '扩展通信失败：' + errText(err) });
    }
  }

  /* =====================================================================
   * 状态与视图切换
   * =================================================================== */

  function setBusy(busy, text) {
    state.busy = !!busy;
    if (els.status) els.status.hidden = !busy;
    if (text) els.statusText.textContent = text;
    var buttons = [els.pickFile, els.pasteClip, els.analyzePage];
    for (var i = 0; i < buttons.length; i++) {
      if (buttons[i]) buttons[i].disabled = !!busy;
    }
  }

  function setHint(text, isError) {
    if (!els.intakeHint) return;
    els.intakeHint.textContent = text || '';
    els.intakeHint.classList.toggle('is-error', !!isError);
  }

  var DEFAULT_HINT = '图片只在你的电脑上分析，不会上传到任何服务器。';

  function showEmpty() {
    els.empty.hidden = false;
    els.result.hidden = true;
    clear(els.result);
    state.lastResult = null;
  }

  function showResult(res) {
    state.lastResult = res || null;
    els.empty.hidden = true;
    els.result.hidden = false;
    clear(els.result);
    try {
      els.result.appendChild(buildResult(res));
    } catch (err) {
      clear(els.result);
      els.result.appendChild(buildFailureCard('渲染结果失败：' + errText(err)));
    }
    els.result.scrollIntoView({ block: 'nearest' });
  }

  function showErrorCard(message) {
    state.lastResult = { ok: false, error: message };
    els.empty.hidden = true;
    els.result.hidden = false;
    clear(els.result);
    els.result.appendChild(buildFailureCard(message));
  }

  /* =====================================================================
   * 结果渲染
   * =================================================================== */

  function buildFailureCard(message) {
    var card = el('div', 'card');
    var head = el('div', 'result-headline');
    head.appendChild(el('span', 'chip chip-level is-error', '无法分析'));
    head.appendChild(el('div', 'level-desc', '没有可显示的美颜程度分数'));
    card.appendChild(head);
    card.appendChild(el('div', 'error-box', message || '分析失败，请重试'));
    var tips = el('ul', 'tips');
    tips.appendChild(el('li', null, '确认图片是常见格式（JPG / PNG / WebP），并且没有损坏。'));
    tips.appendChild(el('li', null, '网页图片受跨域保护时，请改用「选择文件」或拖拽本地图片。'));
    tips.appendChild(el('li', null, '扩展刚更新过时，请刷新页面后重试。'));
    card.appendChild(tips);
    return card;
  }

  function buildScoreRing(score) {
    var value = clamp(Number(score) || 0, 0, 100);
    var wrap = el('div', 'ring-wrap');
    var ring = el('div', 'ring');
    ring.style.setProperty('--pct', String(Math.round(value * 10) / 10));
    ring.setAttribute('aria-hidden', 'true');
    wrap.appendChild(ring);

    var num = el('div', 'ring-num');
    num.appendChild(el('strong', null, String(Math.round(value))));
    num.appendChild(el('span', null, '/100'));
    wrap.appendChild(num);
    return wrap;
  }

  function buildMetricRow(metric) {
    var m = metric || {};
    var available = m.available !== false;
    var li = el('li', 'metric' + (available ? '' : ' is-unavailable'));

    var top = el('div', 'metric-top');
    top.appendChild(el('span', 'metric-label', m.label || m.key || '维度'));
    if (typeof m.weightPct === 'number' && m.weightPct > 0) {
      top.appendChild(el('span', 'metric-weight', '权重 ' + m.weightPct + '%'));
    }
    top.appendChild(el('span', 'metric-score', available ? String(m.score == null ? '—' : m.score) : '—'));
    li.appendChild(top);

    var bar = el('div', 'bar');
    var fill = el('div', 'bar-fill');
    fill.style.width = (available ? clamp(Number(m.score) || 0, 0, 100) : 0) + '%';
    bar.appendChild(fill);
    li.appendChild(bar);

    if (m.hint) li.appendChild(el('p', 'metric-hint', m.hint));
    if (available) {
      if (m.evidence) li.appendChild(el('p', 'metric-evidence', m.evidence));
    } else {
      li.appendChild(el('p', 'metric-evidence', '该项不可用：' + (m.evidence || '数据不足')));
    }
    return li;
  }

  function buildDebugSection(report) {
    if (!state.settings || !state.settings.showDebug) return null;
    var debug = report.debug && typeof report.debug === 'object' ? report.debug : null;
    if (!debug) return null;
    var details = el('details', 'debug');
    details.appendChild(el('summary', null, '调试数据（showDebug 已开启）'));
    var table = el('table', 'debug-table');
    Object.keys(debug).forEach(function (key) {
      var value = debug[key];
      if (value == null || typeof value === 'object') return;
      var tr = el('tr');
      tr.appendChild(el('th', null, key));
      tr.appendChild(el('td', null, String(value)));
      table.appendChild(tr);
    });
    details.appendChild(table);
    return details;
  }

  function buildReportCard(report) {
    var card = el('div', 'card');

    var head = el('div', 'result-head');
    head.appendChild(buildScoreRing(report.score));

    var headline = el('div', 'result-headline');
    var level = el('span', 'chip chip-level', report.level || '未知档位');
    level.setAttribute('data-level', levelSlug(report.level));
    headline.appendChild(level);
    if (report.levelDesc) headline.appendChild(el('div', 'level-desc', report.levelDesc));

    var chips = el('div', 'chips');
    var confidence = typeof report.confidence === 'number' ? report.confidence : 0;
    chips.appendChild(el('span', 'chip', '置信度 ' + Math.round(confidence * 100) + '%'));
    if (confidence < 0.5) chips.appendChild(el('span', 'chip chip-lowconf', '低置信度'));
    if (typeof report.skinRatio === 'number') {
      chips.appendChild(el('span', 'chip', '肤色占比 ' + Math.round(report.skinRatio * 100) + '%'));
    }
    headline.appendChild(chips);

    if (typeof report.width === 'number' && typeof report.height === 'number') {
      var dims = report.width + ' × ' + report.height;
      if (report.resized === true && typeof report.workingWidth === 'number') {
        dims += '（工作分辨率 ' + report.workingWidth + ' × ' + report.workingHeight + '）';
      }
      headline.appendChild(el('div', 'dims', dims));
    }
    head.appendChild(headline);
    card.appendChild(head);

    if (report.partial === true) {
      card.appendChild(el('div', 'banner', '仅供参考：未检测到人脸肤色'));
    }

    var summary = report.summary;
    if (!summary && typeof report.score === 'number') {
      summary = '美颜程度 ' + report.score + '/100（' + (report.level || '') + '）' +
        (report.levelDesc ? '：' + report.levelDesc : '');
    }
    if (summary) card.appendChild(el('p', 'summary', summary));

    var metrics = Array.isArray(report.metrics) ? report.metrics : [];
    if (metrics.length) {
      card.appendChild(el('div', 'section-title', '五个维度'));
      var list = el('ul', 'metrics');
      for (var i = 0; i < metrics.length; i++) list.appendChild(buildMetricRow(metrics[i]));
      card.appendChild(list);
    }

    var warnings = Array.isArray(report.warnings) ? report.warnings : [];
    if (warnings.length) {
      card.appendChild(el('div', 'section-title', '提示'));
      var warningList = el('ul', 'warnings');
      for (var j = 0; j < warnings.length; j++) {
        if (warnings[j]) warningList.appendChild(el('li', null, String(warnings[j])));
      }
      card.appendChild(warningList);
    }

    var debugSection = buildDebugSection(report);
    if (debugSection) card.appendChild(debugSection);

    var actions = el('div', 'actions');
    var copyBtn = el('button', 'btn btn-primary', '复制结论');
    copyBtn.setAttribute('type', 'button');
    var hint = el('span', 'copy-hint', '');
    copyBtn.addEventListener('click', function () {
      var original = copyBtn.textContent;
      copyText(conclusionText(state.lastResult), function (ok) {
        copyBtn.textContent = ok ? '已复制' : '复制失败';
        hint.textContent = ok ? '已复制到剪贴板' : '复制失败，请手动选择文本';
        setTimeout(function () {
          copyBtn.textContent = original;
          hint.textContent = '';
        }, 1600);
      });
    });
    actions.appendChild(copyBtn);
    actions.appendChild(hint);
    card.appendChild(actions);

    return card;
  }

  function buildDegradedCard(report) {
    var card = el('div', 'card');
    var title = report.reason === 'grayscale' ? '黑白 / 近灰度图片' : '这张图无法判断';
    var headline = el('div', 'result-headline');
    headline.appendChild(el('span', 'chip chip-level is-error', title));
    headline.appendChild(el('div', 'level-desc', '没有可显示的美颜程度分数'));
    card.appendChild(headline);
    card.appendChild(el('div', 'error-box', report.error || '无法判断这张图片的美颜程度'));

    var tips = el('ul', 'tips');
    if (report.reason === 'grayscale') {
      tips.appendChild(el('li', null, '黑白照片没有肤色信息，任何美颜程度判断都不可靠。'));
    } else {
      tips.appendChild(el('li', null, '换一张更大、色彩正常、人脸占比较大的图片试试。'));
      tips.appendChild(el('li', null, '建议长边不小于 480px，避免过度压缩的缩略图。'));
    }
    card.appendChild(tips);

    var warnings = Array.isArray(report.warnings) ? report.warnings : [];
    if (warnings.length) {
      card.appendChild(el('div', 'section-title', '提示'));
      var list = el('ul', 'warnings');
      for (var i = 0; i < warnings.length; i++) {
        if (warnings[i]) list.appendChild(el('li', null, String(warnings[i])));
      }
      card.appendChild(list);
    }
    return card;
  }

  function buildResult(res) {
    if (!res || !res.ok || !res.report) {
      return buildFailureCard((res && res.error) || '分析失败，请重试');
    }
    var report = res.report;
    if (report.ok === false) return buildDegradedCard(report);
    return buildReportCard(report);
  }

  /* =====================================================================
   * 复制结论（navigator.clipboard + execCommand 降级）
   * =================================================================== */

  function conclusionText(res) {
    if (!res || !res.ok || !res.report) {
      return '【素颜镜 · 美颜程度检测】\n结论：' + ((res && res.error) || '分析失败');
    }
    var report = res.report;
    if (report.ok === false) {
      return '【素颜镜 · 美颜程度检测】\n结论：' + (report.error || '无法判断');
    }
    var lines = ['【素颜镜 · 美颜程度检测】'];
    lines.push('美颜程度：' + report.score + '/100（' + (report.level || '') + '）' +
      (report.levelDesc ? '—— ' + report.levelDesc : ''));
    if (report.partial === true) lines.push('注意：未检测到人脸肤色，以上仅为整图参考值。');
    lines.push('置信度：' + Math.round((Number(report.confidence) || 0) * 100) + '%');
    var metrics = Array.isArray(report.metrics) ? report.metrics : [];
    if (metrics.length) {
      lines.push('维度：');
      for (var i = 0; i < metrics.length; i++) {
        var m = metrics[i] || {};
        var head = m.label || m.key || '维度';
        var weight = typeof m.weightPct === 'number' ? '（权重 ' + m.weightPct + '%）' : '';
        if (m.available === false) {
          lines.push('  · ' + head + weight + '：不可用（' + (m.evidence || '数据不足') + '）');
        } else {
          lines.push('  · ' + head + weight + '：' + m.score + (m.evidence ? ' —— ' + m.evidence : ''));
        }
      }
    }
    if (Array.isArray(report.warnings)) {
      for (var j = 0; j < report.warnings.length; j++) {
        if (report.warnings[j]) lines.push('提示：' + report.warnings[j]);
      }
    }
    if (report.summary) lines.push('一句话结论：' + report.summary);
    return lines.join('\n');
  }

  function copyText(text, cb) {
    function fallback() {
      var ok = false;
      try {
        var area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', 'readonly');
        area.style.position = 'fixed';
        area.style.top = '-1000px';
        document.body.appendChild(area);
        area.select();
        area.setSelectionRange(0, area.value.length);
        ok = document.execCommand('copy');
        document.body.removeChild(area);
      } catch (err) {
        ok = false;
      }
      cb(ok);
    }
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        navigator.clipboard.writeText(text).then(function () { cb(true); }, function () { fallback(); });
        return;
      }
    } catch (err) { /* 走降级 */ }
    fallback();
  }

  /* =====================================================================
   * 分析入口
   * =================================================================== */

  function engineOptions() {
    var s = state.settings || {};
    var weights = null;
    if (s.preset === 'custom' && s.customWeights) {
      weights = s.customWeights;
    } else if ((s.preset === 'smoothing' || s.preset === 'whitening') && state.presetWeights) {
      weights = state.presetWeights[s.preset] || null;
    }
    return { sensitivity: typeof s.sensitivity === 'number' ? s.sensitivity : 1, weights: weights };
  }

  /** 后台消息通道失败时的兜底：弹窗里直接分析本地文件（不会被跨域污染） */
  function analyzeLocally(blob, priorError) {
    if (!window.BeautyEngine || typeof window.BeautyEngine.analyzeSource !== 'function') {
      setBusy(false);
      showErrorCard(priorError || '分析引擎未加载，请重新打开弹窗或重新加载扩展');
      return;
    }
    setBusy(true, '正在本地分析…');
    var objectUrl = '';
    try { objectUrl = URL.createObjectURL(blob); } catch (err) {
      setBusy(false);
      showErrorCard(priorError ? (priorError + '；本地读取文件也失败：' + errText(err))
        : '无法读取这个文件：' + errText(err));
      return;
    }
    var img = new Image();
    img.onload = function () {
      var report = null;
      try {
        report = window.BeautyEngine.analyzeSource(img, engineOptions());
      } catch (err) {
        report = null;
      }
      try { URL.revokeObjectURL(objectUrl); } catch (err) { /* 忽略 */ }
      setBusy(false);
      if (!report) { showErrorCard(priorError || '本地分析失败，请换一张图片重试'); return; }
      showResult({ ok: true, report: report });
    };
    img.onerror = function () {
      try { URL.revokeObjectURL(objectUrl); } catch (err) { /* 忽略 */ }
      setBusy(false);
      showErrorCard(priorError ? (priorError + '；本地也无法解码这张图片')
        : '无法解码这张图片，可能已损坏或格式不受支持');
    };
    img.src = objectUrl;
  }

  function analyzeUrl(url, fallbackBlob) {
    setBusy(true, '分析中…（纯本地像素分析）');
    sendRequest({ type: 'ANALYZE_URL', url: url }, function (res) {
      if (res && res.ok) { setBusy(false); showResult(res); return; }
      if (fallbackBlob) { analyzeLocally(fallbackBlob, (res && res.error) || ''); return; }
      setBusy(false);
      showErrorCard((res && res.error) || '分析失败，请重试');
    });
  }

  function analyzeBlob(blob) {
    if (!blob) return;
    if (blob.type && blob.type.indexOf('image/') !== 0) {
      showErrorCard('这个文件不是图片（' + blob.type + '）');
      return;
    }
    setBusy(true, '正在读取图片…');
    var reader = new FileReader();
    reader.onload = function () {
      var dataUrl = String(reader.result || '');
      if (!dataUrl) { setBusy(false); showErrorCard('读取文件失败，请重试'); return; }
      analyzeUrl(dataUrl, blob);
    };
    reader.onerror = function () { setBusy(false); showErrorCard('读取文件失败，请重试'); };
    try {
      reader.readAsDataURL(blob);
    } catch (err) {
      setBusy(false);
      showErrorCard('读取文件失败：' + errText(err));
    }
  }

  function pickFile(file) {
    if (!file) return;
    setHint(DEFAULT_HINT, false);
    analyzeBlob(file);
  }

  /* =====================================================================
   * 「分析当前页面最大的图片」
   * =================================================================== */

  function askFrame(tabId, frameId, cb) {
    var finished = false;
    function finish(res) {
      if (finished) return;
      finished = true;
      cb(res);
    }
    var handler = function (response) {
      var lastErr = null;
      try { lastErr = chrome.runtime.lastError; } catch (err) { lastErr = err; }
      if (lastErr) {
        var text = errText(lastErr);
        if (text.indexOf('Receiving end does not exist') !== -1 ||
            text.indexOf('Could not establish connection') !== -1) {
          finish({ ok: false, error: '__NO_CONTENT__' });
        } else {
          finish({ ok: false, error: '与页面通信失败：' + text });
        }
        return;
      }
      if (!response) { finish({ ok: false, error: '页面没有响应' }); return; }
      finish(response);
    };
    try {
      if (typeof frameId === 'number') {
        chrome.tabs.sendMessage(tabId, { type: 'FIND_LARGEST_IMAGE' }, { frameId: frameId }, handler);
      } else {
        chrome.tabs.sendMessage(tabId, { type: 'FIND_LARGEST_IMAGE' }, handler);
      }
    } catch (err) {
      finish({ ok: false, error: errText(err) });
    }
  }

  function analyzeBiggestImage() {
    if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) {
      showErrorCard('当前环境无法读取标签页');
      return;
    }
    setBusy(true, '正在查找页面里最大的图片…');
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var lastErr = null;
        try { lastErr = chrome.runtime.lastError; } catch (err) { lastErr = err; }
        if (lastErr || !tabs || !tabs.length || typeof tabs[0].id !== 'number') {
          setBusy(false);
          showErrorCard('无法读取当前标签页：' + errText(lastErr || '没有找到标签页'));
          return;
        }
        var tabId = tabs[0].id;
        // 先问主框架，找不到再问所有框架（子框架里的图片也常见）
        askFrame(tabId, 0, function (mainRes) {
          if (mainRes && mainRes.ok && mainRes.url) { analyzeUrl(mainRes.url); return; }
          askFrame(tabId, null, function (anyRes) {
            if (anyRes && anyRes.ok && anyRes.url) { analyzeUrl(anyRes.url); return; }
            setBusy(false);
            var message = (anyRes && anyRes.error) || (mainRes && mainRes.error) || '当前页面没有找到可分析的图片';
            if (message === '__NO_CONTENT__') {
              message = '当前页面不支持检测（chrome:// 等内部页面无法注入脚本；扩展刚更新时请刷新页面）';
            }
            showErrorCard(message);
          });
        });
      });
    } catch (err) {
      setBusy(false);
      showErrorCard('无法读取当前标签页：' + errText(err));
    }
  }

  function pasteFromClipboard() {
    if (!navigator.clipboard || typeof navigator.clipboard.read !== 'function') {
      setHint('浏览器不允许直接读取剪贴板，请按 Ctrl+V 粘贴图片。', true);
      return;
    }
    setHint('正在读取剪贴板…', false);
    navigator.clipboard.read().then(function (items) {
      var type = '';
      var item = null;
      for (var i = 0; i < items.length && !item; i++) {
        var types = items[i].types || [];
        for (var j = 0; j < types.length; j++) {
          if (String(types[j]).indexOf('image/') === 0) { type = types[j]; item = items[i]; break; }
        }
      }
      if (!item) throw new Error('剪贴板里没有图片');
      return item.getType(type);
    }).then(function (blob) {
      setHint(DEFAULT_HINT, false);
      analyzeBlob(blob);
    }).catch(function (err) {
      setHint('无法直接读取剪贴板：' + errText(err) + '。请按 Ctrl+V 粘贴图片。', true);
    });
  }

  /* =====================================================================
   * 事件绑定与启动
   * =================================================================== */

  function bindFileInput() {
    els.pickFile.addEventListener('click', function () { els.fileInput.click(); });
    els.fileInput.addEventListener('change', function () {
      var file = els.fileInput.files && els.fileInput.files[0];
      pickFile(file);
      els.fileInput.value = '';
    });
    els.dropZone.addEventListener('click', function () { els.fileInput.click(); });
    els.dropZone.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        els.fileInput.click();
      }
    });
    els.dropZone.addEventListener('dragover', function (event) {
      event.preventDefault();
      els.dropZone.classList.add('is-over');
    });
    els.dropZone.addEventListener('dragleave', function () {
      els.dropZone.classList.remove('is-over');
    });
    els.dropZone.addEventListener('drop', function (event) {
      event.preventDefault();
      els.dropZone.classList.remove('is-over');
      var files = event.dataTransfer && event.dataTransfer.files;
      if (files && files.length) pickFile(files[0]);
    });
    document.addEventListener('dragover', function (event) { event.preventDefault(); });
    document.addEventListener('drop', function (event) { event.preventDefault(); });
  }

  function bindPaste() {
    document.addEventListener('paste', function (event) {
      var items = (event.clipboardData && event.clipboardData.items) || [];
      for (var i = 0; i < items.length; i++) {
        if (String(items[i].type || '').indexOf('image/') === 0) {
          var file = items[i].getAsFile();
          if (file) {
            event.preventDefault();
            pickFile(file);
            return;
          }
        }
      }
    });
    els.pasteClip.addEventListener('click', pasteFromClipboard);
  }

  function bindOptions() {
    els.openOptions.addEventListener('click', function () {
      try {
        if (chrome.runtime.openOptionsPage) {
          chrome.runtime.openOptionsPage(function () {
            try {
              var lastErr = chrome.runtime.lastError;
              if (lastErr) console.warn('[素颜镜] 打开设置页失败：' + errText(lastErr));
            } catch (err) { /* 忽略 */ }
          });
          return;
        }
      } catch (err) { /* 走下面的兜底 */ }
      sendRequest({ type: 'OPEN_OPTIONS' }, function (res) {
        if (!res || !res.ok) setHint('无法打开设置页，请在扩展管理页打开「扩展程序选项」。', true);
      });
    });
  }

  function loadSettings() {
    sendRequest({ type: 'GET_SETTINGS' }, function (res) {
      if (res && res.ok && res.settings) {
        state.settings = res.settings;
        state.presetWeights = res.presetWeights || null;
      } else {
        state.settings = {
          hoverEnabled: true, minImageSize: 160, hoverDelay: 300, sensitivity: 1,
          preset: 'balanced', customWeights: null, showDebug: false, siteWhitelist: []
        };
        state.presetWeights = null;
        setHint('读取设置失败，本次使用默认设置：' + ((res && res.error) || '未知原因'), true);
      }
    });
  }

  function init() {
    els.dropZone = $('drop-zone');
    els.pickFile = $('pick-file');
    els.pasteClip = $('paste-clip');
    els.analyzePage = $('analyze-page');
    els.fileInput = $('file-input');
    els.intakeHint = $('intake-hint');
    els.status = $('status');
    els.statusText = $('status-text');
    els.result = $('result');
    els.empty = $('empty');
    els.openOptions = $('open-options');
    els.engineVersion = $('engine-version');

    if (els.engineVersion) {
      var version = (window.BeautyEngine && window.BeautyEngine.VERSION) || '—';
      els.engineVersion.textContent = '引擎版本 v' + version;
    }

    bindFileInput();
    bindPaste();
    bindOptions();
    els.analyzePage.addEventListener('click', analyzeBiggestImage);

    showEmpty();
    setBusy(false, '');
    loadSettings();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
