/**
 * 一目十行 · 弹窗
 * ---------------------------------------------------------------------------
 * 面板被关掉之后的入口：随时看当前标签页最近一次的 3 条、强制重算、切换自动更新。
 * 数据来自 Service Worker 的 session 存储（按 tabId），所以打开弹窗是瞬时的，不会重新调用模型。
 */
'use strict';

var Settings = window.SpeedReadSettings;

var $ = function (id) { return document.getElementById(id); };
var state = { tabId: null, publicSettings: null, pollTimer: null };

function send(message) {
  return new Promise(function (resolve) {
    chrome.runtime.sendMessage(message, function (res) {
      void chrome.runtime.lastError;
      resolve(res || null);
    });
  });
}

function sendToTab(tabId, message) {
  return new Promise(function (resolve) {
    chrome.tabs.sendMessage(tabId, message, function (res) {
      void chrome.runtime.lastError;
      resolve(res || null);
    });
  });
}

function getActiveTab() {
  return new Promise(function (resolve) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      void chrome.runtime.lastError;
      resolve(tabs && tabs[0] ? tabs[0] : null);
    });
  });
}

async function renderDiagnostics() {
  if (state.tabId == null) return;
  var report = await send({ type: 'SR_DIAGNOSE', tabId: state.tabId });
  if (!report || !report.ok) {
    $('verdict').textContent = '诊断失败：拿不到后台响应，试试重新加载扩展。';
    $('verdict').className = 'verdict bad';
    return;
  }

  var bad = /没注入|没有 API|权限|启动失败|失败|不允许|黑名单/.test(report.verdict);
  var good = /已经算出 3 条/.test(report.verdict);
  $('verdict').className = 'verdict' + (bad ? ' bad' : good ? ' good' : '');
  $('verdict').textContent = report.verdict;

  function line(mark, label, value) {
    var li = document.createElement('li');
    var m = document.createElement('span');
    m.className = 'mark ' + mark;
    m.textContent = mark === 'good' ? '✓' : mark === 'warn' ? '!' : '✕';
    var body = document.createElement('span');
    var b = document.createElement('b');
    b.textContent = label + '：';
    body.appendChild(b);
    body.appendChild(document.createTextNode(value));
    li.appendChild(m);
    li.appendChild(body);
    return li;
  }

  var list = $('diagList');
  while (list.firstChild) list.removeChild(list.firstChild);

  list.appendChild(line(report.isHttp ? 'good' : 'bad', '页面', report.isHttp ? shortUrl(report.url) : (report.url || '（空）') + '（不支持的类型）'));
  list.appendChild(line(
    report.contentScript === 'alive' ? 'good' : 'bad',
    '内容脚本',
    report.contentScript === 'alive'
      ? '已注入并在运行' + (report.ping && report.ping.styleMode ? '' : '')
      : '未注入到本页（装扩展之前就打开的标签页需要补注入）'
  ));
  if (report.isHttp) {
    list.appendChild(line(
      report.originPermission === false ? 'bad' : report.originPermission ? 'good' : 'warn',
      '站点访问权限',
      report.originPermission === false ? '未授予 —— 到 chrome://extensions → 详情 → 网站访问权限' : report.originPermission ? '已授予' : '无法判断'
    ));
  }
  list.appendChild(line(report.blacklisted ? 'bad' : 'good', '黑名单', report.blacklisted ? '该站点被排除，扩展故意不动作' : '未命中'));
  list.appendChild(line(
    report.hasApiKey ? 'good' : (report.fallbackLocal ? 'warn' : 'bad'),
    'API Key',
    report.hasApiKey
      ? '已配置 · ' + report.model + ' @ ' + (report.endpointHost || '?')
      : (report.fallbackLocal ? '未配置 —— 现在只能用本地兜底摘要' : '未配置，且本地兜底已关闭 → 永远不会出结果')
  ));
  list.appendChild(line(report.autoUpdate ? 'good' : 'warn', '自动更新', report.autoUpdate ? '开' : '关（页面变化不会重算）'));
  list.appendChild(line(report.panelHidden ? 'warn' : 'good', '面板', report.panelHidden ? '已被隐藏（按 Alt+Shift+S 显示）' : '显示中'));
  if (report.contentError) list.appendChild(line('bad', '启动错误', report.contentError));
  if (report.lastRun) {
    var when = report.lastRun.at ? new Date(report.lastRun.at).toLocaleTimeString() : '—';
    list.appendChild(line(
      report.lastRun.ok ? 'good' : 'bad',
      '最近一次运行',
      report.lastRun.ok
        ? report.lastRun.items + ' 条 · ' + (report.lastRun.source === 'llm' ? 'AI 摘要' : '本地兜底') + ' · ' + when
        : ((report.lastRun.error && report.lastRun.error.message) || '失败') + ' · ' + when
    ));
  } else {
    list.appendChild(line('warn', '最近一次运行', '还没有记录 —— 这一页还没算过'));
  }

  $('inject').hidden = report.contentScript === 'alive' || !report.isHttp;
  $('showPanel').hidden = !report.panelHidden;
}

function shortUrl(url) {
  try {
    var u = new URL(url);
    var text = u.host + u.pathname;
    return text.length > 46 ? text.slice(0, 45) + '…' : text;
  } catch (e) {
    return String(url || '').slice(0, 46);
  }
}

function render(state_) {
  var rows = $('rows');
  var hint = $('hint');
  var meta = $('meta');
  var result = state_ && state_.result;

  if (result && result.ok && result.items && result.items.length === 3) {
    rows.hidden = false;
    hint.hidden = true;
    var nodes = rows.querySelectorAll('.row');
    var index = 0;
    ['alpha', 'beta', 'gamma'].forEach(function (key) {
      var item = result.items.filter(function (x) { return x.key === key; })[0] || result.items[index];
      var row = nodes[index++];
      row.querySelector('.text').textContent = item ? item.text : '';
    });
    var m = result.meta || {};
    var bits = [];
    bits.push(result.source === 'llm' ? 'AI 摘要' : '本地兜底');
    if (m.cached) bits.push('缓存');
    if (m.model) bits.push(String(m.model).slice(0, 30));
    if (m.inputChars) bits.push('正文 ' + m.inputChars + ' 字');
    if (m.ms) bits.push(m.ms < 1000 ? m.ms + 'ms' : (m.ms / 1000).toFixed(1) + 's');
    meta.textContent = bits.join(' · ');
    meta.className = 'meta';
  } else {
    rows.hidden = true;
    hint.hidden = false;
    if (result && !result.ok && result.error) {
      hint.querySelector('.hint-title').textContent = '没能生成 3 条';
      $('hintBody').textContent = [result.error.message, result.error.hint].filter(Boolean).join(' ');
      meta.textContent = result.error.code || '';
      meta.className = 'meta err';
    } else {
      hint.querySelector('.hint-title').textContent = '还没有结果';
      $('hintBody').textContent = state_ && state_.tabId
        ? '这个标签页还没有算过。点「重新压缩」，或刷新页面让面板自动处理。'
        : '打开一个网页后，面板会自动算好 3 条。';
      meta.textContent = state.publicSettings && !state.publicSettings.hasApiKey
        ? '⚠ 还没填 API Key，只会用本地兜底摘要'
        : '';
      meta.className = state.publicSettings && !state.publicSettings.hasApiKey ? 'meta warn' : 'meta';
    }
  }
}

async function refresh() {
  if (state.tabId == null) return;
  var res = await send({ type: 'SR_GET_TAB_STATE', tabId: state.tabId });
  if (res) {
    state.publicSettings = res.settings || state.publicSettings;
    render(res.state);
  }
  if (state.publicSettings) {
    $('auto').checked = !!state.publicSettings.autoUpdate;
    var host = state.publicSettings.endpointHost || '（未配置）';
    $('page').textContent = host + (state.publicSettings.hasApiKey ? '' : ' · 缺 Key');
  }
}

async function boot() {
  var tab = await getActiveTab();
  if (!tab) return;
  state.tabId = tab.id;
  if (tab.title) $('page').textContent = tab.title.slice(0, 42);
  await refresh();
  await renderDiagnostics();

  $('refresh').addEventListener('click', async function () {
    $('refresh').disabled = true;
    $('refresh').textContent = '压缩中…';
    await sendToTab(state.tabId, { type: 'SR_FORCE_REFRESH' });
    clearTimeout(state.pollTimer);
    state.pollTimer = setTimeout(async function () {
      await refresh();
      await renderDiagnostics();
      $('refresh').disabled = false;
      $('refresh').textContent = '重新压缩';
    }, 2600);
  });

  $('rediagnose').addEventListener('click', function () { renderDiagnostics(); });

  $('inject').addEventListener('click', async function () {
    var btn = $('inject');
    btn.disabled = true;
    btn.textContent = '注入中…';
    await send({ type: 'SR_INJECT_HERE', tabId: state.tabId });
    clearTimeout(state.pollTimer);
    state.pollTimer = setTimeout(async function () {
      await refresh();
      await renderDiagnostics();
      btn.disabled = false;
      btn.textContent = '补注入到本页';
    }, 2600);
  });

  $('showPanel').addEventListener('click', async function () {
    await sendToTab(state.tabId, { type: 'SR_TOGGLE_PANEL' });
    clearTimeout(state.pollTimer);
    state.pollTimer = setTimeout(async function () {
      await refresh();
      await renderDiagnostics();
    }, 900);
  });

  $('options2').addEventListener('click', function () {
    chrome.runtime.openOptionsPage();
    window.close();
  });

  $('options').addEventListener('click', function () {
    chrome.runtime.openOptionsPage();
    window.close();
  });

  $('auto').addEventListener('change', async function () {
    var store = Settings.makeStore(chrome.storage.local);
    var current = await Settings.loadSettings(store);
    current.autoUpdate = $('auto').checked;
    await Settings.saveSettings(store, current);
    await send({ type: 'SR_SETTINGS_CHANGED' });
    await refresh();
    await renderDiagnostics();
  });
}

boot();
